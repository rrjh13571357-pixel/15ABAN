require('dotenv').config();
const express = require('express');
const cors = require('cors');

// Use the compiled controller from dist
const controller = require('../../dist/backend/controllers/identityController');

const app = express();
app.use(cors());
app.use(express.json());

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res)).then(result => {
    if (!res.headersSent) res.json(result);
  }).catch(err => {
    console.error('[Identity Service] Error', err);
    res.status(400).json({ message: err.message });
  });
};

app.post('/api/auth/login', asyncHandler(async (req, res) => controller.login(req.body.username, req.body.password)));

app.get('/api/users', asyncHandler(async (req, res) => controller.getSystemUsers()));
app.post('/api/users', asyncHandler(async (req, res) => {
  const result = controller.addSystemUser(req.body);
  res.status(201).json(result);
}));
app.put('/api/users/:id', asyncHandler(async (req, res) => controller.updateSystemUser({ ...req.body, id: Number(req.params.id) })));
app.put('/api/users/:id/define', asyncHandler(async (req, res) => controller.defineSystemUser(Number(req.params.id), req.body)));
app.delete('/api/users/:id', asyncHandler(async (req, res) => controller.deleteSystemUser(Number(req.params.id))));

app.get('/api/beneficiaries', asyncHandler(async (req, res) => controller.getBeneficiaries()));
app.post('/api/beneficiaries', asyncHandler(async (req, res) => controller.addBeneficiary(req.body)));
app.put('/api/beneficiaries', asyncHandler(async (req, res) => controller.updateBeneficiary(req.body)));
app.delete('/api/beneficiaries/:id', asyncHandler(async (req, res) => controller.deleteBeneficiary(Number(req.params.id))));

app.get('/api/petty-cash-holders', asyncHandler(async (req, res) => controller.getPettyCashHolders()));
app.post('/api/petty-cash-holders/set-global-limit', asyncHandler(async (req, res) => controller.updateAllPettyCashLimits(req.body.limit)));

app.get('/api/roles', asyncHandler(async (req, res) => controller.getRoles()));
app.post('/api/roles', asyncHandler(async (req, res) => controller.addRole(req.body)));
app.put('/api/roles', asyncHandler(async (req, res) => controller.updateRole(req.body)));
app.delete('/api/roles/:id', asyncHandler(async (req, res) => controller.deleteRole(Number(req.params.id))));

const PORT = process.env.PORT || 3010;
app.listen(PORT, () => console.log(`👤 Identity service running on port ${PORT}`));
