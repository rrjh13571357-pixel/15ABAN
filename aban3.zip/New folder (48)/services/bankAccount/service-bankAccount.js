require('dotenv').config();
const express = require('express');
const cors = require('cors');
const controller = require('../../dist/backend/controllers/bankAccountController');

const app = express();
app.use(cors());
app.use(express.json());

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res)).then(result => { if (!res.headersSent) res.json(result); }).catch(err => { console.error('[BankAccount Service] Error', err); res.status(400).json({ message: err.message }); });
};

app.get('/api/bank-accounts', asyncHandler(async (req, res) => controller.getBankAccounts()));

const PORT = process.env.PORT || 3014;
app.listen(PORT, () => console.log(`🏦 BankAccount service running on port ${PORT}`));
