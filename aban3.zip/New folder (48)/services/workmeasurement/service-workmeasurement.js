require('dotenv').config();
const express = require('express');
const cors = require('cors');
const controller = require('../../dist/backend/controllers/workMeasurementController');

const app = express();
app.use(cors());
app.use(express.json());

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res)).then(result => { if (!res.headersSent) res.json(result); }).catch(err => { console.error('[WorkMeasurement Service] Error', err); res.status(400).json({ message: err.message }); });
};

app.get('/api/tasks', asyncHandler(async (req, res) => controller.getTasks()));

const PORT = process.env.PORT || 3017;
app.listen(PORT, () => console.log(`🛠 WorkMeasurement service running on port ${PORT}`));
