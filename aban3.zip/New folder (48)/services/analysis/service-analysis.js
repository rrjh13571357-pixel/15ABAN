require('dotenv').config();
const express = require('express');
const cors = require('cors');
const controller = require('../../dist/backend/controllers/analysisController');

const app = express();
app.use(cors());
app.use(express.json());

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res)).then(result => { if (!res.headersSent) res.json(result); }).catch(err => { console.error('[Analysis Service] Error', err); res.status(400).json({ message: err.message }); });
};

app.post('/api/analysis', asyncHandler(async (req, res) => controller.getAnalysis(req.body.question)));
app.get('/api/analysis/templates', asyncHandler(async (req, res) => controller.getTemplates()));

const PORT = process.env.PORT || 3018;
app.listen(PORT, () => console.log(`📊 Analysis service running on port ${PORT}`));
