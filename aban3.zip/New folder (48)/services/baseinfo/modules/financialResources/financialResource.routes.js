const express = require('express');
const router = express.Router();
const controller = require('./financialResource.controller');

router.get('/financial-resources', controller.getFinancialResources);

module.exports = router;
