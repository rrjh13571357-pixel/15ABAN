const db = require('../../db');

const findAll = async () => {
    const { rows } = await db.query('SELECT * FROM financial_resources ORDER BY name');
    return rows;
};

module.exports = { findAll };
