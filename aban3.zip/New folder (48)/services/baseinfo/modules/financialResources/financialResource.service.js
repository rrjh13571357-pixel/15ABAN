const repository = require('./financialResource.repository');

const getAll = () => repository.findAll();

module.exports = { getAll };
