const service = require('./financialResource.service');
const asyncHandler = require('../../utils/asyncHandler');

const getFinancialResources = asyncHandler(async (req, res) => {
    const data = await service.getAll();
    res.json(data);
});

module.exports = { getFinancialResources };
