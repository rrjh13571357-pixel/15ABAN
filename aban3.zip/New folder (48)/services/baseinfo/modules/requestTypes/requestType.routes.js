const express = require('express');
const router = express.Router();
const controller = require('./requestType.controller');

router.get('/request-types', controller.getRequestTypes);

module.exports = router;
