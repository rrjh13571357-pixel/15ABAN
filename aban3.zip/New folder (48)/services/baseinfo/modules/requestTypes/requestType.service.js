const repository = require('./requestType.repository');

const getAll = () => repository.findAll();

module.exports = { getAll };
