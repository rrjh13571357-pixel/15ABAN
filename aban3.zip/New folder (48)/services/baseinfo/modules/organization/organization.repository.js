const db = require('../../db');

const findAll = async () => {
    const { rows } = await db.query('SELECT id, title, code, manager_id as "managerId", parent FROM org_units ORDER BY code');
    return rows;
};

const create = async (unit) => {
    await db.query('INSERT INTO org_units(id, title, code, manager_id, parent) VALUES($1, $2, $3, $4, $5)', 
        [unit.id, unit.title, unit.code, unit.managerId, unit.parent]
    );
    return findAll();
};

const update = async (unit) => {
     await db.query('UPDATE org_units SET title=$1, code=$2, manager_id=$3, parent=$4 WHERE id=$5', 
        [unit.title, unit.code, unit.managerId, unit.parent, unit.id]
    );
    return findAll();
};

const remove = async (id) => {
    // Note: In a real app, we'd check for dependencies (users, projects) before deleting.
    await db.query('DELETE FROM org_units WHERE id=$1', [id]);
    return findAll();
};

module.exports = {
    findAll,
    create,
    update,
    remove,
};
