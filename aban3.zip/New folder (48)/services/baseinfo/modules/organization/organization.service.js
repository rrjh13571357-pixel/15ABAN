const repository = require('./organization.repository');

const getAll = () => repository.findAll();

const create = (unitData) => {
    const newUnit = { id: Date.now().toString(), ...unitData };
    return repository.create(newUnit);
};

const update = (id, unitData) => repository.update({ ...unitData, id });

const remove = (id) => repository.remove(id);


module.exports = {
    getAll,
    create,
    update,
    remove,
};
