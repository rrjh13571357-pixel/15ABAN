const db = require('../../db');

const findAll = async () => {
    const { rows } = await db.query('SELECT id, bank_name as "bankName", account_number as "accountNumber", iban, owner_id as "ownerId", owner_type as "ownerType" FROM bank_accounts ORDER BY id');
    return rows;
};

module.exports = { findAll };
