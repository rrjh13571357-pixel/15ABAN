const repository = require('./bankAccount.repository');

const getAll = () => repository.findAll();

module.exports = { getAll };
