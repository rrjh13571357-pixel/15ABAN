const service = require('./bankAccount.service');
const asyncHandler = require('../../utils/asyncHandler');

const getBankAccounts = asyncHandler(async (req, res) => {
    const data = await service.getAll();
    res.json(data);
});

module.exports = { getBankAccounts };
