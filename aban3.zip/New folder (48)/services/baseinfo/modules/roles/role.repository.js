const db = require('../../db');

const findAll = async () => {
    const { rows } = await db.query('SELECT id, title, description, user_count as "userCount", status FROM roles ORDER BY title');
    return rows;
};

module.exports = { findAll };
