const db = require('../../db');

const findAllBeneficiaries = async () => {
    const { rows } = await db.query('SELECT id, full_name as "fullName", national_code as "nationalCode" FROM beneficiaries ORDER BY full_name');
    return rows;
};

const findAllPettyCashHolders = async () => {
    const { rows } = await db.query('SELECT id, full_name as "fullName", national_code as "nationalCode", associated_center_id as "associatedCenterId", petty_cash_limit as "pettyCashLimit" FROM petty_cash_holders ORDER BY full_name');
    return rows;
};

const updateAllPettyCashLimits = async (limit) => {
    await db.query('UPDATE petty_cash_holders SET petty_cash_limit = $1', [limit]);
    return findAllPettyCashHolders();
}

module.exports = {
    findAllBeneficiaries,
    findAllPettyCashHolders,
    updateAllPettyCashLimits
};
