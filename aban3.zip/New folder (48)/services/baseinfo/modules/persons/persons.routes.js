const express = require('express');
const router = express.Router();
const controller = require('./persons.controller');

// Beneficiaries
router.get('/beneficiaries', controller.getBeneficiaries);
// Add POST, PUT, DELETE for beneficiaries if needed

// Petty Cash Holders
router.get('/petty-cash-holders', controller.getPettyCashHolders);
router.post('/petty-cash-holders/set-global-limit', controller.updateAllPettyCashLimits);
// Add POST, PUT, DELETE for petty cash holders if needed

module.exports = router;
