const repository = require('./persons.repository');

const getAllBeneficiaries = () => repository.findAllBeneficiaries();
const getAllPettyCashHolders = () => repository.findAllPettyCashHolders();
const updateAllPettyCashLimits = (limit) => repository.updateAllPettyCashLimits(limit);

module.exports = {
    getAllBeneficiaries,
    getAllPettyCashHolders,
    updateAllPettyCashLimits
};
