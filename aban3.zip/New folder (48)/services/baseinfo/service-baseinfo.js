const express = require("express");
const dotenv = require("dotenv");
const cors = require('cors');

// Import modular components
const { initializeDb } = require('./db/initialize');
const organizationRoutes = require('./modules/organization/organization.routes');
const personsRoutes = require('./modules/persons/persons.routes');
const bankAccountRoutes = require('./modules/bankAccounts/bankAccount.routes');
const financialResourceRoutes = require('./modules/financialResources/financialResource.routes');
const requestTypeRoutes = require('./modules/requestTypes/requestType.routes');
const roleRoutes = require('./modules/roles/role.routes');


dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.BASEINFO_PORT || 3006;

// Initialize Database
initializeDb().catch(err => {
    console.error("❌ [BaseInfo Service] Failed to initialize database on startup.", err);
    process.exit(1);
});

// --- API Routes ---
// Use the modular routes
app.use('/api', organizationRoutes);
app.use('/api', personsRoutes);
app.use('/api', bankAccountRoutes);
app.use('/api', financialResourceRoutes);
app.use('/api', requestTypeRoutes);
app.use('/api', roleRoutes);


// Health Check
app.get("/health", (req, res) => res.json({ status: "ok" }));

app.listen(PORT, () => {
  console.log(`ℹ️  BaseInfo Service running on http://localhost:${PORT}`);
});