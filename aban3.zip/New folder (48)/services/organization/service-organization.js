require('dotenv').config();
const express = require('express');
const cors = require('cors');
const controller = require('../../dist/backend/controllers/organizationController');

const app = express();
app.use(cors());
app.use(express.json());

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res)).then(result => { if (!res.headersSent) res.json(result); }).catch(err => { console.error('[Organization Service] Error', err); res.status(400).json({ message: err.message }); });
};

app.get('/api/org-units', asyncHandler(async (req, res) => controller.getOrgUnits()));
app.delete('/api/org-units/:id', asyncHandler(async (req, res) => controller.deleteOrgUnit(req.params.id)));

const PORT = process.env.PORT || 3011;
app.listen(PORT, () => console.log(`🏢 Organization service running on port ${PORT}`));
