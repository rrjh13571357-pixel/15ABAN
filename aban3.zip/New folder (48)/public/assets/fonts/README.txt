Place your local Vazirmatn .woff2 files here with the exact names below:

Vazirmatn-FD-Regular.woff2
Vazirmatn-FD-Bold.woff2

After copying, reload the dev server (if running) or restart Vite:

# In PowerShell (from project root)
npm --workspace=frontend run dev

This folder is served as /assets/fonts/ during development and production build.
