/*
  Simplified service worker:
  - Activate immediately and claim clients so updates take effect.
  - Bypass all cross-origin requests (fonts, CDNs, analytics) so the SW
    never intercepts or caches remote resources like Google Fonts.
  - Keep a small same-origin cache for app shell entries only.
*/

const CACHE_NAME = 'supply-chain-cache-v49';
const APP_SHELL = [
  '/',
  '/index.html',
  '/manifest.json',
  '/assets/icon.svg'
];

const OPTIONAL_CACHE = [
  '/libs/ckeditor.js',
  '/libs/ckeditor-fa.js',
  '/vazirmatn.css'
];

// Separate critical resources from optional ones
const urlsToCache = [...APP_SHELL];

self.addEventListener('install', event => {
  // Activate new SW faster
  self.skipWaiting();
  
  // Cache critical resources first
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Cache app shell first
      await cache.addAll(APP_SHELL);
      // Then cache optional resources
      cache.addAll(OPTIONAL_CACHE).catch(() => {});
    })()
  );
});

self.addEventListener('activate', event => {
  // Take control of uncontrolled clients immediately
  event.waitUntil((async () => {
    await clients.claim();
    // Clean up any old caches not matching current name
    const cacheNames = await caches.keys();
    await Promise.all(cacheNames.map(name => name === CACHE_NAME ? null : caches.delete(name)));
  })());
});

self.addEventListener('fetch', event => {
  try {
    const requestUrl = new URL(event.request.url);

    // Bypass cross-origin requests (CDNs, google fonts etc.) to avoid SW serving cached errors
    if (requestUrl.origin !== location.origin) {
      return; // let the browser handle cross-origin requests directly
    }

    // Don't interfere with non-GET or API requests
    if (event.request.method !== 'GET' || requestUrl.pathname.startsWith('/api/')) {
      return;
    }

    // For same-origin GETs: try cache first, then network and cache response
    event.respondWith((async () => {
      const cached = await caches.match(event.request);
      if (cached) return cached;
      try {
        const networkResponse = await fetch(event.request);
        if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
          const clone = networkResponse.clone();
          const cache = await caches.open(CACHE_NAME);
          cache.put(event.request, clone).catch(() => {});
        }
        return networkResponse;
      } catch (err) {
        // If network fails, try cache fallback (if any)
        const fallback = await caches.match('/index.html');
        return fallback || new Response('Offline', { status: 503, statusText: 'Offline' });
      }
    })());
  } catch (e) {
    // If URL parsing fails, do nothing and let browser handle it
    return;
  }
});
