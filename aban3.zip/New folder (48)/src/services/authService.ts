import type { SystemUser } from '../types';
import { api } from './api';

export const login = (username: string, password: string): Promise<SystemUser> => {
    // Backend expects /api/login (API_BASE_URL already contains /api)
    return api.post<SystemUser>('/login', { username, password });
};
