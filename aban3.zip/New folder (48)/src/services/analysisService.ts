import { api } from './api';
import type { TemplatedQuery } from '../types';

export const getAnalysis = (question: string): Promise<string> => {
    return api.post<string>('/analysis', { question });
};

export const getTemplates = (): Promise<TemplatedQuery[]> => {
    return api.get<TemplatedQuery[]>('/analysis/templates');
};
