import { api } from './api';
import type { Contract, ContractDetails, Payment, Guarantee, Addendum } from '../types';

export const getContractList = (): Promise<Contract[]> => {
    return api.get<Contract[]>('/contracts');
};

export const getContractDetails = (id: number): Promise<ContractDetails> => {
    return api.get<ContractDetails>(`/contracts/${id}`);
};

export const addContract = async (contractData: Omit<ContractDetails, 'id' | 'payments' | 'guarantees' | 'addendums' | 'attachments'>): Promise<Contract[]> => {
    await api.post<Contract>('/contracts', contractData);
    return getContractList();
};

export const updateContract = (contractData: ContractDetails): Promise<ContractDetails> => {
    return api.put<ContractDetails>(`/contracts/${contractData.id}`, contractData);
};

export const deleteContract = async (id: number): Promise<Contract[]> => {
    await api.del(`/contracts/${id}`);
    return getContractList();
};

// --- Payments ---
export const addPayment = (paymentData: Omit<Payment, 'id'>): Promise<ContractDetails> => {
    return api.post<ContractDetails>(`/contracts/${paymentData.contractId}/payments`, paymentData);
};

// --- Guarantees ---
export const addGuarantee = (guaranteeData: Omit<Guarantee, 'id'>): Promise<ContractDetails> => {
    return api.post<ContractDetails>(`/contracts/${guaranteeData.contractId}/guarantees`, guaranteeData);
};

// --- Addendums ---
export const addAddendum = (addendumData: Omit<Addendum, 'id'>): Promise<ContractDetails> => {
    return api.post<ContractDetails>(`/contracts/${addendumData.contractId}/addendums`, addendumData);
};
