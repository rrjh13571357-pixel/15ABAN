import { api } from './api';
import type { Payroll, PayrollDetails } from '../types';

export const getPayrolls = (): Promise<Payroll[]> => {
    return api.get<Payroll[]>('/payrolls');
};

export const getPayrollDetails = (payrollId: number): Promise<PayrollDetails> => {
    return api.get<PayrollDetails>(`/payrolls/${payrollId}`);
};
