import './index.css';
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Register service worker only in production build. During dev it causes cache
// and network interference (404/old assets) so skip registration when Vite's
// dev server is running.
const isDev = (import.meta as any).env ? (import.meta as any).env.DEV : false;

if (!isDev && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then(registration => {
      console.log('ServiceWorker registration successful with scope: ', registration.scope);
    }, err => {
      console.log('ServiceWorker registration failed: ', err);
    });
  });
} else {
  // If in dev, try to unregister any previously-registered service workers.
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then(regs => regs.forEach(r => r.unregister()));
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
