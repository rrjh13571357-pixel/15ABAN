const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'mysecret';

// --- PostgreSQL Setup for User Authentication ---
const pool = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://postgres:admin@localhost:5432/tamin_db',
});

const initialUsersForAuth = [
    {id: 1, fullName: 'علی احمدی', nationalCode: '1234567890', unitId: '2', roleId: 1, username: 'ali.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 6, fullName: 'مدیر سیستم', nationalCode: '1010101010', unitId: '4', roleId: 4, username: 'admin', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: true },
    {id: 7, fullName: 'سارا احمدی', nationalCode: '111222333', unitId: '1', roleId: 2, username: 'sara.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 8, fullName: 'علی رضایی', nationalCode: '444555666', unitId: '2', roleId: 1, username: 'ali.rezaei', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 9, fullName: 'مریم حسینی', nationalCode: '777888999', unitId: '3', roleId: 1, username: 'maryam.hosseini', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 10, fullName: 'رضا قاسمی', nationalCode: '121212121', unitId: '4', roleId: 1, username: 'reza.ghasemi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 4, fullName: 'روح الله جهان پناه', nationalCode: '5566778899', unitId: '1', roleId: 1, username: 'roohollah.j', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 5, fullName: 'محسن سعادتی', nationalCode: '0000000000', unitId: '2', roleId: 1, username: 'mohsen.s', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
];

const initializeDb = async () => {
    try {
        await pool.query(`
          CREATE TABLE IF NOT EXISTS system_users (
            id INTEGER PRIMARY KEY,
            full_name TEXT NOT NULL,
            national_code TEXT,
            unit_id TEXT,
            role_id INTEGER,
            username TEXT UNIQUE,
            password TEXT,
            status TEXT DEFAULT 'active',
            force_password_change BOOLEAN DEFAULT false,
            password_never_expires BOOLEAN DEFAULT false,
            description TEXT
          )
        `);

        const saltRounds = 10;
        for (const user of initialUsersForAuth) {
            const hash = user.password ? await bcrypt.hash(user.password, saltRounds) : null;
            await pool.query(
                `INSERT INTO system_users (id, full_name, national_code, unit_id, role_id, username, password, status, force_password_change, password_never_expires) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) 
                 ON CONFLICT (id) DO NOTHING`,
                [user.id, user.fullName, user.nationalCode, user.unitId, user.roleId, user.username, hash, user.status, user.forcePasswordChange, user.passwordNeverExpires]
            );
        }
        console.log("✅ [Users Service] PostgreSQL user database is ready.");
    } catch (err) {
        console.error("❌ [Users Service] Error initializing PostgreSQL database:", err);
        process.exit(1);
    }
};
initializeDb();

// --- API Routes for Users Service ---

const asyncHandler = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(error => {
        console.error(`[Users Service] Error in ${req.method} ${req.path}:`, error);
        res.status(400).json({ message: error.message });
    });
};

app.post("/api/login", asyncHandler(async (req, res) => {
    const { username, password } = req.body;
    const { rows } = await pool.query('SELECT * FROM system_users WHERE username = $1', [username]);
    const user = rows[0];

    if (!user || !user.password) return res.status(401).json({ message: "Invalid credentials" });
    if (user.status === 'inactive') return res.status(403).json({ message: "User account is inactive" });
    
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ message: "Invalid credentials" });

    // Exclude password from the returned object
    const { password: _, ...userToReturn } = user;
    
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "8h" });
    
    res.json({ token, user: userToReturn });
}));

app.get("/api/users", asyncHandler(async (req, res) => {
    const { rows } = await pool.query('SELECT id, full_name, national_code, unit_id, role_id, username, status, force_password_change, password_never_expires, description FROM system_users ORDER BY id');
    res.json(rows);
}));

app.listen(PORT, () => {
  console.log(`👤 Users Service running on http://localhost:${PORT}`);
});