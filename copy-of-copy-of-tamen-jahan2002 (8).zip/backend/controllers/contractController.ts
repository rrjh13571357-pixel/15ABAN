
import { db } from '../db';
import type { Contract, ContractDetails, Payment, Guarantee, Addendum } from '../../shared/types';

// Helper to project full details to list view
const projectToListView = (details: ContractDetails): Contract => ({
    id: details.id,
    contractNumber: details.contractNumber,
    title: details.title,
    party: details.party,
    amount: details.amount,
    endDate: details.endDate,
    status: details.status,
});

export const getContractList = (): Contract[] => {
    const allDetails = db.contracts.get();
    return allDetails.map(projectToListView);
};

export const getContractDetails = (id: number): ContractDetails => {
    const allContracts = db.contracts.get();
    const contract = allContracts.find(c => c.id === id);
    if (!contract) {
        throw new Error('Contract not found');
    }
    // In a real DB, you'd fetch related items. Here, we filter them.
    contract.payments = db.payments.get().filter(p => p.contractId === id);
    contract.guarantees = db.guarantees.get().filter(g => g.contractId === id);
    contract.addendums = db.addendums.get().filter(a => a.contractId === id);
    contract.attachments = db.attachments.get().filter(at => at.contractId === id);
    return contract;
};

export const addContract = (contractData: Omit<ContractDetails, 'id' | 'payments' | 'guarantees' | 'addendums' | 'attachments'>): Contract[] => {
    const contracts = db.contracts.get();
    const newContract: ContractDetails = {
        ...contractData,
        id: Date.now(),
        payments: [],
        guarantees: [],
        addendums: [],
        attachments: [],
    };
    contracts.push(newContract);
    db.contracts.set(contracts);
    return getContractList();
};

export const updateContract = (contractData: ContractDetails): ContractDetails => {
    let contracts = db.contracts.get();
    const index = contracts.findIndex(c => c.id === contractData.id);
    if (index !== -1) {
        // Keep relations, update main data
        const existingRelations = contracts[index];
        contracts[index] = {
            ...contractData,
            payments: existingRelations.payments,
            guarantees: existingRelations.guarantees,
            addendums: existingRelations.addendums,
            attachments: existingRelations.attachments,
        };
        db.contracts.set(contracts);
        return contracts[index];
    }
    throw new Error('Contract not found');
};

export const deleteContract = (id: number): Contract[] => {
    const requests = db.requests.get();
    if (requests.some(r => r.contractId === id)) {
        throw new Error('Cannot delete contract: It is linked to one or more payment requests.');
    }
    
    let contracts = db.contracts.get();
    const updatedContracts = contracts.filter(c => c.id !== id);
    db.contracts.set(updatedContracts);
    // Also delete related items
    db.payments.set(db.payments.get().filter(p => p.contractId !== id));
    db.guarantees.set(db.guarantees.get().filter(g => g.contractId !== id));
    db.addendums.set(db.addendums.get().filter(a => a.contractId !== id));
    db.attachments.set(db.attachments.get().filter(at => at.contractId !== id));
    return getContractList();
};

// --- Sub-entity CRUD ---

export const addPayment = (paymentData: Omit<Payment, 'id'>): ContractDetails => {
    const payments = db.payments.get();
    const newPayment: Payment = { ...paymentData, id: Date.now() };
    payments.push(newPayment);
    db.payments.set(payments);
    return getContractDetails(paymentData.contractId);
};

export const addGuarantee = (guaranteeData: Omit<Guarantee, 'id'>): ContractDetails => {
    const guarantees = db.guarantees.get();
    const newGuarantee: Guarantee = { ...guaranteeData, id: Date.now() };
    guarantees.push(newGuarantee);
    db.guarantees.set(guarantees);
    return getContractDetails(guaranteeData.contractId);
};

export const addAddendum = (addendumData: Omit<Addendum, 'id'>): ContractDetails => {
    const addendums = db.addendums.get();
    const newAddendum: Addendum = { ...addendumData, id: Date.now() };
    addendums.push(newAddendum);
    db.addendums.set(addendums);
    return getContractDetails(addendumData.contractId);
};