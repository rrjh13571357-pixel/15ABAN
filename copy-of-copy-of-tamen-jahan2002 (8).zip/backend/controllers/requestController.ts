import type { Request, RequestDetails, Invoice, InvoiceItem, SystemUser, OrganizationalUnit, Project, FinancialResource, Beneficiary, Payment, WorkflowStepState, Rejection, Consultation } from '../../shared/types';
import { db } from '../db';
import { RequestStatus } from '../../shared/types';
import { addNotification } from './notificationController';

interface FormInvoiceItem {
    description: string;
    quantity: number;
    unitPrice: number;
}
interface FormInvoice {
    invoiceNumber: string;
    beneficiaryId: number | null;
    items: FormInvoiceItem[];
}

export const getRequests = (): Request[] => {
    return db.requests.get();
};

export const getConsultations = (): Consultation[] => {
    return db.consultations.get();
};

export const addRequest = (
    newRequestData: Omit<Request, 'id' | 'status' | 'date' | 'lastModified'>,
    invoicesData: FormInvoice[]
): Request[] => {
    const requests = db.requests.get();
    const invoices = db.invoices.get();
    const invoiceItems = db.invoiceItems.get();
    const users = db.systemUsers.get();
    const units = db.orgUnits.get();
    const counters = db.requestCounters.get();

    const applicantUser = users.find(u => u.id === newRequestData.originalApplicantId);
    if (!applicantUser) {
        throw new Error("Applicant user not found");
    }

    const applicantUnit = units.find(u => u.id === applicantUser.unitId);
    const unitCode = applicantUnit ? applicantUnit.code : '000';
    
    // Using a library for Jalali date would be better, but this is a simple simulation
    const [year, month, day] = new Date().toLocaleDateString('fa-IR-u-nu-latn').split('/');

    const counterKey = `${year}-${unitCode}-${month}`;
    const newCount = (counters[counterKey] || 0) + 1;
    counters[counterKey] = newCount;
    db.requestCounters.set(counters);
    
    const sequence = String(newCount).padStart(4, '0');
    const newId = `${year}-${unitCode}-${month}-${sequence}`;

    const newRequest: Request = {
        ...newRequestData,
        id: newId,
        status: RequestStatus.Pending,
        date: new Date().toLocaleDateString('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' }),
        lastModified: new Date().toISOString(),
    };

    requests.unshift(newRequest); // Add to the top of the list
    
    // Create invoices and items for this request
    invoicesData.forEach(invData => {
        if (invData.beneficiaryId) {
            const newInvoice: Invoice = {
                id: Date.now() + Math.random(), // simple unique id
                requestId: newRequest.id,
                invoiceNumber: invData.invoiceNumber,
                beneficiaryId: invData.beneficiaryId,
            };
            invoices.push(newInvoice);

            invData.items.forEach(itemData => {
                const newInvoiceItem: InvoiceItem = {
                    id: Date.now() + Math.random(),
                    invoiceId: newInvoice.id,
                    description: itemData.description,
                    quantity: itemData.quantity,
                    unitPrice: itemData.unitPrice,
                    costType: 'جاری' // Defaulting this for now, could be passed from form.
                };
                invoiceItems.push(newInvoiceItem);
            });
        }
    });

    db.requests.set(requests);
    db.invoices.set(invoices);
    db.invoiceItems.set(invoiceItems);
    
    // TODO: Notify the next approver instead of the applicant
    addNotification({
        type: 'request',
        title: 'درخواست جدید ثبت شد',
        description: `درخواست شما با موضوع "${newRequest.subject}" ثبت و در جریان قرار گرفت.`,
        link: 'DASHBOARD',
        requestId: newRequest.id
    });

    return requests;
};

export const deleteRequest = (requestId: string): Request[] => {
    let requests = db.requests.get();
    let invoices = db.invoices.get();
    let invoiceItems = db.invoiceItems.get();

    const requestExists = requests.some(r => r.id === requestId);
    if (!requestExists) {
        throw new Error('Request not found');
    }

    const invoicesToDelete = invoices.filter(inv => inv.requestId === requestId);
    const invoicesToDeleteIds = new Set(invoicesToDelete.map(inv => inv.id));

    const updatedInvoiceItems = invoiceItems.filter(item => !invoicesToDeleteIds.has(item.invoiceId));
    db.invoiceItems.set(updatedInvoiceItems);
    
    const updatedInvoices = invoices.filter(inv => inv.requestId !== requestId);
    db.invoices.set(updatedInvoices);

    const updatedRequests = requests.filter(req => req.id !== requestId);
    db.requests.set(updatedRequests);

    return updatedRequests;
};

export const getRequestDetails = (requestId: string): RequestDetails => {
    const request = db.requests.get().find(r => r.id === requestId);
    if (!request) {
        throw new Error('Request not found');
    }

    const allInvoices = db.invoices.get();
    const allInvoiceItems = db.invoiceItems.get();
    const allUsers = db.systemUsers.get();
    const allUnits = db.orgUnits.get();
    const allProjects = db.projects.get();
    const allResources = db.financialResources.get();
    const allBeneficiaries = db.beneficiaries.get();
    const allRejections = db.rejections.get();
    const allConsultations = db.consultations.get();

    const userMapById = new Map<number, SystemUser>(allUsers.map(u => [u.id, u]));
    const unitMap = new Map<string, OrganizationalUnit>(allUnits.map(u => [u.id, u]));
    const projectMap = new Map<number, Project>(allProjects.map(p => [p.id, p]));
    const resourceMap = new Map<number, FinancialResource>(allResources.map(r => [r.id, r]));
    const beneficiaryMap = new Map<number, Beneficiary>(allBeneficiaries.map(b => [b.id, b]));

    const applicant = userMapById.get(request.originalApplicantId);
    const requestingUnit = applicant ? unitMap.get(applicant.unitId) : null;
    
    let creditSource = 'نامشخص';
    if (request.projectId) {
        const project = projectMap.get(request.projectId);
        if (project) {
            const resource = resourceMap.get(project.financialResourceId);
            creditSource = resource ? resource.name : 'تولیدی';
        }
    } else if (request.applicant === 'روح الله جهان پناه') {
        creditSource = 'تولیدی';
    }


    const requestInvoices = allInvoices
        .filter(inv => inv.requestId === requestId)
        .map(inv => {
            const items = allInvoiceItems.filter(item => item.invoiceId === inv.id);
            const beneficiary = beneficiaryMap.get(inv.beneficiaryId);
            return {
                ...inv,
                items: items,
                beneficiaryName: beneficiary?.fullName || 'نامشخص'
            };
        });
    
    const rejectionHistory = allRejections.filter(r => r.requestId === requestId);
    const consultations = allConsultations
        .filter(c => c.requestId === requestId)
        .map(c => ({
            ...c,
            fromUserName: userMapById.get(c.fromUserId)?.fullName || 'ناشناس',
            toUserName: userMapById.get(c.toUserId)?.fullName || 'ناشناس',
        }));

    // Hardcode workflow to match the image
    const workflow = {
        steps: [
            { name: 'تایید اولیه', status: (request.status === RequestStatus.Completed || request.status === RequestStatus.InProgress || request.status === RequestStatus.Pending) ? 'completed' as const : 'current' as const },
            { name: 'بررسی مدیر', status: request.status === RequestStatus.Completed ? 'completed' as const : (request.status === RequestStatus.InProgress || request.status === RequestStatus.Pending) ? 'current' as const : 'pending' as const },
            { name: 'تصویب', status: request.status === RequestStatus.Completed ? 'completed' as const : 'pending' as const },
        ],
        currentActionBy: request.status === RequestStatus.Completed ? 'تکمیل شده' : (userMapById.get(request.currentStepOwnerId)?.fullName || 'نامشخص')
    };


    return {
        ...request,
        requestingUnit: requestingUnit?.title || 'مدیریت مالی',
        creditSource,
        invoices: requestInvoices,
        workflow,
        rejectionHistory,
        consultations,
    };
};

export const approveRequestStep = (requestId: string): RequestDetails => {
    const requests = db.requests.get();
    const request = requests.find(r => r.id === requestId);
    if (!request) {
        throw new Error('Request not found to approve');
    }
    
    request.status = RequestStatus.Completed;
    request.lastModified = new Date().toISOString();

    // Deduct from project budget if applicable
    if (request.projectId) {
        const projects = db.projects.get();
        const projectIndex = projects.findIndex(p => p.id === request.projectId);
        if (projectIndex !== -1) {
            projects[projectIndex].spentAmount.rial += request.amount.rial;
            projects[projectIndex].spentAmount.usd += request.amount.usd;
            projects[projectIndex].spentAmount.eur += request.amount.eur;
            db.projects.set(projects);
        }
    }
    
    db.requests.set(requests);

    if (request.subject.includes('قرارداد') && request.contractId) {
        const payments = db.payments.get();
        const newPayment: Payment = {
            id: Date.now(),
            contractId: request.contractId,
            type: 'پیش پرداخت',
            date: new Date().toLocaleDateString('fa-IR'),
            amount: request.amount,
            description: `پرداخت خودکار از درخواست ${request.id}`,
            referenceNumber: request.id,
        };
        payments.push(newPayment);
        db.payments.set(payments);
    }
    
    addNotification({
        type: 'request',
        title: 'درخواست تایید نهایی شد',
        description: `درخواست "${request.subject}" با شماره ${request.id} تایید نهایی شد.`,
        link: 'DASHBOARD',
        requestId: request.id,
    });
    
    return getRequestDetails(requestId);
};

export const askForConsultation = (requestId: string, toUserIds: number[], question: string): RequestDetails => {
    const requests = db.requests.get();
    const request = requests.find(r => r.id === requestId);
    if (!request) {
        throw new Error('Request not found');
    }

    const consultations = db.consultations.get();
    const fromUserId = request.currentStepOwnerId;
    const fromUser = db.systemUsers.get().find(u => u.id === fromUserId);

    toUserIds.forEach(toUserId => {
        const newConsultation: Consultation = {
            id: Date.now() + Math.random(),
            requestId,
            fromUserId,
            toUserId,
            question,
            answer: null,
            status: 'pending',
            questionDate: new Date().toISOString(),
            answerDate: null,
        };
        consultations.push(newConsultation);
        addNotification({
            type: 'consultation',
            title: 'نظرخواهی جدید',
            description: `${fromUser?.fullName || 'کاربر'} در مورد درخواست "${request.subject}" از شما نظر خواسته است.`,
            link: 'DASHBOARD',
            requestId: requestId,
        });
    });

    db.consultations.set(consultations);

    const reqIndex = requests.findIndex(r => r.id === requestId);
    if (reqIndex > -1) {
        requests[reqIndex].isConsultation = true;
        requests[reqIndex].lastModified = new Date().toISOString();
        db.requests.set(requests);
    }

    return getRequestDetails(requestId);
};

export const answerConsultation = (consultationId: number, answer: string): RequestDetails => {
    const consultations = db.consultations.get();
    const consultation = consultations.find(c => c.id === consultationId);

    if (!consultation) {
        throw new Error('Consultation not found');
    }

    consultation.answer = answer;
    consultation.status = 'answered';
    consultation.answerDate = new Date().toISOString();

    db.consultations.set(consultations);

    const fromUser = db.systemUsers.get().find(u => u.id === consultation.fromUserId);
    const toUser = db.systemUsers.get().find(u => u.id === consultation.toUserId);
    const request = db.requests.get().find(r => r.id === consultation.requestId);

    addNotification({
        type: 'consultation',
        title: 'پاسخ نظرخواهی دریافت شد',
        description: `${toUser?.fullName || 'کاربر'} به نظرخواهی شما در مورد درخواست "${request?.subject}" پاسخ داد.`,
        link: 'DASHBOARD',
        requestId: consultation.requestId,
    });
    
    const requests = db.requests.get();
    const reqIndex = requests.findIndex(r => r.id === consultation.requestId);
    if (reqIndex > -1) {
        requests[reqIndex].lastModified = new Date().toISOString();
        const allConsultationsForRequest = consultations.filter(c => c.requestId === consultation.requestId);
        if (allConsultationsForRequest.every(c => c.status === 'answered')) {
            requests[reqIndex].isConsultation = false;
        }
        db.requests.set(requests);
    }

    return getRequestDetails(consultation.requestId);
};

export const rejectRequest = (requestId: string, reason: string): RequestDetails => {
    const requests = db.requests.get();
    const request = requests.find(r => r.id === requestId);
    if (!request) {
        throw new Error('Request not found to reject');
    }

    const rejecterId = request.currentStepOwnerId;
    
    request.status = RequestStatus.Rejected;
    request.currentStepOwnerId = request.originalApplicantId; // Send back to applicant
    request.lastModified = new Date().toISOString();
    db.requests.set(requests);

    const users = db.systemUsers.get();
    const rejecterUser = users.find(u => u.id === rejecterId);
    
    const details = getRequestDetails(requestId);
    const currentStep = details.workflow.steps.find(s => s.status === 'current');

    const newRejection: Rejection & { requestId: string } = {
        requestId,
        stepName: currentStep?.name || 'مرحله نامشخص',
        rejectedBy: rejecterUser?.fullName || 'کاربر ناشناس',
        reason,
        date: new Date().toISOString(),
    };
    
    const rejections = db.rejections.get();
    rejections.push(newRejection);
    db.rejections.set(rejections);

    addNotification({
        type: 'request',
        title: 'درخواست شما رد شد',
        description: `درخواست "${request.subject}" توسط ${rejecterUser?.fullName} رد شد و به شما بازگشت.`,
        link: 'DASHBOARD',
        requestId: requestId,
    });
    
    return getRequestDetails(requestId);
};

export const resubmitRequest = async (requestData: RequestDetails, invoicesData: any[]): Promise<Request[]> => {
    let requests = db.requests.get();
    const index = requests.findIndex(r => r.id === requestData.id);
    if (index === -1) {
        throw new Error('Request not found to resubmit');
    }

    const rejections = db.rejections.get().filter(rej => rej.requestId === requestData.id).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    const lastRejecterName = rejections.length > 0 ? rejections[0].rejectedBy : null;
    const users = db.systemUsers.get();
    const lastRejecterUser = lastRejecterName ? users.find(u => u.fullName === lastRejecterName) : null;
    
    const nextOwnerId = lastRejecterUser ? lastRejecterUser.id : 7;

    requests[index] = {
        ...requests[index],
        subject: requestData.subject,
        amount: requestData.amount,
        projectId: requestData.projectId,
        contractId: requestData.contractId,
        status: RequestStatus.Pending,
        currentStepOwnerId: nextOwnerId,
        lastModified: new Date().toISOString(),
    };
    
    db.requests.set(requests);
    
    const applicant = users.find(u => u.id === requestData.originalApplicantId);
    
    addNotification({
        type: 'request',
        title: 'درخواست بروزرسانی شد',
        description: `درخواست رد شده "${requestData.subject}" توسط ${applicant?.fullName} ویرایش و مجددا برای شما ارسال شد.`,
        link: 'DASHBOARD',
        requestId: requestData.id,
    });
    
    return requests;
};