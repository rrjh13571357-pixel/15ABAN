
import type { FinancialResource } from '../../shared/types';
import { db } from '../db';

export const getFinancialResources = (): FinancialResource[] => {
    return db.financialResources.get();
};

export const addFinancialResource = (resource: Omit<FinancialResource, 'id'>): FinancialResource[] => {
    const resources = db.financialResources.get();
    const newResource: FinancialResource = {
        ...resource,
        id: Date.now(),
    };
    resources.push(newResource);
    db.financialResources.set(resources);
    return resources;
};

export const updateFinancialResource = (resource: FinancialResource): FinancialResource[] => {
    let resources = db.financialResources.get();
    const index = resources.findIndex(r => r.id === resource.id);
    if (index !== -1) {
        resources[index] = resource;
        db.financialResources.set(resources);
        return resources;
    }
    throw new Error('FinancialResource not found');
};

export const deleteFinancialResource = (resourceId: number): FinancialResource[] => {
    const projects = db.projects.get();
    if (projects.some(p => p.financialResourceId === resourceId)) {
        throw new Error('Cannot delete financial resource: It is currently assigned to one or more projects.');
    }

    let resources = db.financialResources.get();
    const updatedResources = resources.filter(r => r.id !== resourceId);
    if (resources.length === updatedResources.length) {
        throw new Error('FinancialResource not found');
    }
    db.financialResources.set(updatedResources);
    return updatedResources;
};