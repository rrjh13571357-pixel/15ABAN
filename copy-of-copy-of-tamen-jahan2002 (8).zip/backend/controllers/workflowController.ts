
import type { RequestType, Workflow } from '../../shared/types';
import { db } from '../db';

export const getRequestTypes = (): RequestType[] => {
    return db.requestTypes.get();
};

export const addRequestType = (requestType: Omit<RequestType, 'id'>): RequestType[] => {
    const types = db.requestTypes.get();
    const newType: RequestType = { ...requestType, id: Date.now() };
    types.push(newType);
    db.requestTypes.set(types);
    return types;
};

export const updateRequestType = (requestType: RequestType): RequestType[] => {
    let types = db.requestTypes.get();
    const index = types.findIndex(t => t.id === requestType.id);
    if (index !== -1) {
        types[index] = requestType;
        db.requestTypes.set(types);
        return types;
    }
    throw new Error('RequestType not found');
};

export const deleteRequestType = (requestTypeId: number): RequestType[] => {
    let types = db.requestTypes.get();
    const updatedTypes = types.filter(t => t.id !== requestTypeId);
    if (types.length === updatedTypes.length) {
       throw new Error('RequestType not found');
    }
    db.requestTypes.set(updatedTypes);
    return updatedTypes;
};


export const getWorkflows = (): Workflow[] => {
    return db.workflows.get();
};

export const addWorkflow = (workflow: Omit<Workflow, 'id'>): Workflow[] => {
    const workflows = db.workflows.get();
    const newWorkflow: Workflow = { ...workflow, id: Date.now() };
    workflows.push(newWorkflow);
    db.workflows.set(workflows);
    return workflows;
};

export const updateWorkflow = (workflow: Workflow): Workflow[] => {
    let workflows = db.workflows.get();
    const index = workflows.findIndex(w => w.id === workflow.id);
    if (index !== -1) {
        workflows[index] = workflow;
        db.workflows.set(workflows);
        return workflows;
    }
    throw new Error('Workflow not found');
};

export const deleteWorkflow = (workflowId: number): Workflow[] => {
    let workflows = db.workflows.get();
    const updatedWorkflows = workflows.filter(w => w.id !== workflowId);
    if (workflows.length === updatedWorkflows.length) {
        throw new Error('Workflow not found');
    }
    db.workflows.set(updatedWorkflows);
    return updatedWorkflows;
};