
import type { BankAccount } from '../../shared/types';
import { db } from '../db';

export const getBankAccounts = (): BankAccount[] => {
    return db.bankAccounts.get();
};

export const addBankAccount = (account: Omit<BankAccount, 'id'>): BankAccount[] => {
    const accounts = db.bankAccounts.get();
    const newAccount: BankAccount = {
        ...account,
        id: Date.now(),
    };
    accounts.push(newAccount);
    db.bankAccounts.set(accounts);
    return accounts;
};

export const updateBankAccount = (account: BankAccount): BankAccount[] => {
    let accounts = db.bankAccounts.get();
    const index = accounts.findIndex(acc => acc.id === account.id);
    if (index !== -1) {
        accounts[index] = account;
        db.bankAccounts.set(accounts);
        return accounts;
    }
    throw new Error('BankAccount not found');
};

export const deleteBankAccount = (accountId: number): BankAccount[] => {
    let accounts = db.bankAccounts.get();
    const updatedAccounts = accounts.filter(acc => acc.id !== accountId);
    if (accounts.length === updatedAccounts.length) {
       throw new Error('BankAccount not found');
    }
    db.bankAccounts.set(updatedAccounts);
    return updatedAccounts;
};