

import type { Project, CurrencyAmount, FundInjection } from '../../shared/types';
import { db } from '../db';

export const getProjects = (): Project[] => {
    return db.projects.get();
};

export const addProject = (project: Omit<Project, 'id'>): Project[] => {
    const projects = db.projects.get();
    const newProject: Project = {
        ...project,
        id: Date.now(),
    };
    projects.push(newProject);
    db.projects.set(projects);
    return projects;
};

export const updateProject = (project: Project): Project[] => {
    let projects = db.projects.get();
    const index = projects.findIndex(p => p.id === project.id);
    if (index !== -1) {
        // Only update editable fields, keep spentAmount as is
        projects[index] = {
            ...projects[index], // keeps original spentAmount
            name: project.name,
            orgUnitId: project.orgUnitId,
            startDate: project.startDate,
            financialResourceId: project.financialResourceId,
            budget: project.budget,
        };
        db.projects.set(projects);
        return projects;
    }
    throw new Error('Project not found');
};

export const deleteProject = (projectId: number): Project[] => {
    const requests = db.requests.get();
    if(requests.some(r => r.projectId === projectId)) {
        throw new Error('Cannot delete project: It is linked to one or more requests.');
    }

    let projects = db.projects.get();
    const updatedProjects = projects.filter(p => p.id !== projectId);
    if (projects.length === updatedProjects.length) {
        throw new Error('Project not found');
    }
    db.projects.set(updatedProjects);
    return updatedProjects;
};

export const injectFunds = (projectId: number, amount: CurrencyAmount, allocationNumber: string, allocationDate: string, financialResourceId: number): Project[] => {
    let projects = db.projects.get();
    const index = projects.findIndex(p => p.id === projectId);
    if (index !== -1) {
        projects[index].budget.rial += amount.rial;
        projects[index].budget.usd += amount.usd;
        projects[index].budget.eur += amount.eur;
        db.projects.set(projects);
        
        // Create a record for the injection
        const fundInjections = db.fundInjections.get();
        const newInjection: FundInjection = {
            id: Date.now(),
            projectId,
            amount,
            allocationNumber,
            allocationDate,
            financialResourceId,
        };
        fundInjections.push(newInjection);
        db.fundInjections.set(fundInjections);

        return projects;
    }
    throw new Error('Project not found for injection');
};

export const transferFunds = (fromProjectId: number, toProjectId: number, amount: CurrencyAmount): Project[] => {
    let projects = db.projects.get();
    const fromIndex = projects.findIndex(p => p.id === fromProjectId);
    const toIndex = projects.findIndex(p => p.id === toProjectId);

    if (fromIndex !== -1 && toIndex !== -1) {
        const fromProject = projects[fromIndex];

        // Check for sufficient funds
        if (
            (fromProject.budget.rial - fromProject.spentAmount.rial) < amount.rial ||
            (fromProject.budget.usd - fromProject.spentAmount.usd) < amount.usd ||
            (fromProject.budget.eur - fromProject.spentAmount.eur) < amount.eur
        ) {
            throw new Error('Insufficient funds for transfer');
        }

        // Deduct from sender (as spent) and add to receiver (as budget)
        fromProject.spentAmount.rial += amount.rial;
        fromProject.spentAmount.usd += amount.usd;
        fromProject.spentAmount.eur += amount.eur;

        const toProject = projects[toIndex];
        toProject.budget.rial += amount.rial;
        toProject.budget.usd += amount.usd;
        toProject.budget.eur += amount.eur;

        db.projects.set(projects);
        return projects;
    }
    throw new Error('One or both projects not found for transfer');
};