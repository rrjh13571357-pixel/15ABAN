
import type { OrganizationalUnit } from '../../shared/types';
import { db } from '../db';

export const getOrgUnits = (): OrganizationalUnit[] => {
    return db.orgUnits.get();
};

export const addOrgUnit = (unit: Omit<OrganizationalUnit, 'id'>): OrganizationalUnit[] => {
    const units = db.orgUnits.get();
    const newUnit: OrganizationalUnit = {
        ...unit,
        id: Date.now().toString(),
    };
    units.push(newUnit);
    db.orgUnits.set(units);
    return units;
};

export const updateOrgUnit = (unit: OrganizationalUnit): OrganizationalUnit[] => {
    let units = db.orgUnits.get();
    const index = units.findIndex(u => u.id === unit.id);
    if (index !== -1) {
        units[index] = unit;
        db.orgUnits.set(units);
        return units;
    }
    throw new Error('Unit not found');
};

export const deleteOrgUnit = (unitId: string): OrganizationalUnit[] => {
    const users = db.systemUsers.get();
    if (users.some(u => u.unitId === unitId)) {
        throw new Error('Cannot delete unit: It has users assigned to it.');
    }
    const projects = db.projects.get();
    if (projects.some(p => p.orgUnitId === unitId)) {
        throw new Error('Cannot delete unit: It has projects assigned to it.');
    }
    const pettyCashHolders = db.pettyCashHolders.get();
    if (pettyCashHolders.some(p => p.associatedCenterId === unitId)) {
        throw new Error('Cannot delete unit: It is linked to petty cash holders.');
    }

    let units = db.orgUnits.get();
    const updatedUnits = units.filter(u => u.id !== unitId);
    if (units.length === updatedUnits.length) {
        throw new Error('Unit not found');
    }
    db.orgUnits.set(updatedUnits);
    return updatedUnits;
};