
import { db } from '../db';
import type { Payroll, PayrollDetails, SystemUser } from '../../shared/types';

export const getPayrolls = (): Payroll[] => {
    return db.payrolls.get().sort((a, b) => b.id - a.id);
};

export const getPayrollDetails = (payrollId: number): PayrollDetails => {
    const payroll = db.payrolls.get().find(p => p.id === payrollId);
    if (!payroll) {
        throw new Error('Payroll not found');
    }

    const allItems = db.payrollItems.get();
    const allUsers = db.systemUsers.get();
    const userMap = new Map<number, SystemUser>(allUsers.map(u => [u.id, u]));

    const itemsForPayroll = allItems
        .filter(item => item.payrollId === payrollId)
        .map(item => {
            const employee = userMap.get(item.employeeId);
            return {
                ...item,
                employeeName: employee?.fullName || 'کاربر حذف شده',
                nationalCode: employee?.nationalCode || '---'
            };
        });

    return {
        ...payroll,
        items: itemsForPayroll
    };
};