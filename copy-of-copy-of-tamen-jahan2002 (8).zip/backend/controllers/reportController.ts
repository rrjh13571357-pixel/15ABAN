

import { db } from '../db';
import { ProjectFinancialSummary, StatusDistribution, MonthlyRequestVolume, ContractStatus, InvoiceItemExplorerResult, RequestStatus } from '../../shared/types';


export const getProjectFinancialSummary = (): ProjectFinancialSummary => {
    const projects = db.projects.get();
    const sortedProjects = [...projects]
        .sort((a, b) => b.budget.rial - a.budget.rial)
        .slice(0, 5);

    return {
        labels: sortedProjects.map(p => p.name),
        datasets: [
            {
                label: 'بودجه کل',
                data: sortedProjects.map(p => p.budget.rial),
                backgroundColor: 'rgba(54, 162, 235, 0.6)', // blue
            },
            {
                label: 'مبلغ هزینه شده',
                data: sortedProjects.map(p => p.spentAmount.rial),
                backgroundColor: 'rgba(255, 99, 132, 0.6)', // red
            }
        ]
    };
};

export const getStatusDistribution = (): StatusDistribution => {
    const contracts = db.contracts.get();
    const distribution = {
        [ContractStatus.Active]: 0,
        [ContractStatus.Pending]: 0,
        [ContractStatus.Archived]: 0,
    };

    contracts.forEach(c => {
        if (distribution[c.status] !== undefined) {
            distribution[c.status]++;
        }
    });

    return {
        labels: Object.keys(distribution),
        datasets: [{
            data: Object.values(distribution),
            backgroundColor: [
                'rgba(75, 192, 192, 0.6)', // green for active
                'rgba(255, 206, 86, 0.6)', // yellow for pending
                'rgba(201, 203, 207, 0.6)', // gray for archived
            ]
        }]
    };
};

export const getMonthlyRequestVolume = (): MonthlyRequestVolume => {
    // The mock data's date format is not standard. We will simulate data for the chart.
    const monthLabels: string[] = [];
    for (let i = 5; i >= 0; i--) {
        const d = new Date();
        d.setMonth(d.getMonth() - i);
        const month = new Intl.DateTimeFormat('fa-IR', { month: 'long' }).format(d);
        monthLabels.push(month);
    }
    
    const dummyData = [12, 19, 3, 5, 2, 8];

    return {
        labels: monthLabels,
        datasets: [{
            label: 'تعداد درخواست‌ها',
            data: dummyData,
            borderColor: 'rgba(255, 99, 132, 1)',
            tension: 0.1,
        }]
    };
};

export const searchInvoiceItems = (filters: any): InvoiceItemExplorerResult[] => {
    const allItems = db.invoiceItems.get();
    const allInvoices = db.invoices.get();
    const allRequests = db.requests.get();
    const allBeneficiaries = db.beneficiaries.get();
    const allUsers = db.systemUsers.get();
    const allUnits = db.orgUnits.get();
    const allProjects = db.projects.get();
    
    const invoiceMap = new Map(allInvoices.map(i => [i.id, i]));
    const requestMap = new Map(allRequests.map(r => [r.id, r]));
    const beneficiaryMap = new Map(allBeneficiaries.map(b => [b.id, b]));
    const userMap = new Map(allUsers.map(u => [u.id, u]));
    const unitMap = new Map(allUnits.map(u => [u.id, u]));
    const projectMap = new Map(allProjects.map(p => [p.id, p]));

    const results: InvoiceItemExplorerResult[] = allItems.map(item => {
        const invoice = invoiceMap.get(item.invoiceId);
        if (!invoice) return null;

        const request = requestMap.get(invoice.requestId);
        if (!request) return null;

        const beneficiary = beneficiaryMap.get(invoice.beneficiaryId);
        const applicant = userMap.get(request.originalApplicantId);
        const requestingUnit = applicant ? unitMap.get(applicant.unitId) : null;
        const project = request.projectId ? projectMap.get(request.projectId) : null;
        
        return {
            id: item.id,
            description: item.description,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            totalPrice: item.quantity * item.unitPrice,
            beneficiaryName: beneficiary?.fullName || '---',
            requestingUnitName: requestingUnit?.title || '---',
            requestDate: request.date,
            requestNumber: request.id,
            projectName: project?.name || '---',
            requestStatus: request.status,
        };
    }).filter((item): item is InvoiceItemExplorerResult => item !== null);
    
    // Apply filters
    return results.filter(item => {
        const descMatch = !filters.description || item.description.toLowerCase().includes(filters.description.toLowerCase());
        
        const request = requestMap.get(item.requestNumber);
        const applicant = request ? userMap.get(request.originalApplicantId) : undefined;
        const unitId = applicant ? applicant.unitId : null;
        const unitMatch = !filters.requestingUnitId || filters.requestingUnitId === 'all' || unitId === filters.requestingUnitId;
        
        const invoice = allInvoices.find(i => i.requestId === item.requestNumber);
        const beneficiaryId = invoice ? invoice.beneficiaryId : null;
        const beneficiaryMatch = !filters.beneficiaryId || filters.beneficiaryId === 'all' || beneficiaryId === Number(filters.beneficiaryId);
        
        const statusMatch = !filters.requestStatus || filters.requestStatus === 'all' || item.requestStatus === filters.requestStatus;
        
        return descMatch && unitMatch && beneficiaryMatch && statusMatch;
    });
};