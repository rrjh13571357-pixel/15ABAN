import type { SystemUser, Beneficiary, PettyCashHolder, Role } from '../../shared/types';
import { db } from '../db';

// --- Login ---
export const login = (username: string, password: string): { token: string; user: Omit<SystemUser, 'password'> } => {
    const users = db.systemUsers.get();
    const user = users.find(u => u.username?.toLowerCase() === username.toLowerCase());

    if (!user) {
        throw new Error('نام کاربری یا رمز عبور اشتباه است.');
    }

    if (user.status === 'inactive') {
        throw new Error('حساب کاربری شما غیرفعال است.');
    }
    
    // In a real app, this would be a hash comparison
    if (user.password !== password) {
         throw new Error('نام کاربری یا رمز عبور اشتباه است.');
    }
    
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password: _, ...userToReturn } = user;
    // In a real app, the token would be a JWT.
    return { token: `mock-token-for-${user.id}`, user: userToReturn };
};


// --- System Users ---
export const getSystemUsers = (): SystemUser[] => {
    return db.systemUsers.get();
};

export const addSystemUser = (user: Omit<SystemUser, 'id'>): SystemUser[] => {
    const users = db.systemUsers.get();
    const newUser: SystemUser = { 
        ...user, 
        id: Date.now(),
        username: null,
        status: 'active',
        forcePasswordChange: true,
        passwordNeverExpires: false,
     };
    users.push(newUser);
    db.systemUsers.set(users);
    return users;
};

export const updateSystemUser = (user: SystemUser): SystemUser[] => {
    let users = db.systemUsers.get();
    const index = users.findIndex(u => u.id === user.id);
    if (index !== -1) {
        // If password field is present and not empty, it means a reset is requested.
        // Otherwise, keep the old password hash.
        const password = user.password ? user.password : users[index].password;
        users[index] = {
            ...users[index],
            ...user,
            password,
        };
        db.systemUsers.set(users);
        return users;
    }
    throw new Error('SystemUser not found');
};

export const defineSystemUser = (userId: number, definition: Partial<SystemUser>): SystemUser[] => {
    const users = db.systemUsers.get();
    
    // Check for unique username
    if (definition.username && users.some(u => u.username === definition.username && u.id !== userId)) {
        throw new Error(`شناسه کاربری '${definition.username}' تکراری است.`);
    }

    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex === -1) {
        throw new Error('کاربر مورد نظر یافت نشد.');
    }
    
    // Update user
    const updatedUser = { ...users[userIndex], ...definition };
    users[userIndex] = updatedUser;
    
    db.systemUsers.set(users);
    return users;
};

/**
 * Deletes a user's access by nullifying their username and setting their status to inactive.
 * This is a "soft delete" to preserve historical data associated with the user.
 * The user record itself is not removed from the database.
 * @param userId The ID of the user to deactivate.
 * @returns The updated list of all system users.
 */
export const deleteSystemUser = (userId: number): SystemUser[] => {
    let users = db.systemUsers.get();
    const index = users.findIndex(u => u.id === userId);
    if (index !== -1) {
        users[index].username = null;
        users[index].status = 'inactive';
        db.systemUsers.set(users);
        return users;
    }
    throw new Error('SystemUser not found to delete access.');
};


// --- Beneficiaries ---
export const getBeneficiaries = (): Beneficiary[] => {
    return db.beneficiaries.get();
};

export const addBeneficiary = (beneficiary: Omit<Beneficiary, 'id'>): Beneficiary[] => {
    const beneficiaries = db.beneficiaries.get();
    const newBeneficiary: Beneficiary = { ...beneficiary, id: Date.now() };
    beneficiaries.push(newBeneficiary);
    db.beneficiaries.set(beneficiaries);
    return beneficiaries;
};

export const updateBeneficiary = (beneficiary: Beneficiary): Beneficiary[] => {
    let beneficiaries = db.beneficiaries.get();
    const index = beneficiaries.findIndex(b => b.id === beneficiary.id);
    if (index !== -1) {
        beneficiaries[index] = beneficiary;
        db.beneficiaries.set(beneficiaries);
        return beneficiaries;
    }
    throw new Error('Beneficiary not found');
};

export const deleteBeneficiary = (beneficiaryId: number): Beneficiary[] => {
    const bankAccounts = db.bankAccounts.get();
    if(bankAccounts.some(acc => acc.ownerId === beneficiaryId && acc.ownerType === 'beneficiary')) {
        throw new Error('Cannot delete beneficiary: They are linked to one or more bank accounts.');
    }

    let beneficiaries = db.beneficiaries.get();
    const updatedBeneficiaries = beneficiaries.filter(b => b.id !== beneficiaryId);
    if (beneficiaries.length === updatedBeneficiaries.length) {
       throw new Error('Beneficiary not found');
    }
    db.beneficiaries.set(updatedBeneficiaries);
    return updatedBeneficiaries;
};

// --- Petty Cash Holders ---
export const getPettyCashHolders = (): PettyCashHolder[] => {
    return db.pettyCashHolders.get();
};

export const addPettyCashHolder = (holder: Omit<PettyCashHolder, 'id'>): PettyCashHolder[] => {
    const holders = db.pettyCashHolders.get();
    const newHolder: PettyCashHolder = { ...holder, id: Date.now(), pettyCashLimit: 0 };
    holders.push(newHolder);
    db.pettyCashHolders.set(holders);
    return holders;
};

export const updatePettyCashHolder = (holder: PettyCashHolder): PettyCashHolder[] => {
    let holders = db.pettyCashHolders.get();
    const index = holders.findIndex(h => h.id === holder.id);
    if (index !== -1) {
        holders[index] = holder;
        db.pettyCashHolders.set(holders);
        return holders;
    }
    throw new Error('PettyCashHolder not found');
};

export const deletePettyCashHolder = (holderId: number): PettyCashHolder[] => {
    const bankAccounts = db.bankAccounts.get();
    if(bankAccounts.some(acc => acc.ownerId === holderId && acc.ownerType === 'pettyCash')) {
        throw new Error('Cannot delete petty cash holder: They are linked to one or more bank accounts.');
    }

    let holders = db.pettyCashHolders.get();
    const updatedHolders = holders.filter(h => h.id !== holderId);
    if (holders.length === updatedHolders.length) {
       throw new Error('PettyCashHolder not found');
    }
    db.pettyCashHolders.set(updatedHolders);
    return updatedHolders;
};

export const updateAllPettyCashLimits = (limit: number): PettyCashHolder[] => {
    let holders = db.pettyCashHolders.get();
    holders = holders.map(h => ({ ...h, pettyCashLimit: limit }));
    db.pettyCashHolders.set(holders);
    return holders;
};


// --- Roles ---
export const getRoles = (): Role[] => {
    return db.roles.get();
};

export const addRole = (role: Omit<Role, 'id'>): Role[] => {
    const roles = db.roles.get();
    const newRole: Role = {
        ...role,
        id: Date.now(),
        userCount: role.userCount || 0,
        status: role.status || 'فعال'
    };
    roles.push(newRole);
    db.roles.set(roles);
    // FIX: A function whose declared type is neither 'undefined', 'void', nor 'any' must return a value.
    return roles;
};

export const updateRole = (role: Role): Role[] => {
    let roles = db.roles.get();
    const index = roles.findIndex(r => r.id === role.id);
    if (index !== -1) {
        roles[index] = role;
        db.roles.set(roles);
        return roles;
    }
    throw new Error('Role not found');
};

export const deleteRole = (roleId: number): Role[] => {
    let roles = db.roles.get();
    const updatedRoles = roles.filter(r => r.id !== roleId);
    if (roles.length === updatedRoles.length) {
       throw new Error('Role not found');
    }
    db.roles.set(updatedRoles);
    return updatedRoles;
};