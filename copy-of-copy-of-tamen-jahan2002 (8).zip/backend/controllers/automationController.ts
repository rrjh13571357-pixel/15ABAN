

import { db } from '../db';
import type { Letter, InboxLetter, SystemUser, LetterTemplate, LetterAttachment } from '../../shared/types';
import { LetterStatus, LetterPriority } from '../../shared/types';

export const getInboxLetters = (userId: number): InboxLetter[] => {
    const letters = db.letters.get();
    const users = db.systemUsers.get();
    const userMap = new Map<number, SystemUser>(users.map(u => [u.id, u]));

    const inbox = letters
        .filter(letter => letter.recipientIds.includes(userId))
        .map(letter => {
            const sender = userMap.get(letter.senderId);
            return {
                id: letter.id,
                subject: letter.subject,
                senderName: sender ? sender.fullName : 'ناشناس',
                sentDate: letter.sentDate,
                priority: letter.priority,
                status: letter.status[userId] || LetterStatus.Unread,
                hasAttachment: (letter.attachments || []).length > 0,
            };
        });

    return inbox.sort((a, b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime());
};

export const getLetterDetails = (letterId: number, userId: number): Letter & { senderName: string, recipientNames: string[], senderUnitName: string, recipientUnitName: string, signatory: { name: string, title: string } } => {
    const letters = db.letters.get();
    const letter = letters.find(l => l.id === letterId);

    if (!letter || !(letter.recipientIds.includes(userId) || letter.senderId === userId)) {
        throw new Error('Letter not found or access denied');
    }
    
    if (letter.recipientIds.includes(userId)) {
        letter.status[userId] = LetterStatus.Read;
        db.letters.set(letters);
    }

    const users = db.systemUsers.get();
    const userMap = new Map<number, SystemUser>(users.map(u => [u.id, u]));
    
    const orgUnits = db.orgUnits.get();
    const orgUnitMap = new Map(orgUnits.map(u => [u.id, u.title]));
    
    const roles = db.roles.get();
    const roleMap = new Map(roles.map(r => [r.id, r.title]));

    const sender = userMap.get(letter.senderId);
    const recipients = letter.recipientIds.map(id => userMap.get(id)?.fullName || 'ناشناس');
    const signatoryUser = userMap.get(letter.signatoryId);
    const signatory = {
        name: signatoryUser?.fullName || 'ناشناس',
        title: signatoryUser ? (roleMap.get(signatoryUser.roleId) || '') : ''
    }

    return {
        ...letter,
        senderName: sender ? sender.fullName : 'ناشناس',
        recipientNames: recipients,
        senderUnitName: orgUnitMap.get(letter.senderUnitId) || 'نامشخص',
        recipientUnitName: orgUnitMap.get(letter.recipientUnitId) || 'نامشخص',
        signatory,
    };
};

export const sendLetter = (data: { 
    subject: string, 
    content: string, 
    recipientIds: number[], 
    priority: LetterPriority,
    letterDate: string,
    senderUnitId: string,
    recipientUnitId: string,
    signatoryId: number,
    attachments: Omit<LetterAttachment, 'id'>[],
}): Letter[] => {
    const letters = db.letters.get();
    const senderId = 6; // Hardcoded current user "مدیر سیستم"

    const newLetter: Letter = {
        id: Date.now(),
        subject: data.subject,
        content: data.content,
        senderId: senderId,
        recipientIds: data.recipientIds,
        sentDate: new Date().toISOString(),
        priority: data.priority,
        status: data.recipientIds.reduce((acc, recipientId) => {
            acc[recipientId] = LetterStatus.Unread;
            return acc;
        }, {} as Record<number, LetterStatus>),
        letterDate: data.letterDate,
        senderUnitId: data.senderUnitId,
        recipientUnitId: data.recipientUnitId,
        signatoryId: data.signatoryId,
        attachments: data.attachments.map(att => ({ ...att, id: Date.now() + Math.random() })),
    };

    letters.unshift(newLetter);
    db.letters.set(letters);
    return letters;
}

// --- Letter Templates ---

export const getLetterTemplates = (): LetterTemplate[] => {
    return db.letterTemplates.get();
};

export const addLetterTemplate = (template: Omit<LetterTemplate, 'id'>): LetterTemplate[] => {
    const templates = db.letterTemplates.get();
    const newTemplate: LetterTemplate = { ...template, id: Date.now() };
    templates.push(newTemplate);
    db.letterTemplates.set(templates);
    return templates;
};

export const deleteLetterTemplate = (templateId: number): LetterTemplate[] => {
    let templates = db.letterTemplates.get();
    const updatedTemplates = templates.filter(t => t.id !== templateId);
    if (templates.length === updatedTemplates.length) {
       throw new Error('LetterTemplate not found');
    }
    db.letterTemplates.set(updatedTemplates);
    return updatedTemplates;
};