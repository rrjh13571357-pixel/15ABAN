
import * as projectController from './projectController';
import * as contractController from './contractController';
import * as identityController from './identityController';
import { ContractStatus, Project, Contract, TemplatedQuery } from '../../shared/types';

const initialTemplatedQueries: TemplatedQuery[] = [
    {
        id: 'project_full_analysis',
        displayText: 'تحلیل کامل یک پروژه...',
        template: 'تحلیل کامل پروژه {{entity}}',
        entityType: 'project',
        description: 'اطلاعات کامل یک پروژه شامل بودجه، هزینه‌ها و مانده را نمایش می‌دهد.',
        command: 'project_full_analysis',
    },
    {
        id: 'contract_status_check',
        displayText: 'بررسی وضعیت یک قرارداد...',
        template: 'وضعیت قرارداد {{entity}} چیست؟',
        entityType: 'contract',
        description: 'وضعیت فعلی (فعال، در حال بررسی، آرشیو شده) یک قرارداد را برمی‌گرداند.',
        command: 'contract_status_check',
    },
];

export const getTemplates = (): TemplatedQuery[] => {
    return initialTemplatedQueries;
};


// --- Entity Extraction ---
const extractEntity = (question: string, entities: {id: any, name: string}[] | {id: any, title: string}[] | {id: any, party: string}[]): {id: any, name: string} | null => {
    const q = question.toLowerCase();
    for (const entity of entities) {
        const entityName = 'name' in entity ? entity.name : ('title' in entity ? entity.title : entity.party);
        if (q.includes(entityName.toLowerCase())) {
            return { id: entity.id, name: entityName };
        }
    }
    return null;
};


// --- Intent Recognition ---
const getIntent = (question: string): { intent: string; params: any } => {
    const q = question.toLowerCase();

    // --- Specific Entity Intents (must come first) ---
    if (q.includes('بودجه') && q.includes('پروژه')) {
        const projects = projectController.getProjects();
        const projectEntity = extractEntity(question, projects);
        if(projectEntity) {
            return { intent: 'GET_PROJECT_BUDGET', params: { projectId: projectEntity.id, projectName: projectEntity.name } };
        }
    }
    
    if (q.includes('آخرین') && q.includes('قرارداد')) {
        const contracts = contractController.getContractList();
        const contractPartyEntity = extractEntity(question, contracts);
        if(contractPartyEntity) {
            return { intent: 'GET_LAST_CONTRACT_WITH_PARTY', params: { partyName: contractPartyEntity.name } };
        }
    }


    // --- General List/Sort Intents ---
    if (q.includes('پروژه') && (q.includes('بیشترین') || q.includes('بالاترین')) && q.includes('بودجه')) {
        return { intent: 'GET_PROJECTS_BY_BUDGET', params: { sort: 'desc' } };
    }
    if (q.includes('پروژه') && (q.includes('کمترین') || q.includes('پایین‌ترین')) && q.includes('بودجه')) {
        return { intent: 'GET_PROJECTS_BY_BUDGET', params: { sort: 'asc' } };
    }
    if (q.includes('پروژه') && (q.includes('خارج از بودجه') || q.includes('کسری') || q.includes('بیشتر از بودجه'))) {
        return { intent: 'GET_OVER_BUDGET_PROJECTS', params: {} };
    }
     if (q.includes('تعداد') && q.includes('پروژه')) {
        return { intent: 'COUNT_PROJECTS', params: {} };
    }
     if (q.includes('لیست') && q.includes('پروژه')) {
        return { intent: 'LIST_PROJECTS', params: {} };
    }

    if ((q.includes('قرارداد') || q.includes('قراردادهای')) && (q.includes('فعال'))) {
        return { intent: 'GET_CONTRACTS_BY_STATUS', params: { status: ContractStatus.Active } };
    }
    if ((q.includes('قرارداد') || q.includes('قراردادهای')) && (q.includes('در دست بررسی') || q.includes('منتظر'))) {
        return { intent: 'GET_CONTRACTS_BY_STATUS', params: { status: ContractStatus.Pending } };
    }
    if ((q.includes('قرارداد') || q.includes('قراردادهای')) && (q.includes('آرشیو'))) {
        return { intent: 'GET_CONTRACTS_BY_STATUS', params: { status: ContractStatus.Archived } };
    }
    if (q.includes('تعداد') && q.includes('قرارداد')) {
        const statusMatch = q.match(/فعال|در دست بررسی|آرشیو/);
        const status = statusMatch ? statusMatch[0] as ContractStatus : 'all';
        return { intent: 'COUNT_CONTRACTS', params: { status } };
    }

    if (q.includes('تعداد') && (q.includes('کاربر') || q.includes('کاربران'))) {
        return { intent: 'COUNT_SYSTEM_USERS', params: {} };
    }
    if (q.includes('لیست') && (q.includes('کاربر') || q.includes('کاربران'))) {
        return { intent: 'LIST_SYSTEM_USERS', params: {} };
    }

    if (q.includes('سلام') || q.includes('وقت بخیر') || q.includes('چطوری')) {
        return { intent: 'GREETING', params: {} };
    }

    return { intent: 'UNKNOWN', params: {} };
};

// --- Response Generation ---
export const getAnalysis = (question: string): string => {
    const { intent, params } = getIntent(question);

    try {
        switch (intent) {
            case 'GREETING':
                return 'سلام! من آماده‌ام تا به سوالات شما درباره داده‌های سیستم پاسخ دهم.';
            
            case 'GET_PROJECT_BUDGET': {
                const project = projectController.getProjects().find(p => p.id === params.projectId);
                if (!project) return `متاسفانه پروژه‌ای با نام "${params.projectName}" یافت نشد.`;
                let response = `بودجه پروژه "${params.projectName}":\n\n`;
                response += `- ریال: ${project.budget.rial.toLocaleString()}\n`;
                response += `- دلار: ${project.budget.usd.toLocaleString()}\n`;
                response += `- یورو: ${project.budget.eur.toLocaleString()}`;
                return response;
            }

            case 'GET_LAST_CONTRACT_WITH_PARTY': {
                const contracts = contractController.getContractList();
                const partyContracts = contracts.filter(c => c.party === params.partyName);
                if (partyContracts.length === 0) return `هیچ قراردادی با طرف قرارداد "${params.partyName}" یافت نشد.`;
                
                // Assuming latest is the one with highest ID (most recent)
                const lastContract = partyContracts.sort((a,b) => b.id - a.id)[0];

                return `آخرین قرارداد با "${params.partyName}"، قرارداد "${lastContract.title}" به شماره ${lastContract.contractNumber} است که در تاریخ ${lastContract.endDate} به پایان می‌رسد.`;
            }

            case 'GET_PROJECTS_BY_BUDGET': {
                const projects = projectController.getProjects();
                const sortedProjects = [...projects].sort((a, b) => {
                    if (params.sort === 'desc') return b.budget.rial - a.budget.rial;
                    return a.budget.rial - b.budget.rial;
                });
                const topProjects = sortedProjects.slice(0, 3);
                if (topProjects.length === 0) return 'در حال حاضر هیچ پروژه‌ای در سیستم ثبت نشده است.';
                
                let response = `لیست ${topProjects.length} پروژه با ${params.sort === 'desc' ? 'بیشترین' : 'کمترین'} بودجه ریالی:\n\n`;
                topProjects.forEach((p, i) => {
                    response += `${i + 1}. ${p.name} - بودجه: ${p.budget.rial.toLocaleString()} ریال\n`;
                });
                return response;
            }
            
            case 'GET_OVER_BUDGET_PROJECTS': {
                const projects = projectController.getProjects();
                const overBudgetProjects = projects.filter(p => p.spentAmount.rial > p.budget.rial);

                if (overBudgetProjects.length === 0) {
                    return 'خوشبختانه هیچ پروژه‌ای خارج از بودجه مصوب ریالی خود نیست.';
                }

                let response = `تعداد ${overBudgetProjects.length} پروژه خارج از بودجه ریالی یافت شد:\n\n`;
                overBudgetProjects.forEach((p, i) => {
                    const deficit = p.spentAmount.rial - p.budget.rial;
                    response += `${i + 1}. ${p.name} - کسری بودجه: ${deficit.toLocaleString()} ریال\n`;
                });
                return response;
            }
            
             case 'COUNT_PROJECTS': {
                const projects = projectController.getProjects();
                return `در حال حاضر تعداد ${projects.length} پروژه در سیستم ثبت شده است.`;
            }
            
            case 'LIST_PROJECTS': {
                const projects = projectController.getProjects();
                if (projects.length === 0) return 'در حال حاضر هیچ پروژه‌ای در سیستم ثبت نشده است.';
                let response = `لیست کل پروژه‌ها:\n\n`;
                projects.forEach((p, i) => {
                    response += `${i + 1}. ${p.name}\n`;
                });
                return response;
            }

            case 'GET_CONTRACTS_BY_STATUS': {
                const contracts = contractController.getContractList();
                const filteredContracts = contracts.filter(c => c.status === params.status);
                if (filteredContracts.length === 0) return `در حال حاضر هیچ قراردادی با وضعیت "${params.status}" وجود ندارد.`;

                let response = `لیست قراردادهای با وضعیت "${params.status}":\n\n`;
                filteredContracts.forEach((c, i) => {
                    response += `${i + 1}. ${c.title} (شماره: ${c.contractNumber})\n`;
                });
                return response;
            }

            case 'COUNT_CONTRACTS': {
                const contracts = contractController.getContractList();
                if (params.status === 'all') {
                    return `در مجموع ${contracts.length} قرارداد در سیستم وجود دارد.`;
                }
                const count = contracts.filter(c => c.status === params.status).length;
                return `تعداد ${count} قرارداد با وضعیت "${params.status}" وجود دارد.`;
            }

            case 'COUNT_SYSTEM_USERS': {
                const users = identityController.getSystemUsers();
                return `در حال حاضر ${users.length} کاربر در سیستم تعریف شده است.`;
            }

            case 'LIST_SYSTEM_USERS': {
                const users = identityController.getSystemUsers();
                 if (users.length === 0) return 'در حال حاضر هیچ کاربری در سیستم ثبت نشده است.';
                let response = `لیست کاربران سیستم:\n\n`;
                users.forEach((u, i) => {
                    response += `${i + 1}. ${u.fullName}\n`;
                });
                return response;
            }

            case 'UNKNOWN':
            default:
                return 'متاسفانه متوجه سوال شما نشدم. می‌توانید سوال خود را به شکل دیگری بپرسید؟ برای مثال: "کدام پروژه‌ها بیشترین بودجه را دارند؟"';
        }
    } catch (error) {
        console.error("Analysis controller error:", error);
        return "خطایی در هنگام تحلیل داده‌ها رخ داد. لطفاً با پشتیبانی تماس بگیرید.";
    }
};