import type { AccessLevel } from '../../shared/types';
import { db } from '../db';

export const getAccessLevels = (): AccessLevel[] => {
    return db.accessLevels.get();
};

export const addAccessLevel = (level: Omit<AccessLevel, 'id'>): AccessLevel[] => {
    const levels = db.accessLevels.get();
    const newLevel: AccessLevel = {
        ...level,
        id: Date.now(),
        permissions: level.permissions || [],
    };
    levels.push(newLevel);
    db.accessLevels.set(levels);
    return levels;
};

export const updateAccessLevel = (level: AccessLevel): AccessLevel[] => {
    let levels = db.accessLevels.get();
    const index = levels.findIndex(l => l.id === level.id);
    if (index !== -1) {
        levels[index] = {
            ...level,
            permissions: level.permissions || [],
        };
        db.accessLevels.set(levels);
        return levels;
    }
    throw new Error('AccessLevel not found');
};

export const deleteAccessLevel = (levelId: number): AccessLevel[] => {
    let levels = db.accessLevels.get();
    const updatedLevels = levels.filter(l => l.id !== levelId);
     if (levels.length === updatedLevels.length) {
       throw new Error('AccessLevel not found');
    }
    db.accessLevels.set(updatedLevels);
    return updatedLevels;
};