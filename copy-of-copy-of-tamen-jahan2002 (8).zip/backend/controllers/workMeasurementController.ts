import type { Task } from '../../shared/types';
import { db } from '../db';

export const getTasks = (): Task[] => {
    return db.tasks.get();
};