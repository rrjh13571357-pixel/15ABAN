import React from 'react';
import type { Notification, Page } from '@shared/types';
import { timeAgo } from '../utils/time';
import { BriefcaseIcon, ClipboardDocumentListIcon, InformationCircleIcon } from './Icons';

interface NotificationPanelProps {
  notifications: Notification[];
  onMarkAsRead: (id: number) => void;
  onMarkAllAsRead: () => void;
  onNavigate: (page: Page) => void;
  onClose: () => void;
}

const NotificationIcon: React.FC<{ type: Notification['type'] }> = ({ type }) => {
  const commonClasses = "w-6 h-6";
  switch (type) {
    case 'request':
      return <ClipboardDocumentListIcon className={`${commonClasses} text-sky-600`} />;
    case 'contract':
      return <BriefcaseIcon className={`${commonClasses} text-green-600`} />;
    case 'system':
      return <InformationCircleIcon className={`${commonClasses} text-purple-600`} />;
    case 'consultation':
      return <InformationCircleIcon className={`${commonClasses} text-purple-600`} />;
    default:
      return null;
  }
};

const NotificationPanel: React.FC<NotificationPanelProps> = ({ notifications, onMarkAsRead, onMarkAllAsRead, onNavigate, onClose }) => {

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.isRead) {
      onMarkAsRead(notification.id);
    }
    if (notification.link) {
      onNavigate(notification.link);
      onClose();
    }
  }

  return (
    <div className="absolute top-full mt-2 right-0 w-80 sm:w-96 bg-white rounded-lg shadow-xl border border-slate-200 z-50">
      <div className="flex justify-between items-center p-4 border-b">
        <h3 className="font-bold text-slate-800">اعلان‌ها</h3>
        <button onClick={onMarkAllAsRead} className="text-sm text-indigo-600 hover:underline">
          علامت زدن همه به عنوان خوانده شده
        </button>
      </div>
      <div className="max-h-96 overflow-y-auto">
        {notifications.length === 0 ? (
          <p className="text-center text-slate-500 p-8">هیچ اعلان جدیدی وجود ندارد.</p>
        ) : (
          notifications.map(notification => (
            <div
              key={notification.id}
              className={`flex items-start p-4 cursor-pointer transition-colors ${
                notification.isRead ? 'bg-white' : 'bg-indigo-50'
              } hover:bg-slate-100`}
              onClick={() => handleNotificationClick(notification)}
            >
              <div className="flex-shrink-0 relative">
                <div className={`p-2 rounded-full ${
                  notification.type === 'request' ? 'bg-sky-100' :
                  notification.type === 'contract' ? 'bg-green-100' : 'bg-purple-100'
                }`}>
                    <NotificationIcon type={notification.type} />
                </div>
                 {!notification.isRead && <span className="absolute top-0 right-0 h-2.5 w-2.5 bg-indigo-500 rounded-full border-2 border-white"></span>}
              </div>
              <div className="mr-3 flex-1">
                <p className="font-semibold text-sm text-slate-800">{notification.title}</p>
                <p className="text-xs text-slate-600 mt-0.5">{notification.description}</p>
                <p className="text-xs text-slate-400 mt-1">{timeAgo(notification.timestamp)}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default NotificationPanel;
