import React from 'react';
import type { RequestDetails, SystemUser, ComposeLetterPayload } from '@shared/types';


interface RequestDetailsModalProps {
  requestId: string;
  onClose: () => void;
  currentUser: SystemUser;
  onEditRequest: (request: RequestDetails) => void;
  onSendToAutomation: (payload: ComposeLetterPayload) => void;
}

const RequestDetailsModal: React.FC<RequestDetailsModalProps> = ({ requestId, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50" onClick={onClose}>
      <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-4xl" onClick={e => e.stopPropagation()}>
         <h2 className="text-xl font-bold mb-4">جزئیات درخواست (Placeholder)</h2>
         <p>شناسه درخواست: {requestId}</p>
         <p>محتوای کامل این مودال در حال ساخت است.</p>
         <button onClick={onClose} className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md">بستن</button>
      </div>
    </div>
  );
};

export default RequestDetailsModal;