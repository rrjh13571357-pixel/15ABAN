import React, { useState } from 'react';
import type { Payment, ContractDetails } from '@shared/types';
import { addPayment } from '../services/contractService';

interface AddPaymentModalProps {
    contractId: number;
    onClose: () => void;
    onSaveSuccess: (updatedContract: ContractDetails) => void;
}

const DateField: React.FC<{label: string; year: string; setYear: (y: string) => void; month: string; setMonth: (m: string) => void; day: string; setDay: (d: string) => void;}> = ({label, year, setYear, month, setMonth, day, setDay}) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <div className="grid grid-cols-3 gap-2">
            <select value={year} onChange={e => setYear(e.target.value)} className="w-full p-2 border rounded-md bg-white text-sm"><option>1404</option><option>1403</option></select>
            <select value={month} onChange={e => setMonth(e.target.value)} className="w-full p-2 border rounded-md bg-white text-sm">
                {['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'].map((m,i) => <option key={i} value={i+1}>{m}</option>)}
            </select>
            <select value={day} onChange={e => setDay(e.target.value)} className="w-full p-2 border rounded-md bg-white text-sm">
                {Array.from({ length: 31 }, (_, i) => i + 1).map(d => <option key={d}>{d}</option>)}
            </select>
        </div>
    </div>
);


const AddPaymentModal: React.FC<AddPaymentModalProps> = ({ contractId, onClose, onSaveSuccess }) => {
    const [amount, setAmount] = useState(0);
    const [type, setType] = useState('پیش پرداخت');
    const [referenceNumber, setReferenceNumber] = useState('');
    const [year, setYear] = useState('1404');
    const [month, setMonth] = useState('8');
    const [day, setDay] = useState('8');
    const [isSaving, setIsSaving] = useState(false);

    const handleSave = async () => {
        if (!amount || !referenceNumber) {
            alert('لطفا تمام فیلدهای ستاره‌دار را تکمیل کنید.');
            return;
        }
        setIsSaving(true);
        const paymentData: Omit<Payment, 'id'> = {
            contractId,
            type,
            referenceNumber,
            amount: { rial: amount, usd: 0, eur: 0 },
            date: `${year}/${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`,
            description: 'پرداخت دستی'
        };
        try {
            const updatedContractDetails = await addPayment(paymentData);
            onSaveSuccess(updatedContractDetails);
        } catch (error) {
            console.error("Failed to add payment", error);
            alert("خطا در ثبت پرداخت.");
        } finally {
            setIsSaving(false);
        }
    };
    
    return (
        <form onSubmit={(e) => { e.preventDefault(); handleSave(); }}>
            <h3 className="text-xl font-bold mb-6">افزودن پرداخت جدید</h3>
            <div className="space-y-4">
                <DateField label="تاریخ*" year={year} setYear={setYear} month={month} setMonth={setMonth} day={day} setDay={setDay} />

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">مبلغ* (ریال)</label>
                    <input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} className="w-full p-2 border border-gray-300 rounded-md" required />
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">شماره سند*</label>
                    <input type="text" value={referenceNumber} onChange={e => setReferenceNumber(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md" required />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">نوع*</label>
                    <select value={type} onChange={e => setType(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md bg-white">
                        <option>پیش پرداخت</option>
                        <option>علی الحساب</option>
                        <option>پرداخت نهایی</option>
                        <option>سایر</option>
                    </select>
                </div>
            </div>

            <div className="mt-8 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">انصراف</button>
                <button type="submit" disabled={isSaving} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-400">
                    {isSaving ? 'در حال ذخیره...' : 'ذخیره'}
                </button>
            </div>
        </form>
    );
};

export default AddPaymentModal;
