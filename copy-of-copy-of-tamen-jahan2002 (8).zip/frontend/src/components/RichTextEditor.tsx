import React, { useEffect, useRef } from 'react';

declare global {
    interface Window {
        ClassicEditor: any;
    }
}

interface RichTextEditorProps {
    value: string;
    onChange: (data: string) => void;
}

const RichTextEditor: React.FC<RichTextEditorProps> = ({ value, onChange }) => {
    const editorContainerRef = useRef<HTMLDivElement>(null);
    const editorRef = useRef<any>(null);
    const isInitializing = useRef(false);

    useEffect(() => {
        if (!editorContainerRef.current || !window.ClassicEditor || editorRef.current || isInitializing.current) {
            return;
        }

        isInitializing.current = true;
        const container = editorContainerRef.current;

        window.ClassicEditor
            .create(container, {
                language: 'fa',
                toolbar: {
                    items: [
                        'heading', '|',
                        'bold', 'italic', 'underline', 'strikethrough', '|',
                        'bulletedList', 'numberedList', '|',
                        'outdent', 'indent', '|',
                        'link', 'blockQuote', 'insertTable', '|',
                        'alignment', '|',
                        'undo', 'redo'
                    ]
                },
                table: {
                    contentToolbar: [
                        'tableColumn', 'tableRow', 'mergeTableCells'
                    ]
                },
            })
            .then((editor: any) => {
                editorRef.current = editor;
                editor.setData(value || '');
                editor.model.document.on('change:data', () => {
                    const data = editor.getData();
                    if (data !== value) {
                        onChange(data);
                    }
                });
                isInitializing.current = false;
            })
            .catch((error: any) => {
                console.error('Error during CKEditor initialization.', error);
                isInitializing.current = false;
            });

        return () => {
            if (editorRef.current) {
                editorRef.current.destroy()
                    .catch((error: any) => console.error('Error destroying CKEditor:', error));
                editorRef.current = null;
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (editorRef.current && editorRef.current.getData() !== value) {
            editorRef.current.setData(value || '');
        }
    }, [value]);


    return <div ref={editorContainerRef}></div>;
};

export default RichTextEditor;
