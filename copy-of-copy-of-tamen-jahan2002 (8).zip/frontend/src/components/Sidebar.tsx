import React, { useState, useEffect } from 'react';
// FIX: Use @shared/types alias for consistency.
import type { Page } from '@shared/types';
import { 
    ChevronLeftIcon, HomeIcon, FolderIcon, UsersIcon, CogIcon, 
    ArrowRightOnRectangleIcon, QuestionMarkCircleIcon, ClipboardDocumentListIcon, 
    BriefcaseIcon, UserGroupIcon, ChartBarIcon, PaperAirplaneIcon, ClockIcon,
    BuildingOfficeIcon, ShieldCheckIcon, DocumentTextIcon, ArrowPathIcon, CreditCardIcon, KeyIcon, BanknotesIcon, SparklesIcon,
    MagnifyingGlassIcon,
    UserPlusIcon
} from './Icons';

interface SidebarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  onLogout: () => void;
}

interface NavItemProps {
  icon: React.ReactNode;
  text: string;
  active: boolean;
  onClick: () => void;
  isSubItem?: boolean;
}

type AccordionName = 'baseInfo' | 'system' | 'reports' | 'processes' | 'automation';

const NavItem: React.FC<NavItemProps> = ({ icon, text, active, onClick, isSubItem = false }) => (
  <li
    className={`flex items-center p-3 my-1 rounded-md cursor-pointer transition-colors group relative ${
      active
        ? 'bg-indigo-600/10 text-indigo-100'
        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
    } ${isSubItem ? 'pr-8' : ''}`}
    onClick={onClick}
  >
    {active && <div className="absolute right-0 top-0 h-full w-1 bg-indigo-400 rounded-l-md"></div>}
    <div className="group-hover:scale-110 transition-transform duration-200">{icon}</div>
    <span className="mr-4 font-medium">{text}</span>
  </li>
);


const Sidebar: React.FC<SidebarProps> = ({ currentPage, setCurrentPage, onLogout }) => {
  const [openAccordion, setOpenAccordion] = useState<AccordionName | null>(null);

  useEffect(() => {
    if (['ORG_STRUCTURE', 'PERSONS', 'BANK_ACCOUNTS', 'FINANCIAL_RESOURCES', 'PETTY_CASH_MANAGEMENT', 'REQUEST_TYPES'].includes(currentPage)) {
      setOpenAccordion('baseInfo');
    } else if (['ACCESS_LEVELS', 'USER_DEFINITION', 'USERS', 'ROLES'].includes(currentPage)) {
      setOpenAccordion('system');
    } else if (['REPORTS', 'INVOICE_EXPLORER', 'ADVANCED_SEARCH_REPORTS'].includes(currentPage)) {
      setOpenAccordion('reports');
    } else if (['WORKFLOWS', 'WORKFLOWS_PURCHASE', 'WORKFLOWS_PETTY_CASH', 'WORKFLOWS_CONTRACT', 'WORKFLOWS_PAYROLL'].includes(currentPage)) {
      setOpenAccordion('processes');
    } else if (['AUTOMATION', 'AUTOMATION_TEMPLATES'].includes(currentPage)) {
      setOpenAccordion('automation');
    } else {
      setOpenAccordion(null); 
    }
  }, [currentPage]);

  const toggleAccordion = (accordion: AccordionName) => {
    setOpenAccordion(prev => (prev === accordion ? null : accordion));
  };


  const SubNavItem: React.FC<Omit<NavItemProps, 'isSubItem'>> = (props) => (
    <NavItem {...props} isSubItem={true} />
  );

  return (
    <aside className="w-64 bg-slate-900 flex-shrink-0 flex flex-col">
      <div className="flex items-center justify-center h-20 border-b border-slate-800">
        <HomeIcon className="w-8 h-8 text-indigo-400" />
        <span className="text-xl font-bold text-slate-200 mr-3">نام سامانه</span>
      </div>
      <nav className="flex-1 px-4 py-4">
        <ul>
          <NavItem
            icon={<HomeIcon className="w-6 h-6"/>}
            text="داشبورد"
            active={currentPage === 'DASHBOARD'}
            onClick={() => setCurrentPage('DASHBOARD')}
          />
          <NavItem
            icon={<ClipboardDocumentListIcon />}
            text="کنترل پروژه"
            active={currentPage === 'PROJECTS'}
            onClick={() => setCurrentPage('PROJECTS')}
          />
           <NavItem
            icon={<BriefcaseIcon />}
            text="قراردادها"
            active={currentPage === 'CONTRACTS'}
            onClick={() => setCurrentPage('CONTRACTS')}
          />
           <NavItem
            icon={<UserGroupIcon />}
            text="پرداختی کارکنان"
            active={currentPage === 'PAYROLL'}
            onClick={() => setCurrentPage('PAYROLL')}
          />

          {/* Reports Accordion */}
          <li className="my-1">
            <div
              className="flex items-center justify-between p-3 rounded-md cursor-pointer hover:bg-slate-800 text-slate-400 hover:text-slate-200"
              onClick={() => toggleAccordion('reports')}
            >
              <div className="flex items-center">
                <ChartBarIcon />
                <span className="mr-4 font-medium">گزارش‌گیری‌ها</span>
              </div>
              <ChevronLeftIcon className={`w-5 h-5 transition-transform ${openAccordion === 'reports' ? '-rotate-90' : ''}`} />
            </div>
            {openAccordion === 'reports' && (
              <ul className="mt-1">
                <SubNavItem
                  icon={<ChartBarIcon className="w-5 h-5" />}
                  text="داشبورد گزارش‌ها"
                  active={currentPage === 'REPORTS'}
                  onClick={() => setCurrentPage('REPORTS')}
                />
                 <SubNavItem
                  icon={<MagnifyingGlassIcon className="w-5 h-5" />}
                  text="کاوشگر اقلام فاکتور"
                  active={currentPage === 'INVOICE_EXPLORER'}
                  onClick={() => setCurrentPage('INVOICE_EXPLORER')}
                />
                 <SubNavItem
                  icon={<ClipboardDocumentListIcon className="w-5 h-5" />}
                  text="گزارش درخواست ها"
                  active={currentPage === 'ADVANCED_SEARCH_REPORTS'}
                  onClick={() => setCurrentPage('ADVANCED_SEARCH_REPORTS')}
                />
              </ul>
            )}
          </li>

          {/* Automation Accordion */}
           <li className="my-1">
            <div
              className="flex items-center justify-between p-3 rounded-md cursor-pointer hover:bg-slate-800 text-slate-400 hover:text-slate-200"
              onClick={() => toggleAccordion('automation')}
            >
              <div className="flex items-center">
                <PaperAirplaneIcon />
                <span className="mr-4 font-medium">اتوماسیون داخلی</span>
              </div>
              <ChevronLeftIcon className={`w-5 h-5 transition-transform ${openAccordion === 'automation' ? '-rotate-90' : ''}`} />
            </div>
            {openAccordion === 'automation' && (
              <ul className="mt-1">
                <SubNavItem
                  icon={<ClipboardDocumentListIcon className="w-5 h-5" />}
                  text="کارتابل اصلی"
                  active={currentPage === 'AUTOMATION'}
                  onClick={() => setCurrentPage('AUTOMATION')}
                />
                 <SubNavItem
                  icon={<DocumentTextIcon className="w-5 h-5" />}
                  text="قالب نامه‌ها"
                  active={currentPage === 'AUTOMATION_TEMPLATES'}
                  onClick={() => setCurrentPage('AUTOMATION_TEMPLATES')}
                />
              </ul>
            )}
          </li>

           <NavItem
            icon={<ClockIcon />}
            text="کارسنجی"
            active={currentPage === 'WORK_MEASUREMENT'}
            onClick={() => setCurrentPage('WORK_MEASUREMENT')}
          />
           <NavItem
            icon={<SparklesIcon />}
            text="تحلیلگر هوشمند"
            active={currentPage === 'AI_ANALYST'}
            onClick={() => setCurrentPage('AI_ANALYST')}
          />

          {/* Processes Accordion */}
          <li className="my-1">
            <div
              className="flex items-center justify-between p-3 rounded-md cursor-pointer hover:bg-slate-800 text-slate-400 hover:text-slate-200"
              onClick={() => toggleAccordion('processes')}
            >
              <div className="flex items-center">
                <ArrowPathIcon />
                <span className="mr-4 font-medium">فرایندها و گردش کار</span>
              </div>
              <ChevronLeftIcon className={`w-5 h-5 transition-transform ${openAccordion === 'processes' ? '-rotate-90' : ''}`} />
            </div>
            {openAccordion === 'processes' && (
              <ul className="mt-1">
                <SubNavItem
                  icon={<ClipboardDocumentListIcon className="w-5 h-5" />}
                  text="فرایندهای تامین و خرید"
                  active={currentPage === 'WORKFLOWS_PURCHASE'}
                  onClick={() => setCurrentPage('WORKFLOWS_PURCHASE')}
                />
                <SubNavItem
                  icon={<BanknotesIcon className="w-5 h-5" />}
                  text="فرایندهای تنخواه"
                  active={currentPage === 'WORKFLOWS_PETTY_CASH'}
                  onClick={() => setCurrentPage('WORKFLOWS_PETTY_CASH')}
                />
                <SubNavItem
                  icon={<BriefcaseIcon className="w-5 h-5" />}
                  text="فرایندهای قرارداد"
                  active={currentPage === 'WORKFLOWS_CONTRACT'}
                  onClick={() => setCurrentPage('WORKFLOWS_CONTRACT')}
                />
                <SubNavItem
                  icon={<UserGroupIcon className="w-5 h-5" />}
                  text="فرایندهای حقوق و مزایا"
                  active={currentPage === 'WORKFLOWS_PAYROLL'}
                  onClick={() => setCurrentPage('WORKFLOWS_PAYROLL')}
                />
                <SubNavItem
                  icon={<CogIcon className="w-5 h-5" />}
                  text="مدیریت همه گردش کارها"
                  active={currentPage === 'WORKFLOWS'}
                  onClick={() => setCurrentPage('WORKFLOWS')}
                />
              </ul>
            )}
          </li>

          {/* Base Info Accordion */}
          <li className="my-1">
            <div
              className="flex items-center justify-between p-3 rounded-md cursor-pointer hover:bg-slate-800 text-slate-400 hover:text-slate-200"
              onClick={() => toggleAccordion('baseInfo')}
            >
              <div className="flex items-center">
                <FolderIcon />
                <span className="mr-4 font-medium">اطلاعات پایه</span>
              </div>
              <ChevronLeftIcon className={`w-5 h-5 transition-transform ${openAccordion === 'baseInfo' ? '-rotate-90' : ''}`} />
            </div>
            {openAccordion === 'baseInfo' && (
              <ul className="mt-1">
                <SubNavItem
                  icon={<BuildingOfficeIcon className="w-5 h-5" />}
                  text="ساختار سازمانی"
                  active={currentPage === 'ORG_STRUCTURE'}
                  onClick={() => setCurrentPage('ORG_STRUCTURE')}
                />
                 <SubNavItem
                  icon={<UsersIcon className="w-5 h-5" />}
                  text="مدیریت اشخاص"
                  active={currentPage === 'PERSONS'}
                  onClick={() => setCurrentPage('PERSONS')}
                />
                 <SubNavItem
                  icon={<CreditCardIcon className="w-5 h-5" />}
                  text="ثبت شماره حساب"
                  active={currentPage === 'BANK_ACCOUNTS'}
                  onClick={() => setCurrentPage('BANK_ACCOUNTS')}
                />
                 <SubNavItem
                  icon={<BanknotesIcon className="w-5 h-5" />}
                  text="منابع مالی"
                  active={currentPage === 'FINANCIAL_RESOURCES'}
                  onClick={() => setCurrentPage('FINANCIAL_RESOURCES')}
                />
                 <SubNavItem
                  icon={<BanknotesIcon className="w-5 h-5" />}
                  text="مدیریت تنخواه بگیران"
                  active={currentPage === 'PETTY_CASH_MANAGEMENT'}
                  onClick={() => setCurrentPage('PETTY_CASH_MANAGEMENT')}
                />
                 <SubNavItem
                  icon={<DocumentTextIcon className="w-5 h-5" />}
                  text="انواع درخواست"
                  active={currentPage === 'REQUEST_TYPES'}
                  onClick={() => setCurrentPage('REQUEST_TYPES')}
                />
              </ul>
            )}
          </li>
          
           {/* System Accordion */}
           <li className="my-1">
            <div
              className="flex items-center justify-between p-3 rounded-md cursor-pointer hover:bg-slate-800 text-slate-400 hover:text-slate-200"
              onClick={() => toggleAccordion('system')}
            >
              <div className="flex items-center">
                <CogIcon />
                <span className="mr-4 font-medium">مدیریت سیستم</span>
              </div>
              <ChevronLeftIcon className={`w-5 h-5 transition-transform ${openAccordion === 'system' ? '-rotate-90' : ''}`} />
            </div>
            {openAccordion === 'system' && (
              <ul className="mt-1">
                <SubNavItem
                  icon={<UserPlusIcon className="w-5 h-5" />}
                  text="تعریف کاربر"
                  active={currentPage === 'USER_DEFINITION'}
                  onClick={() => setCurrentPage('USER_DEFINITION')}
                />
                <SubNavItem
                  icon={<UserGroupIcon className="w-5 h-5" />}
                  text="کاربران"
                  active={currentPage === 'USERS'}
                  onClick={() => setCurrentPage('USERS')}
                />
                 <SubNavItem
                  icon={<ShieldCheckIcon className="w-5 h-5" />}
                  text="نقش‌ها"
                  active={currentPage === 'ROLES'}
                  onClick={() => setCurrentPage('ROLES')}
                />
                 <SubNavItem
                  icon={<KeyIcon className="w-5 h-5" />}
                  text="دسترسی‌ها"
                  active={currentPage === 'ACCESS_LEVELS'}
                  onClick={() => setCurrentPage('ACCESS_LEVELS')}
                />
              </ul>
            )}
          </li>
        </ul>
      </nav>
      <div className="mt-auto p-4 border-t border-slate-800">
        <ul>
           <NavItem icon={<QuestionMarkCircleIcon />} text="راهنما" active={false} onClick={() => {}} />
           <NavItem icon={<ArrowRightOnRectangleIcon />} text="خروج" active={false} onClick={onLogout} />
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;
