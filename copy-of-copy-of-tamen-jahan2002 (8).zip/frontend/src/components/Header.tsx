import React, { useState, useEffect, useRef } from 'react';
import { BellIcon, ChevronDownIcon, CheckCircleIcon, ArrowRightOnRectangleIcon } from './Icons';
import NotificationPanel from './NotificationPanel';
import { getNotifications, markNotificationAsRead, markAllNotificationsAsRead } from '../services/notificationService';
import type { Notification, Page, SystemUser } from '@shared/types';

interface HeaderProps {
  title: string;
  setCurrentPage: (page: Page) => void;
  currentUser: SystemUser;
  onLogout: () => void;
}

const SearchIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
  </svg>
);


const Header: React.FC<HeaderProps> = ({ title, setCurrentPage, currentUser, onLogout }) => {
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  const notificationsRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const data = await getNotifications();
        setNotifications(data);
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      }
    };
    fetchNotifications();

    // Fetch notifications periodically
    const interval = setInterval(fetchNotifications, 60000); // every minute
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleMarkAsRead = async (id: number) => {
    // Optimistic update
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
    try {
      await markNotificationAsRead(id);
    } catch (e) {
      console.error("Failed to mark notification as read", e);
      // Optionally revert state on failure
    }
  };

  const handleMarkAllAsRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    try {
      await markAllNotificationsAsRead();
    } catch (e) {
      console.error("Failed to mark all notifications as read", e);
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;


  return (
    <header className="bg-white border-b border-slate-200 px-6 h-20 flex justify-between items-center flex-shrink-0">
      <div className="flex items-center">
        <h1 className="text-xl font-bold text-slate-800">{title}</h1>
      </div>
      
      <div className="flex items-center space-x-6 space-x-reverse">
        {/* Search Bar */}
        <div className="relative w-64 hidden md:block">
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
            <SearchIcon />
          </div>
          <input 
            type="text" 
            placeholder="جستجو..."
            className="w-full bg-slate-100 border-transparent rounded-full py-2 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition"
          />
        </div>

        {/* Icons & User */}
        <div className="relative" ref={notificationsRef}>
          <button onClick={() => setIsNotificationsOpen(prev => !prev)} className="relative cursor-pointer focus:outline-none p-1">
            <BellIcon className="w-6 h-6 text-slate-500 hover:text-indigo-600 transition" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center font-bold">
                {unreadCount}
              </span>
            )}
          </button>
          {isNotificationsOpen && (
            <NotificationPanel
              notifications={notifications}
              onMarkAsRead={handleMarkAsRead}
              onMarkAllAsRead={handleMarkAllAsRead}
              onNavigate={setCurrentPage}
              onClose={() => setIsNotificationsOpen(false)}
            />
          )}
        </div>

        <div className="relative" ref={userMenuRef}>
          <div onClick={() => setIsUserMenuOpen(prev => !prev)} className="flex items-center space-x-3 space-x-reverse cursor-pointer">
            <img
              className="h-10 w-10 rounded-full object-cover border-2 border-transparent hover:border-indigo-500 transition"
              src="https://picsum.photos/100"
              alt="User Avatar"
            />
            <div className="text-right">
              <div className="font-semibold text-sm text-slate-700">{currentUser.fullName}</div>
              <div className="text-xs text-slate-500 flex items-center justify-end">
                  <CheckCircleIcon className="text-green-500 w-3 h-3 ml-1" />
                  <span>آنلاین</span>
              </div>
            </div>
            <ChevronDownIcon className="w-4 h-4 text-slate-400" />
          </div>

          {isUserMenuOpen && (
            <div className="absolute top-full mt-2 right-0 w-48 bg-white rounded-md shadow-lg border border-slate-200 z-50">
              <ul className="py-1">
                <li onClick={onLogout} className="flex items-center px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 cursor-pointer">
                  <ArrowRightOnRectangleIcon className="w-5 h-5 ml-2" />
                  خروج از حساب
                </li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
