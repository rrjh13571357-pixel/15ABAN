import type { SystemUser } from '@shared/types';
import { api } from './api';

export const login = (username: string, password: string): Promise<{ token: string; user: SystemUser }> => {
    return api.post<{ token: string; user: SystemUser }>('/login', { username, password });
};
