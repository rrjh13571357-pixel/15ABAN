import type { SystemUser, Beneficiary, PettyCashHolder, Role, AccessLevel } from '@shared/types';
import { api } from './api';

// --- System Users ---
export const getSystemUsers = (): Promise<SystemUser[]> => {
    return api.get<SystemUser[]>('/users');
};

export const addSystemUser = async (user: Omit<SystemUser, 'id'>): Promise<SystemUser[]> => {
    await api.post<SystemUser>('/users', user);
    return getSystemUsers();
}

export const updateSystemUser = async (user: SystemUser): Promise<SystemUser[]> => {
    await api.put<SystemUser>(`/users/${user.id}`, user);
    return getSystemUsers();
}

export const defineSystemUser = async (userId: number, definition: any): Promise<SystemUser[]> => {
    await api.put(`/users/${userId}/define`, definition);
    return getSystemUsers();
};

export const deleteSystemUser = async (userId: number): Promise<SystemUser[]> => {
    await api.del(`/users/${userId}`);
    return getSystemUsers();
}

// --- Beneficiaries ---
export const getBeneficiaries = (): Promise<Beneficiary[]> => {
    return api.get<Beneficiary[]>('/beneficiaries');
};

export const addBeneficiary = async (beneficiary: Omit<Beneficiary, 'id'>): Promise<Beneficiary[]> => {
    await api.post<Beneficiary>('/beneficiaries', beneficiary);
    return getBeneficiaries();
}

export const updateBeneficiary = async (beneficiary: Beneficiary): Promise<Beneficiary[]> => {
    await api.put<Beneficiary>(`/beneficiaries/${beneficiary.id}`, beneficiary);
    return getBeneficiaries();
}

export const deleteBeneficiary = async (beneficiaryId: number): Promise<Beneficiary[]> => {
    await api.del(`/beneficiaries/${beneficiaryId}`);
    return getBeneficiaries();
}

// --- Petty Cash Holders ---
export const getPettyCashHolders = (): Promise<PettyCashHolder[]> => {
    return api.get<PettyCashHolder[]>('/petty-cash-holders');
};

export const addPettyCashHolder = async (holder: Omit<PettyCashHolder, 'id'>): Promise<PettyCashHolder[]> => {
    await api.post<PettyCashHolder>('/petty-cash-holders', holder);
    return getPettyCashHolders();
}

export const updatePettyCashHolder = async (holder: PettyCashHolder): Promise<PettyCashHolder[]> => {
    await api.put<PettyCashHolder>(`/petty-cash-holders/${holder.id}`, holder);
    return getPettyCashHolders();
}

export const deletePettyCashHolder = async (holderId: number): Promise<PettyCashHolder[]> => {
    await api.del(`/petty-cash-holders/${holderId}`);
    return getPettyCashHolders();
}

export const updateAllPettyCashLimits = (limit: number): Promise<PettyCashHolder[]> => {
    return api.post<PettyCashHolder[]>('/petty-cash-holders/set-global-limit', { limit });
};


// --- Roles ---
export const getRoles = (): Promise<Role[]> => {
    return api.get<Role[]>('/roles');
};

export const addRole = async (role: Omit<Role, 'id'>): Promise<Role[]> => {
    await api.post<Role>('/roles', role);
    return getRoles();
};

export const updateRole = async (role: Role): Promise<Role[]> => {
    await api.put<Role>(`/roles/${role.id}`, role);
    return getRoles();
};

export const deleteRole = async (roleId: number): Promise<Role[]> => {
    await api.del(`/roles/${roleId}`);
    return getRoles();
};
