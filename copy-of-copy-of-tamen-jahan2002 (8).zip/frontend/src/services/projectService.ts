import type { Project, CurrencyAmount } from '@shared/types';
import { api } from './api';

export const getProjects = (): Promise<Project[]> => {
    return api.get<Project[]>('/projects');
};

export const addProject = async (project: Omit<Project, 'id'>): Promise<Project[]> => {
    await api.post<Project>('/projects', project);
    return getProjects();
}

export const updateProject = async (project: Project): Promise<Project[]> => {
    await api.put<Project>(`/projects/${project.id}`, project);
    return getProjects();
}

export const deleteProject = async (projectId: number): Promise<Project[]> => {
    await api.del(`/projects/${projectId}`);
    return getProjects();
}

export const injectFunds = (projectId: number, amount: CurrencyAmount, allocationNumber: string, allocationDate: string, financialResourceId: number): Promise<Project[]> => {
    return api.post<Project[]>(`/projects/${projectId}/inject-funds`, { amount, allocationNumber, allocationDate, financialResourceId });
}

export const transferFunds = (fromProjectId: number, toProjectId: number, amount: CurrencyAmount): Promise<Project[]> => {
    return api.post<Project[]>(`/projects/transfer-funds`, { fromProjectId, toProjectId, amount });
}
