import type { BankAccount } from '@shared/types';
import { api } from './api';

export const getBankAccounts = (): Promise<BankAccount[]> => {
    return api.get<BankAccount[]>('/bank-accounts');
};

export const addBankAccount = async (account: Omit<BankAccount, 'id'>): Promise<BankAccount[]> => {
    await api.post<BankAccount>('/bank-accounts', account);
    return getBankAccounts();
}

export const updateBankAccount = async (account: BankAccount): Promise<BankAccount[]> => {
    await api.put<BankAccount>(`/bank-accounts/${account.id}`, account);
    return getBankAccounts();
}

export const deleteBankAccount = async (accountId: number): Promise<BankAccount[]> => {
    await api.del(`/bank-accounts/${accountId}`);
    return getBankAccounts();
}
