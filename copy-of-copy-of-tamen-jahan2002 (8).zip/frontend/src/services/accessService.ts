import type { AccessLevel } from '@shared/types';
import { api } from './api';

export const getAccessLevels = (): Promise<AccessLevel[]> => {
    return api.get<AccessLevel[]>('/access-levels');
};

export const addAccessLevel = async (level: Omit<AccessLevel, 'id'>): Promise<AccessLevel[]> => {
    await api.post<AccessLevel>('/access-levels', level);
    return getAccessLevels();
};

export const updateAccessLevel = async (level: AccessLevel): Promise<AccessLevel[]> => {
    await api.put<AccessLevel>(`/access-levels/${level.id}`, level);
    return getAccessLevels();
};

export const deleteAccessLevel = async (levelId: number): Promise<AccessLevel[]> => {
    await api.del(`/access-levels/${levelId}`);
    return getAccessLevels();
};
