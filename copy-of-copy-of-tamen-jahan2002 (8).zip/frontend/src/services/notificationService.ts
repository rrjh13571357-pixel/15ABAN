import { api } from './api';
import type { Notification } from '@shared/types';

export const getNotifications = (): Promise<Notification[]> => {
    return api.get<Notification[]>('/notifications');
};

export const markNotificationAsRead = (notificationId: number): Promise<Notification[]> => {
    return api.post<Notification[]>(`/notifications/${notificationId}/read`, {});
};

export const markAllNotificationsAsRead = (): Promise<Notification[]> => {
    return api.post<Notification[]>(`/notifications/read-all`, {});
};
