import { api } from './api';
import type { InboxLetter, Letter, LetterTemplate, LetterPriority, LetterAttachment } from '@shared/types';

export const getInbox = (): Promise<InboxLetter[]> => {
    return api.get<InboxLetter[]>('/automation/inbox');
};

export const getLetter = (id: number): Promise<Letter & { senderName: string, recipientNames: string[], senderUnitName: string, recipientUnitName: string, signatory: { name: string, title: string } }> => {
    return api.get<Letter & { senderName: string, recipientNames: string[], senderUnitName: string, recipientUnitName: string, signatory: { name: string, title: string } }>(`/automation/letters/${id}`);
};

export const sendLetter = async (data: { 
    subject: string, 
    content: string, 
    recipientIds: number[], 
    priority: LetterPriority,
    letterDate: string,
    senderUnitId: string,
    recipientUnitId: string,
    signatoryId: number,
    attachments: Omit<LetterAttachment, 'id'>[],
}): Promise<Letter[]> => {
    await api.post<Letter>('/automation/letters', data);
    return [];
};

// --- Letter Templates ---
export const getLetterTemplates = (): Promise<LetterTemplate[]> => {
    return api.get<LetterTemplate[]>('/automation/templates');
};

export const addLetterTemplate = async (template: Omit<LetterTemplate, 'id'>): Promise<LetterTemplate[]> => {
    await api.post<LetterTemplate>('/automation/templates', template);
    return getLetterTemplates();
};

export const deleteLetterTemplate = async (templateId: number): Promise<LetterTemplate[]> => {
    await api.del(`/automation/templates/${templateId}`);
    return getLetterTemplates();
};
