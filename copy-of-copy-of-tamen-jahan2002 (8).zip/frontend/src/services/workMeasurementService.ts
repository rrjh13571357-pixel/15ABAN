import type { Task } from '@shared/types';
import { api } from './api';

export const getTasks = (): Promise<Task[]> => {
    return api.get<Task[]>('/tasks');
};
