import { api } from './api';
import type { ProjectFinancialSummary, StatusDistribution, MonthlyRequestVolume, InvoiceItemExplorerResult } from '@shared/types';

export const getProjectFinancialSummary = (): Promise<ProjectFinancialSummary> => {
    return api.get<ProjectFinancialSummary>('/reports/project-financial-summary');
};

export const getStatusDistribution = (): Promise<StatusDistribution> => {
    return api.get<StatusDistribution>('/reports/status-distribution');
};

export const getMonthlyRequestVolume = (): Promise<MonthlyRequestVolume> => {
    return api.get<MonthlyRequestVolume>('/reports/monthly-request-volume');
};

export const searchInvoiceItems = (filters: any): Promise<InvoiceItemExplorerResult[]> => {
    // Clean up filters before sending
    const cleanFilters = Object.fromEntries(
        Object.entries(filters).filter(([, value]) => value !== '' && value !== 'all')
    );
    const queryParams = new URLSearchParams(cleanFilters as Record<string, string>).toString();
    return api.get<InvoiceItemExplorerResult[]>(`/invoice-items/search?${queryParams}`);
};
