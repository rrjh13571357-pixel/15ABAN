import type { Request, RequestDetails, Consultation } from '@shared/types';
import { api } from './api';

interface FormInvoiceItem {
    description: string;
    quantity: number;
    unitPrice: number;
    currency: 'rial' | 'usd' | 'eur';
}
interface FormInvoice {
    invoiceNumber: string;
    beneficiaryId: number | null;
    items: FormInvoiceItem[];
}

export const getRequests = (): Promise<Request[]> => {
    return api.get<Request[]>('/requests');
};

export const getRequestDetails = (requestId: string): Promise<RequestDetails> => {
    return api.get<RequestDetails>(`/requests/${requestId}`);
};

export const approveRequestStep = (requestId: string): Promise<RequestDetails> => {
    return api.post<RequestDetails>(`/requests/${requestId}/approve`, {});
};

export const addRequest = async (
    requestData: Omit<Request, 'id' | 'status' | 'date' | 'lastModified'>,
    invoicesData: FormInvoice[]
): Promise<Request[]> => {
    await api.post<Request>('/requests', { requestData, invoicesData });
    return getRequests();
};

export const deleteRequest = async (requestId: string): Promise<Request[]> => {
    await api.del(`/requests/${requestId}`);
    return getRequests();
};

// --- New Functions ---

export const askForConsultation = (requestId: string, toUserIds: number[], question: string): Promise<RequestDetails> => {
    return api.post<RequestDetails>(`/requests/${requestId}/consultations`, { toUserIds, question });
};

export const answerConsultation = (consultationId: number, answer: string): Promise<RequestDetails> => {
    return api.post<RequestDetails>(`/consultations/${consultationId}/answer`, { answer });
};

export const rejectRequest = (requestId: string, reason: string): Promise<RequestDetails> => {
    return api.post<RequestDetails>(`/requests/${requestId}/reject`, { reason });
};

export const resubmitRequest = async (requestData: RequestDetails, invoicesData: any[]): Promise<Request[]> => {
    await api.put<Request>(`/requests/${requestData.id}/resubmit`, { requestData, invoicesData });
    return getRequests();
};

export const getConsultations = (): Promise<Consultation[]> => {
    return api.get<Consultation[]>('/consultations');
};
