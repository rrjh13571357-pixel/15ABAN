import React from 'react';

interface WorkflowsProps {
    category?: 'purchase' | 'petty_cash' | 'contract' | 'payroll';
}

const Workflows: React.FC<WorkflowsProps> = ({ category }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4">مدیریت گردش‌های کاری {category}</h1>
      <p className="text-gray-600">این صفحه در حال ساخت است.</p>
    </div>
  );
};

export default Workflows;
