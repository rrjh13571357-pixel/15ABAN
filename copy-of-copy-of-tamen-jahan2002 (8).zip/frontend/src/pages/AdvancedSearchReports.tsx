import React, { useState, useEffect, useMemo } from 'react';
import { ChevronDownIcon } from '../components/Icons';
import { getRequests } from '../services/requestService';
import { getProjects } from '../services/projectService';
import { getSystemUsers } from '../services/identityService';
import { getRequestTypes } from '../services/workflowService';
import { Request, RequestStatus, Project, SystemUser, RequestType, RequestDetails, ComposeLetterPayload } from '@shared/types';
import RequestDetailsModal from '../components/RequestDetailsModal';

const statusStyles: Record<RequestStatus, string> = {
  [RequestStatus.InProgress]: 'bg-blue-100 text-blue-700',
  [RequestStatus.Pending]: 'bg-yellow-100 text-yellow-700',
  [RequestStatus.Rejected]: 'bg-red-100 text-red-700',
  [RequestStatus.Completed]: 'bg-green-100 text-green-700',
};

const StatusBadge: React.FC<{ status: RequestStatus }> = ({ status }) => (
  <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${statusStyles[status]}`}>
    {status}
  </span>
);

interface SearchFilters {
    status: string;
    requestTypeId: string;
    applicantId: string;
    projectId: string;
    currentOwnerId: string;
    dateFrom: string;
    dateTo: string;
    amountFrom: string;
    amountTo: string;
}

const InputField = ({ label, name, value, onChange, ...props }: {label: string, name: keyof SearchFilters, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, [key: string]: any}) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input name={name} onChange={onChange} value={value} {...props} className="w-full p-2 border border-gray-300 rounded-md text-sm" />
    </div>
);

const SelectField = ({ label, name, value, onChange, options }: {label: string, name: keyof SearchFilters, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, options: {value: string | number, label: string}[]}) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <select name={name} value={value} onChange={onChange} className="w-full p-2 border border-gray-300 rounded-md bg-white text-sm">
            <option value="all">همه</option>
            {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
        </select>
    </div>
);

interface AdvancedSearchReportsProps {
    currentUser: SystemUser;
    onEditRequest: (request: RequestDetails) => void;
    onSendToAutomation: (payload: ComposeLetterPayload) => void;
}


const AdvancedSearchReports: React.FC<AdvancedSearchReportsProps> = ({ currentUser, onEditRequest, onSendToAutomation }) => {
    const [allRequests, setAllRequests] = useState<Request[]>([]);
    const [projects, setProjects] = useState<Project[]>([]);
    const [users, setUsers] = useState<SystemUser[]>([]);
    const [requestTypes, setRequestTypes] = useState<RequestType[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);

    const [filters, setFilters] = useState<SearchFilters>({
        status: 'all',
        requestTypeId: 'all',
        applicantId: 'all',
        projectId: 'all',
        currentOwnerId: 'all',
        dateFrom: '',
        dateTo: '',
        amountFrom: '',
        amountTo: '',
    });
    const [results, setResults] = useState<Request[]>([]);
    const [searchPerformed, setSearchPerformed] = useState(false);

    const projectMap = useMemo(() => new Map(projects.map(p => [p.id, p.name])), [projects]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [requestsData, projectsData, usersData, requestTypesData] = await Promise.all([
                    getRequests(),
                    getProjects(),
                    getSystemUsers(),
                    getRequestTypes()
                ]);
                setAllRequests(requestsData);
                setProjects(projectsData);
                setUsers(usersData);
                setRequestTypes(requestTypesData);
            } catch (error) {
                console.error("Failed to fetch data for reports page:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSearch = () => {
        setSearchPerformed(true);
        let filtered = [...allRequests];

        if (filters.status !== 'all') {
            filtered = filtered.filter(r => r.status === filters.status);
        }
        if (filters.projectId !== 'all') {
            filtered = filtered.filter(r => r.projectId?.toString() === filters.projectId);
        }
        if (filters.applicantId !== 'all') {
            filtered = filtered.filter(r => r.originalApplicantId.toString() === filters.applicantId);
        }
        if (filters.requestTypeId !== 'all') {
            filtered = filtered.filter(r => r.requestTypeId.toString() === filters.requestTypeId);
        }
        if(filters.currentOwnerId !== 'all') {
            filtered = filtered.filter(r => r.currentStepOwnerId.toString() === filters.currentOwnerId);
        }
        
        const amountFrom = parseFloat(filters.amountFrom);
        if (!isNaN(amountFrom)) {
            filtered = filtered.filter(r => r.amount.rial >= amountFrom);
        }
        const amountTo = parseFloat(filters.amountTo);
        if (!isNaN(amountTo)) {
            filtered = filtered.filter(r => r.amount.rial <= amountTo);
        }

        if (filters.dateFrom) {
            filtered = filtered.filter(r => r.date >= filters.dateFrom);
        }
        if (filters.dateTo) {
            filtered = filtered.filter(r => r.date <= filters.dateTo);
        }
        
        setResults(filtered);
    };

    const handleClear = () => {
        setFilters({
            status: 'all', requestTypeId: 'all', applicantId: 'all',
            projectId: 'all', currentOwnerId: 'all', dateFrom: '',
            dateTo: '', amountFrom: '', amountTo: '',
        });
        setResults([]);
        setSearchPerformed(false);
    };
    
    const summary = useMemo(() => {
        const data = searchPerformed ? results : allRequests;
        const totalAmount = data
            .filter(r => r.status === RequestStatus.Completed)
            .reduce((sum, r) => sum + r.amount.rial, 0);

        const statusCounts = data.reduce((acc, r) => {
            acc[r.status] = (acc[r.status] || 0) + 1;
            return acc;
        }, {} as Record<RequestStatus, number>);

        return {
            totalCount: data.length,
            totalAmount,
            statusCounts
        };
    }, [results, allRequests, searchPerformed]);

    if (loading) {
        return <div className="text-center p-10">در حال بارگذاری داده‌ها...</div>;
    }

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <details open className="group">
                    <summary className="flex justify-between items-center cursor-pointer list-none -m-2 p-2">
                        <h2 className="text-lg font-bold text-slate-800">جستجوی دستی و پیشرفته</h2>
                        <ChevronDownIcon className="w-5 h-5 text-slate-500 transform transition-transform group-open:rotate-180" />
                    </summary>
                    <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 pt-4 border-t">
                        <SelectField label="وضعیت" name="status" value={filters.status} onChange={handleFilterChange} options={Object.values(RequestStatus).map(s => ({ value: s as string, label: s as string }))} />
                        <SelectField label="نوع درخواست" name="requestTypeId" value={filters.requestTypeId} onChange={handleFilterChange} options={requestTypes.map(rt => ({ value: rt.id, label: rt.title }))} />
                        <SelectField label="درخواست‌کننده" name="applicantId" value={filters.applicantId} onChange={handleFilterChange} options={users.map((u: SystemUser) => ({ value: u.id, label: u.fullName }))} />
                        <SelectField label="پروژه" name="projectId" value={filters.projectId} onChange={handleFilterChange} options={projects.map((p: Project) => ({ value: p.id, label: p.name }))} />
                        <SelectField label="مسئول فعلی" name="currentOwnerId" value={filters.currentOwnerId} onChange={handleFilterChange} options={users.map((u: SystemUser) => ({ value: u.id, label: u.fullName }))} />
                        <InputField label="تاریخ ثبت (از)" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} placeholder="YYYY/MM/DD" />
                        <InputField label="تاریخ ثبت (تا)" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} placeholder="YYYY/MM/DD" />
                        <InputField label="مبلغ (از)" name="amountFrom" value={filters.amountFrom} onChange={handleFilterChange} type="number" />
                        <InputField label="مبلغ (تا)" name="amountTo" value={filters.amountTo} onChange={handleFilterChange} type="number" />
                    </div>
                     <div className="mt-6 flex justify-start space-x-3 space-x-reverse">
                        <button onClick={handleSearch} className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors font-semibold text-sm">جستجو</button>
                        <button onClick={handleClear} className="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 font-semibold text-sm">پاک کردن</button>
                    </div>
                </details>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h2 className="text-lg font-bold text-slate-800 mb-4">خلاصه گزارش</h2>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-slate-50 p-4 rounded-lg border flex items-center justify-between">
                        <div>
                             <p className="text-slate-500 font-medium text-sm">کل درخواست ها</p>
                             <p className="text-2xl font-bold text-slate-800 mt-1">{summary.totalCount}</p>
                        </div>
                        <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                        </div>
                    </div>
                     <div className="bg-slate-50 p-4 rounded-lg border flex items-center justify-between">
                        <div>
                             <p className="text-slate-500 font-medium text-sm">مبلغ کل تایید شده</p>
                             <p className="text-2xl font-bold text-slate-800 mt-1">{summary.totalAmount.toLocaleString()} <span className="text-sm font-normal">ریال</span></p>
                        </div>
                        <div className="p-3 rounded-full bg-green-100 text-green-600">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                        </div>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-lg border">
                         <p className="text-slate-500 font-medium text-sm mb-2">تفکیک وضعیت</p>
                         <ul className="space-y-1 text-sm">
                            <li className="flex justify-between items-center"><span className="text-green-600">تایید نهایی</span><span className="font-bold">{summary.statusCounts[RequestStatus.Completed] || 0}</span></li>
                            <li className="flex justify-between items-center"><span className="text-blue-600">در حال بررسی</span><span className="font-bold">{summary.statusCounts[RequestStatus.InProgress] || 0}</span></li>
                            <li className="flex justify-between items-center"><span className="text-yellow-500">در انتظار تایید</span><span className="font-bold">{summary.statusCounts[RequestStatus.Pending] || 0}</span></li>
                            <li className="flex justify-between items-center"><span className="text-red-600">رد شده</span><span className="font-bold">{summary.statusCounts[RequestStatus.Rejected] || 0}</span></li>
                         </ul>
                    </div>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h2 className="text-lg font-bold text-slate-800 mb-4">نتایج جستجو</h2>
                 <div className="overflow-x-auto">
                    <table className="w-full text-sm text-right">
                        <thead className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                        <tr>
                            <th className="p-3 font-semibold">شماره</th>
                            <th className="p-3 font-semibold">موضوع</th>
                            <th className="p-3 font-semibold">درخواست‌کننده</th>
                            <th className="p-3 font-semibold">مبلغ (ریال)</th>
                            <th className="p-3 font-semibold">پروژه</th>
                            <th className="p-3 font-semibold">تاریخ ثبت</th>
                            <th className="p-3 font-semibold">وضعیت</th>
                            <th className="p-3 font-semibold">عملیات</th>
                        </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                           {(searchPerformed ? results : []).map((req) => (
                                <tr key={req.id} className="hover:bg-slate-50 transition-colors">
                                <td className="p-4 font-mono text-xs">{req.id}</td>
                                <td className="p-4 font-medium">{req.subject}</td>
                                <td className="p-4">{req.applicant}</td>
                                <td className="p-4">{req.amount.rial.toLocaleString()}</td>
                                <td className="p-4">{req.projectId ? projectMap.get(req.projectId) || '---' : '---'}</td>
                                <td className="p-4">{req.date}</td>
                                <td className="p-4"><StatusBadge status={req.status} /></td>
                                <td className="p-4">
                                    <button onClick={() => setSelectedRequestId(req.id)} className="text-indigo-600 hover:text-indigo-800 font-semibold text-xs">مشاهده جزئیات</button>
                                </td>
                                </tr>
                            ))}
                             {searchPerformed && results.length === 0 && (
                                <tr><td colSpan={8} className="text-center p-8 text-slate-500">هیچ نتیجه‌ای با این فیلترها یافت نشد.</td></tr>
                            )}
                             {!searchPerformed && (
                                <tr><td colSpan={8} className="text-center p-8 text-slate-500">برای مشاهده نتایج، لطفا جستجو کنید.</td></tr>
                             )}
                        </tbody>
                    </table>
                </div>
            </div>
             {selectedRequestId && (
                <RequestDetailsModal 
                    requestId={selectedRequestId} 
                    onClose={() => setSelectedRequestId(null)} 
                    currentUser={currentUser}
                    onEditRequest={onEditRequest}
                    onSendToAutomation={onSendToAutomation}
                />
            )}
        </div>
    );
};

export default AdvancedSearchReports;