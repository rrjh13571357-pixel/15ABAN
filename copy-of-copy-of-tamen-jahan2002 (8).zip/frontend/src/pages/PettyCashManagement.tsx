import React from 'react';
import type { SystemUser } from '@shared/types';


interface PettyCashManagementProps {
    currentUser: SystemUser;
}

const PettyCashManagement: React.FC<PettyCashManagementProps> = ({ currentUser }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4">مدیریت تنخواه بگیران</h1>
      <p className="text-gray-600">این صفحه در حال ساخت است.</p>
    </div>
  );
};

export default PettyCashManagement;
