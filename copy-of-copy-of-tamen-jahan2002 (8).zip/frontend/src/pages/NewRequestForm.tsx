import React from 'react';
import type { Page, RequestDetails, SystemUser } from '@shared/types';

interface NewRequestFormProps {
  setCurrentPage: (page: Page | 'DASHBOARD') => void;
  requestToEdit: RequestDetails | null;
  currentUser: SystemUser;
}

const NewRequestForm: React.FC<NewRequestFormProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4">ثبت درخواست جدید</h1>
      <p className="text-gray-600">این صفحه در حال ساخت است.</p>
      <button onClick={() => setCurrentPage('DASHBOARD')} className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md">بازگشت</button>
    </div>
  );
};

export default NewRequestForm;
