import React, { useState, useEffect, useMemo, useRef } from 'react';
import * as contractService from '../services/contractService';
import { Contract, ContractDetails, ContractStatus, Payment, Guarantee, Addendum, Attachment, Beneficiary, Workflow, Project, OrganizationalUnit } from '@shared/types';
import * as identityService from '../services/identityService';
import * as workflowService from '../services/workflowService';
import * as projectService from '../services/projectService';
import * as organizationService from '../services/organizationService';
import { PencilIcon, TrashIcon, ArrowLeftIcon, PlusIcon, ChevronUpDownIcon } from '../components/Icons';
import AddPaymentModal from '../components/AddPaymentModal';

const statusStyles: Record<ContractStatus, string> = {
  [ContractStatus.Active]: 'bg-green-100 text-green-800',
  [ContractStatus.Pending]: 'bg-yellow-100 text-yellow-800',
  [ContractStatus.Archived]: 'bg-gray-100 text-gray-800',
};

const StatusBadge: React.FC<{ status: ContractStatus }> = ({ status }) => (
  <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${statusStyles[status]}`}>
    {status}
  </span>
);

const Modal: React.FC<{onClose: () => void; children: React.ReactNode}> = ({ onClose, children }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-start pt-10 z-50 overflow-y-auto" onClick={onClose}>
        <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-4xl relative" onClick={e => e.stopPropagation()}>
            <button onClick={onClose} className="absolute top-4 left-4 text-gray-500 hover:text-gray-800">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
            {children}
        </div>
    </div>
);

const InputField: React.FC<{label: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, required?: boolean}> = ({ label, ...props }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input {...props} className="w-full p-2 border border-gray-300 rounded-md" />
    </div>
);

const SelectField: React.FC<{label: string, options: any[], value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, displayKey: string, valueKey: string}> = ({ label, options, displayKey, valueKey, ...props }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <select {...props} className="w-full p-2 border border-gray-300 rounded-md bg-white">
            <option value="">-- انتخاب کنید --</option>
            {options.map(opt => <option key={opt[valueKey]} value={opt[valueKey]}>{opt[displayKey]}</option>)}
        </select>
    </div>
);

const SearchableDropdown: React.FC<{value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, onFocus: () => void, isOpen: boolean, options: any[], onSelect: (item: any) => void, displayKey: string}> = ({ value, onChange, onFocus, isOpen, options, onSelect, displayKey }) => (
    <div className="relative">
        <input type="text" value={value} onChange={onChange} onFocus={onFocus} className="w-full p-2 pr-10 border border-gray-300 rounded-md" autoComplete="off" />
        <ChevronUpDownIcon className="absolute top-1/2 right-3 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        {isOpen && (
            <ul className="absolute z-10 w-full bg-white border border-gray-300 rounded-md mt-1 max-h-40 overflow-y-auto shadow-lg">
                {options.length > 0 ? options.map(opt => (
                    <li key={opt.id} className="p-2 cursor-pointer hover:bg-gray-100" onClick={() => onSelect(opt)}>
                        {opt[displayKey]}
                    </li>
                )) : <li className="p-2 text-gray-500">موردی یافت نشد.</li>}
            </ul>
        )}
    </div>
);

const DateField: React.FC<{label: string; year: string; setYear: (y: string) => void; month: string; setMonth: (m: string) => void; day: string; setDay: (d: string) => void;}> = ({label, year, setYear, month, setMonth, day, setDay}) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <div className="grid grid-cols-3 gap-2">
            <select value={year} onChange={e => setYear(e.target.value)} className="w-full p-2 border rounded-md bg-white text-sm"><option>1404</option><option>1403</option></select>
            <select value={month} onChange={e => setMonth(e.target.value)} className="w-full p-2 border rounded-md bg-white text-sm">
                {['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'].map((m,i) => <option key={i} value={i+1}>{m}</option>)}
            </select>
            <select value={day} onChange={e => setDay(e.target.value)} className="w-full p-2 border rounded-md bg-white text-sm">
                {Array.from({ length: 31 }, (_, i) => i + 1).map(d => <option key={d}>{d}</option>)}
            </select>
        </div>
    </div>
);

const NewContractForm: React.FC<{onClose: () => void, onSaveSuccess: (contracts: Contract[]) => void}> = ({onClose, onSaveSuccess}) => {
    const [formData, setFormData] = useState({
        title: '',
        party: null as Beneficiary | null,
        manualContractNumber: '',
        employer: null as Beneficiary | null,
        ourRole: 'payer' as 'payer' | 'payee',
        contractType: null as Workflow | null,
        category: 'IT',
        project: null as Project | null,
        relatedCenter: null as OrganizationalUnit | null,
        buyerRep: '',
        sellerRep: '',
        buyerAddress: '',
    });
    const [startYear, setStartYear] = useState('1404');
    const [startMonth, setStartMonth] = useState('8');
    const [startDay, setStartDay] = useState('6');
    const [endYear, setEndYear] = useState('1404');
    const [endMonth, setEndMonth] = useState('8');
    const [endDay, setEndDay] = useState('6');
    const [requirementFiles, setRequirementFiles] = useState<Record<string, File | null>>({});

    const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
    const [workflows, setWorkflows] = useState<Workflow[]>([]);
    const [projects, setProjects] = useState<Project[]>([]);
    const [orgUnits, setOrgUnits] = useState<OrganizationalUnit[]>([]);
    
    const [loading, setLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    const [partySearchTerm, setPartySearchTerm] = useState('');
    const [isPartyOpen, setIsPartyOpen] = useState(false);
    const partyRef = useRef<HTMLDivElement>(null);
    
    const [employerSearchTerm, setEmployerSearchTerm] = useState('');
    const [isEmployerOpen, setIsEmployerOpen] = useState(false);
    const employerRef = useRef<HTMLDivElement>(null);

    const [projectSearchTerm, setProjectSearchTerm] = useState('');
    const [isProjectOpen, setIsProjectOpen] = useState(false);
    const projectRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [benefs, wfs, projs, units] = await Promise.all([
                    identityService.getBeneficiaries(),
                    workflowService.getWorkflows(),
                    projectService.getProjects(),
                    organizationService.getOrgUnits()
                ]);
                setBeneficiaries(benefs);
                setWorkflows(wfs.filter((w: Workflow) => w.name.includes("قرارداد"))); // Filter for contract related workflows
                setProjects(projs);
                setOrgUnits(units);
            } catch (e) {
                console.error("Failed to load dependencies for NewContractForm", e);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);
    
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (partyRef.current && !partyRef.current.contains(event.target as Node)) setIsPartyOpen(false);
            if (employerRef.current && !employerRef.current.contains(event.target as Node)) setIsEmployerOpen(false);
            if (projectRef.current && !projectRef.current.contains(event.target as Node)) setIsProjectOpen(false);
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);
    
    const filteredParties = useMemo(() => beneficiaries.filter(b => b.fullName.toLowerCase().includes(partySearchTerm.toLowerCase())), [beneficiaries, partySearchTerm]);
    const filteredEmployers = useMemo(() => beneficiaries.filter(b => b.fullName.toLowerCase().includes(employerSearchTerm.toLowerCase())), [beneficiaries, employerSearchTerm]);
    const filteredProjects = useMemo(() => projects.filter(p => p.name.toLowerCase().includes(projectSearchTerm.toLowerCase())), [projects, projectSearchTerm]);

    const handleSelect = (field: keyof typeof formData, value: any) => {
        setFormData(prev => ({...prev, [field]: value}));
    };
    
    const handleFileChange = (reqName: string, file: File | null) => {
        setRequirementFiles(prev => ({ ...prev, [reqName]: file }));
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            if (!formData.title || !formData.party || !formData.employer || !formData.contractType || !formData.relatedCenter || !formData.project) {
                 alert('لطفا تمام فیلدهای ستاره‌دار را تکمیل کنید.');
                 setIsSaving(false);
                 return;
            }
            
            const requirements = formData.contractType.requirements || [];
            if (requirements.some((req: string) => !requirementFiles[req])) {
                alert('لطفا تمام فایل‌های الزامات را بارگذاری کنید.');
                setIsSaving(false);
                return;
            }

            const contractData = {
                contractNumber: `C-${Date.now()}`,
                title: formData.title,
                party: formData.party.fullName,
                amount: null,
                endDate: `${endYear}/${String(endMonth).padStart(2, '0')}/${String(endDay).padStart(2, '0')}`,
                status: ContractStatus.Pending,
                manualContractNumber: formData.manualContractNumber,
                employer: formData.employer.fullName,
                ourRole: formData.ourRole,
                contractType: formData.contractType.name,
                category: formData.category,
                projectType: "پروژه‌ای",
                relatedCenter: formData.relatedCenter.title,
                startDate: `${startYear}/${String(startMonth).padStart(2, '0')}/${String(startDay).padStart(2, '0')}`,
            };
            const updatedContracts = await contractService.addContract(contractData as any);
            onSaveSuccess(updatedContracts);
        } catch(e) {
            console.error(e);
            alert("خطا در ذخیره قرارداد");
        } finally {
            setIsSaving(false);
        }
    };


    if (loading) return <div className="p-4 text-center">در حال بارگذاری فرم...</div>

    return (
        <form onSubmit={e => { e.preventDefault(); handleSave(); }}>
            <h3 className="text-xl font-bold mb-6">ثبت قرارداد جدید</h3>
            
            <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                <p className="font-semibold text-gray-700 border-b pb-2">اطلاعات پایه</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <InputField label="عنوان قرارداد*" value={formData.title} onChange={e => handleSelect('title', e.target.value)} required />
                    
                    <div ref={partyRef}>
                        <label className="block text-sm font-medium text-gray-700 mb-1">طرف قرارداد*</label>
                        <SearchableDropdown value={partySearchTerm} onChange={e => setPartySearchTerm(e.target.value)} onFocus={() => setIsPartyOpen(true)} isOpen={isPartyOpen} options={filteredParties} onSelect={item => { handleSelect('party', item); setPartySearchTerm(item.fullName); setIsPartyOpen(false); }} displayKey="fullName" />
                    </div>
                     <div ref={employerRef}>
                        <label className="block text-sm font-medium text-gray-700 mb-1">کارفرما*</label>
                        <SearchableDropdown value={employerSearchTerm} onChange={e => setEmployerSearchTerm(e.target.value)} onFocus={() => setIsEmployerOpen(true)} isOpen={isEmployerOpen} options={filteredEmployers} onSelect={item => { handleSelect('employer', item); setEmployerSearchTerm(item.fullName); setIsEmployerOpen(false); }} displayKey="fullName" />
                    </div>
                    <InputField label="شماره قرارداد دستی" value={formData.manualContractNumber} onChange={e => handleSelect('manualContractNumber', e.target.value)} />
                </div>
                <div className="flex items-center space-x-4">
                    <label className="text-sm font-medium text-gray-700">نقش شرکت در این قرارداد:</label>
                    <div className="flex items-center">
                        <input type="radio" id="payer" name="ourRole" value="payer" checked={formData.ourRole === 'payer'} onChange={e => handleSelect('ourRole', e.target.value)} className="h-4 w-4" />
                        <label htmlFor="payer" className="mr-2 text-sm">ما کارفرما هستیم (پرداخت کننده)</label>
                    </div>
                    <div className="flex items-center">
                        <input type="radio" id="payee" name="ourRole" value="payee" checked={formData.ourRole === 'payee'} onChange={e => handleSelect('ourRole', e.target.value)} className="h-4 w-4" />
                        <label htmlFor="payee" className="mr-2 text-sm">ما پیمانکار هستیم (دریافت کننده)</label>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <SelectField label="نوع قرارداد*" options={workflows} value={formData.contractType?.id.toString() || ''} onChange={e => handleSelect('contractType', workflows.find(w => w.id.toString() === e.target.value) || null)} displayKey="name" valueKey="id" />
                    <SelectField label="دسته‌بندی" options={['IT', 'تدارکات', 'ساختمانی', 'مشاوره'].map(c=>({name: c}))} value={formData.category} onChange={e => handleSelect('category', e.target.value)} displayKey="name" valueKey="name" />
                    <div ref={projectRef} className="col-span-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">نوع پروژه*</label>
                        <SearchableDropdown value={projectSearchTerm} onChange={e => setProjectSearchTerm(e.target.value)} onFocus={() => setIsProjectOpen(true)} isOpen={isProjectOpen} options={filteredProjects} onSelect={item => { handleSelect('project', item); setProjectSearchTerm(item.name); setIsProjectOpen(false); }} displayKey="name" />
                    </div>
                    <SelectField label="مرکز مرتبط*" options={orgUnits} value={formData.relatedCenter?.id.toString() || ''} onChange={e => handleSelect('relatedCenter', orgUnits.find(u => u.id === e.target.value) || null)} displayKey="title" valueKey="id" />
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <DateField label="تاریخ شروع*" year={startYear} setYear={setStartYear} month={startMonth} setMonth={setStartMonth} day={startDay} setDay={setStartDay} />
                     <DateField label="تاریخ پایان*" year={endYear} setYear={setEndYear} month={endMonth} setMonth={setEndMonth} day={endDay} setDay={setEndDay} />
                 </div>
                 
                {(formData.contractType?.requirements || []).length > 0 && (
                     <div>
                        <p className="font-semibold text-gray-700 border-b pb-2 mt-6">الزامات فرآیند: {formData.contractType?.name}</p>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                            {formData.contractType?.requirements?.map((req: string) => (
                                <div key={req}>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">{req}*</label>
                                    <input type="file" onChange={e => handleFileChange(req, e.target.files ? e.target.files[0] : null)} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" required />
                                </div>
                            ))}
                        </div>
                    </div>
                )}


                 <p className="font-semibold text-gray-700 border-b pb-2 mt-6">مقادیر قالب قرارداد: قالب قرارداد خرید کالا</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <InputField label="نماینده خریدار" value={formData.buyerRep} onChange={e => handleSelect('buyerRep', e.target.value)} />
                    <InputField label="نماینده فروشنده" value={formData.sellerRep} onChange={e => handleSelect('sellerRep', e.target.value)} />
                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">آدرس خریدار</label>
                        <textarea value={formData.buyerAddress} onChange={e => handleSelect('buyerAddress', e.target.value)} rows={3} className="w-full p-2 border border-gray-300 rounded-md"></textarea>
                    </div>
                </div>

            </div>
            <div className="mt-8 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="px-6 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">انصراف</button>
                <button type="submit" disabled={isSaving} className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-400">
                    {isSaving ? 'در حال ذخیره...' : 'ذخیره'}
                </button>
            </div>
        </form>
    );
};

interface DetailViewProps { contract: ContractDetails; onBack: () => void; onOpenModal: (content: React.ReactNode) => void; onCloseModal: () => void; onPaymentSaved: (updatedContract: ContractDetails) => void; }
const ContractDetailView: React.FC<DetailViewProps> = ({ contract, onBack, onOpenModal, onCloseModal, onPaymentSaved }) => {
    const [activeTab, setActiveTab] = useState<'info'|'payments'|'guarantees'|'addendums'|'attachments'|'workflow'>('info');
    
    const renderTabContent = () => {
        switch(activeTab) {
            case 'info': return <InfoTab contract={contract} />;
            case 'payments': return <GenericTab title="پرداخت‌ها" data={contract.payments} headers={['نوع', 'تاریخ', 'مبلغ', 'شرح', 'شماره سند']} renderRow={(item: Payment, i) => <tr key={i}><td>{item.type}</td><td>{item.date}</td><td>{item.amount.rial.toLocaleString()} ریال</td><td>{item.description}</td><td>{item.referenceNumber}</td></tr>} onAdd={() => onOpenModal(<AddPaymentModal contractId={contract.id} onClose={onCloseModal} onSaveSuccess={onPaymentSaved} />)} addText="ثبت پرداخت جدید" />;
            case 'guarantees': return <GenericTab title="ضمانت‌نامه‌ها" data={contract.guarantees} headers={['نوع', 'صادرکننده', 'مبلغ', 'تاریخ انقضا']} renderRow={(item: Guarantee, i) => <tr key={i}><td>{item.type}</td><td>{item.issuer}</td><td>{item.amount.rial.toLocaleString()} ریال</td><td>{item.expiryDate}</td></tr>} onAdd={() => onOpenModal(<div>فرم ثبت ضمانت‌نامه جدید</div>)} addText="ثبت ضمانت‌نامه جدید" />;
            case 'addendums': return <GenericTab title="متمم‌ها" data={contract.addendums} headers={['نوع', 'تاریخ', 'شماره', 'تغییر مبلغ']} renderRow={(item: Addendum, i) => <tr key={i}><td>{item.type}</td><td>{item.date}</td><td>{item.number}</td><td>{item.amountChange.rial.toLocaleString()} ریال</td></tr>} onAdd={() => onOpenModal(<div>فرم ثبت متمم جدید</div>)} addText="ثبت متمم جدید" />;
            case 'attachments': return <GenericTab title="پیوست‌ها" data={contract.attachments} headers={['نام فایل', 'نوع', 'تاریخ بارگذاری']} renderRow={(item: Attachment, i) => <tr key={i}><td>{item.fileName}</td><td>{item.fileType}</td><td>{item.uploadDate}</td></tr>} onAdd={() => { /* Upload logic */ }} addText="افزودن فایل" />;
            case 'workflow': return <div className="text-center p-10 text-gray-500">هیچ فرآیند گردش کاری برای این نوع قرارداد تعریف نشده است.</div>
            default: return null;
        }
    }

    return (
        <div className="bg-white p-6 rounded-lg shadow">
            <button onClick={onBack} className="flex items-center text-blue-600 mb-4 text-sm"><ArrowLeftIcon className="w-4 h-4 ml-2" /> بازگشت به لیست قراردادها</button>
            <div className="flex justify-between items-start mb-4 pb-4 border-b">
                <div>
                    <h2 className="text-xl font-bold">{contract.title}</h2>
                    <div className="flex items-center space-x-2 text-sm text-gray-500 mt-1">
                        <span>{contract.contractNumber}</span>
                        <StatusBadge status={contract.status} />
                    </div>
                </div>
                <div className="flex space-x-2">
                    <button className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 flex items-center"><TrashIcon className="w-4 h-4 ml-2" /> حذف</button>
                    <button className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 flex items-center"><PencilIcon className="w-4 h-4 ml-2" /> ویرایش</button>
                </div>
            </div>
            {/* Tabs */}
            <div className="border-b border-gray-200 mb-4">
                 <nav className="-mb-px flex space-x-4" aria-label="Tabs">
                    {['info', 'payments', 'guarantees', 'addendums', 'attachments', 'workflow'].map(tab => (
                        <button key={tab} onClick={() => setActiveTab(tab as any)} className={`${activeTab === tab ? 'border-purple-500 text-purple-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm`}>
                            { {info: 'اطلاعات کلی', payments: 'پرداخت‌ها', guarantees: 'ضمانت‌نامه‌ها', addendums: 'متمم‌ها', attachments: 'پیوست‌ها', workflow: 'گردش کار'}[tab] }
                        </button>
                    ))}
                </nav>
            </div>
            {renderTabContent()}
        </div>
    );
};

const InfoTab: React.FC<{contract: ContractDetails}> = ({contract}) => (
    <div className="space-y-6">
        <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-3">اطلاعات پایه</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div><p className="text-gray-500">عنوان:</p><p>{contract.title}</p></div>
                <div><p className="text-gray-500">شماره قرارداد:</p><p>{contract.contractNumber}</p></div>
                <div><p className="text-gray-500">طرف قرارداد:</p><p>{contract.party}</p></div>
                <div><p className="text-gray-500">کارفرما:</p><p>{contract.employer}</p></div>
                <div><p className="text-gray-500">شماره دستی:</p><p>{contract.manualContractNumber || '---'}</p></div>
                <div><p className="text-gray-500">نوع:</p><p>{contract.contractType}</p></div>
                <div><p className="text-gray-500">دسته‌بندی:</p><p>{contract.category}</p></div>
                 <div><p className="text-gray-500">مرکز مرتبط:</p><p>{contract.relatedCenter}</p></div>
            </div>
        </div>
        <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-3">اطلاعات مالی</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                 <div><p className="text-gray-500">مبلغ (ریال):</p><p>{contract.amount ? contract.amount.toLocaleString() : '---'}</p></div>
                 <div><p className="text-gray-500">مبلغ (ارزی):</p><p>---</p></div>
            </div>
        </div>
         <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-3">زمان‌بندی</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                 <div><p className="text-gray-500">تاریخ شروع:</p><p>{contract.startDate}</p></div>
                 <div><p className="text-gray-500">تاریخ پایان:</p><p>{contract.endDate}</p></div>
            </div>
        </div>
    </div>
);

interface GenericTabProps { title: string; data: any[]; headers: string[]; renderRow: (item: any, index: number) => React.ReactNode; onAdd: () => void; addText?: string;}
const GenericTab: React.FC<GenericTabProps> = ({ title, data, headers, renderRow, onAdd, addText }) => (
    <div>
        <div className="flex justify-between items-center mb-4">
             <h3 className="font-semibold">{title}</h3>
             {addText && <button onClick={onAdd} className="bg-blue-500 text-white px-3 py-1.5 rounded-md hover:bg-blue-600 text-sm flex items-center"><PlusIcon className="w-4 h-4 ml-2" />{addText}</button>}
        </div>
        {data.length > 0 ? (
            <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm text-right">
                    <thead className="bg-gray-50"><tr>{headers.map(h => <th key={h} className="p-3 font-semibold">{h}</th>)}</tr></thead>
                    <tbody>{data.map(renderRow)}</tbody>
                </table>
            </div>
        ) : <div className="text-center p-10 text-gray-500 border rounded-lg">هیچ موردی ثبت نشده است.</div>}
    </div>
);


const Contracts: React.FC = () => {
    const [view, setView] = useState<'LIST' | 'DETAILS'>('LIST');
    const [selectedContract, setSelectedContract] = useState<ContractDetails | null>(null);
    const [contracts, setContracts] = useState<Contract[]>([]);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalContent, setModalContent] = useState<React.ReactNode | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState<ContractStatus | 'all'>('all');

    const fetchData = async () => {
        setLoading(true);
        try {
            const data = await contractService.getContractList();
            setContracts(data);
        } catch (e) {
            console.error("Failed to fetch contracts:", e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (view === 'LIST') {
            fetchData();
        }
    }, [view]);

    const handleViewDetails = async (contractId: number) => {
        setLoading(true);
        try {
            const details = await contractService.getContractDetails(contractId);
            setSelectedContract(details);
            setView('DETAILS');
        } catch (e) {
            console.error("Failed to fetch contract details:", e);
        } finally {
            setLoading(false);
        }
    };
    
    const handleBackToList = () => {
        setView('LIST');
        setSelectedContract(null);
    };

    const handleOpenModal = (content: React.ReactNode) => {
        setModalContent(content);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setModalContent(null);
    };

    const handlePaymentSaved = (updatedContract: ContractDetails) => {
        setSelectedContract(updatedContract);
        handleCloseModal();
    };

    const handleSaveSuccess = (updatedContracts: Contract[]) => {
        setContracts(updatedContracts);
        handleCloseModal();
    };
    
    const filteredContracts = useMemo(() => {
        return contracts.filter(c => {
            const matchesSearch = c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                c.contractNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                c.party.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
            return matchesSearch && matchesStatus;
        });
    }, [contracts, searchTerm, statusFilter]);

    if (loading && !isModalOpen) {
        return <div className="text-center p-10">در حال بارگذاری...</div>;
    }

    return (
        <>
            {isModalOpen && <Modal onClose={handleCloseModal}>{modalContent}</Modal>}

            {view === 'LIST' && (
                <div className="bg-white p-6 rounded-lg shadow">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-lg font-semibold">لیست قراردادها</h2>
                        <div className="flex items-center space-x-2">
                            <input type="text" placeholder="جستجو در عنوان، شماره یا طرف قرارداد..." className="p-2 border border-gray-300 rounded-md text-sm w-72" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value as any)} className="p-2 border border-gray-300 rounded-md text-sm bg-white">
                                <option value="all">همه وضعیت‌ها</option>
                                {Object.values(ContractStatus).map(s => <option key={s as string} value={s as string}>{s as string}</option>)}
                            </select>
                            <button onClick={() => handleOpenModal(<NewContractForm onClose={handleCloseModal} onSaveSuccess={handleSaveSuccess} />)} className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 flex items-center">
                                <PlusIcon className="w-5 h-5 ml-2" />
                                ثبت قرارداد جدید
                            </button>
                        </div>
                    </div>
                    <div className="overflow-x-auto border rounded-lg">
                        <table className="w-full text-sm text-right">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="p-3 font-semibold">شماره قرارداد</th>
                                    <th className="p-3 font-semibold">عنوان</th>
                                    <th className="p-3 font-semibold">طرف قرارداد</th>
                                    <th className="p-3 font-semibold">مبلغ (ریال)</th>
                                    <th className="p-3 font-semibold">تاریخ پایان</th>
                                    <th className="p-3 font-semibold">وضعیت</th>
                                    <th className="p-3 font-semibold">عملیات</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading && contracts.length === 0 ? (
                                    <tr><td colSpan={7} className="text-center p-10">در حال بارگذاری...</td></tr>
                                ) : filteredContracts.map(c => (
                                    <tr key={c.id} className="border-b hover:bg-gray-50 cursor-pointer" onClick={() => handleViewDetails(c.id)}>
                                        <td className="p-3 font-mono text-xs">{c.contractNumber}</td>
                                        <td className="p-3 font-medium">{c.title}</td>
                                        <td className="p-3">{c.party}</td>
                                        <td className="p-3">{c.amount ? c.amount.toLocaleString() : '---'}</td>
                                        <td className="p-3">{c.endDate}</td>
                                        <td className="p-3"><StatusBadge status={c.status} /></td>
                                        <td className="p-3"><button className="text-blue-600 hover:underline text-xs">مشاهده</button></td>
                                    </tr>
                                ))}
                                 {filteredContracts.length === 0 && !loading && (
                                    <tr><td colSpan={7} className="text-center p-4 text-gray-500">هیچ قراردادی یافت نشد.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
            
            {view === 'DETAILS' && selectedContract && (
                <ContractDetailView 
                  contract={selectedContract} 
                  onBack={handleBackToList} 
                  onOpenModal={handleOpenModal} 
                  onCloseModal={handleCloseModal}
                  onPaymentSaved={handlePaymentSaved}
                />
            )}
        </>
    );
};

export default Contracts;
