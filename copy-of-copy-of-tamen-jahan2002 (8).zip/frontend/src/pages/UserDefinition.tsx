import React from 'react';
import type { Page } from '@shared/types';

interface UserDefinitionProps {
  setCurrentPage: (page: Page) => void;
}

const UserDefinition: React.FC<UserDefinitionProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4">تعریف کاربر جدید</h1>
      <p className="text-gray-600">این صفحه در حال ساخت است.</p>
       <button onClick={() => setCurrentPage('DASHBOARD')} className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md">بازگشت</button>
    </div>
  );
};

export default UserDefinition;
