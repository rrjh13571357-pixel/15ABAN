import React, { useEffect, useRef, useState } from 'react';
import Chart from 'chart.js/auto';
import { getProjectFinancialSummary, getStatusDistribution, getMonthlyRequestVolume } from '../services/reportService';
import type { ProjectFinancialSummary, StatusDistribution, MonthlyRequestVolume } from '@shared/types';


const ChartCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4 text-gray-700">{title}</h3>
        <div>{children}</div>
    </div>
);

const Reports: React.FC = () => {
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const projectChartRef = useRef<HTMLCanvasElement>(null);
    const statusChartRef = useRef<HTMLCanvasElement>(null);
    const volumeChartRef = useRef<HTMLCanvasElement>(null);
    
    const chartInstances = useRef<Chart[]>([]);

    useEffect(() => {
        const renderCharts = async () => {
            // Destroy previous charts before rendering new ones
            chartInstances.current.forEach(instance => instance.destroy());
            chartInstances.current = [];

            try {
                const [projectData, statusData, volumeData] = await Promise.all([
                    getProjectFinancialSummary(),
                    getStatusDistribution(),
                    getMonthlyRequestVolume()
                ]);

                // Project Financial Summary Chart
                if (projectChartRef.current) {
                    const projectChart = new Chart(projectChartRef.current, {
                        type: 'bar',
                        data: projectData,
                        options: {
                            responsive: true,
                            plugins: { legend: { position: 'top' } },
                            scales: { y: { beginAtZero: true } }
                        },
                    });
                    chartInstances.current.push(projectChart);
                }
                
                // Contract Status Distribution Chart
                if (statusChartRef.current) {
                     const statusChart = new Chart(statusChartRef.current, {
                        type: 'doughnut',
                        data: statusData,
                        options: {
                            responsive: true,
                            plugins: { legend: { position: 'top' } },
                        },
                    });
                    chartInstances.current.push(statusChart);
                }
                
                // Monthly Request Volume Chart
                if (volumeChartRef.current) {
                     const volumeChart = new Chart(volumeChartRef.current, {
                        type: 'line',
                        data: volumeData,
                        options: {
                            responsive: true,
                            plugins: { legend: { position: 'top' } },
                            scales: { y: { beginAtZero: true } }
                        },
                    });
                    chartInstances.current.push(volumeChart);
                }

            } catch (err) {
                console.error("Failed to fetch or render chart data:", err);
                setError("خطا در دریافت داده‌های گزارش.");
            } finally {
                setLoading(false);
            }
        };

        renderCharts();

        // Cleanup function to destroy chart instances on component unmount
        return () => {
            chartInstances.current.forEach(instance => instance.destroy());
        };

    }, []);

    if (loading) {
        return <div className="text-center p-10">در حال بارگذاری گزارش‌ها...</div>;
    }
    
    if (error) {
         return <div className="text-center p-10 text-red-500">{error}</div>;
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="lg:col-span-2">
                <ChartCard title="خلاصه مالی ۵ پروژه برتر (بر اساس بودجه ریالی)">
                    <canvas ref={projectChartRef}></canvas>
                </ChartCard>
            </div>
            <div>
                 <ChartCard title="توزیع وضعیت قراردادها">
                    <canvas ref={statusChartRef}></canvas>
                </ChartCard>
            </div>
             <div>
                 <ChartCard title="حجم درخواست‌های ماهانه (شبیه‌سازی شده)">
                    <canvas ref={volumeChartRef}></canvas>
                </ChartCard>
            </div>
        </div>
    );
};

export default Reports;
