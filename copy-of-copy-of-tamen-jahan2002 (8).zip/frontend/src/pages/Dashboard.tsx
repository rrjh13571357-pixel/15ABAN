import React, { useState, useEffect } from 'react';
import { getRequests } from '../services/requestService';
import { RequestStatus } from '@shared/types';
import type { Request, Page, RequestDetails, SystemUser, ComposeLetterPayload } from '@shared/types';
import { PlusIcon } from '../components/Icons';
import RequestDetailsModal from '../components/RequestDetailsModal';

interface DashboardCardProps {
  title: string;
  value: string | number;
  unit: string;
  icon: React.ReactNode;
  color: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ title, value, unit, icon, color }) => (
  <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex items-center justify-between">
    <div>
      <p className="text-slate-500 font-medium text-sm">{title}</p>
      <p className="text-2xl font-bold text-slate-800 mt-1">
        {value} <span className="text-base font-medium text-slate-600">{unit}</span>
      </p>
    </div>
    <div className={`p-3 rounded-full ${color}`}>
      {icon}
    </div>
  </div>
);

const statusStyles: Record<RequestStatus, string> = {
  [RequestStatus.InProgress]: 'bg-blue-100 text-blue-700',
  [RequestStatus.Pending]: 'bg-yellow-100 text-yellow-700',
  [RequestStatus.Rejected]: 'bg-red-100 text-red-700',
  [RequestStatus.Completed]: 'bg-green-100 text-green-700',
};

const StatusBadge: React.FC<{ status: RequestStatus }> = ({ status }) => (
  <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${statusStyles[status]}`}>
    {status}
  </span>
);

interface DashboardProps {
  setCurrentPage: (page: Page) => void;
  onEditRequest: (request: RequestDetails) => void;
  currentUser: SystemUser;
  onSendToAutomation: (payload: ComposeLetterPayload) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ setCurrentPage, onEditRequest, currentUser, onSendToAutomation }) => {
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);


  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const data = await getRequests();
        setRequests(data);
      } catch (error) {
        console.error("Failed to fetch requests:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchRequests();
  }, []);

  if (loading) {
    return <div className="text-center p-10">در حال بارگذاری...</div>;
  }

  return (
    <>
      <div className="space-y-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <DashboardCard
            title="کارهای منتظر اقدام من"
            value={6}
            unit=""
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            color="bg-indigo-100"
          />
          <DashboardCard
            title="درخواست های اخیر من"
            value={7}
            unit=""
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-sky-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>}
            color="bg-sky-100"
          />
          <DashboardCard
            title="کار درخواست های در جریان"
            value={15}
            unit=""
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 14l9-5-9-5-9 5 9 5z" /><path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-5.998 12.078 12.078 0 01.665-6.479L12 14z" /><path strokeLinecap="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-5.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222 4 2.222V20" /></svg>}
            color="bg-amber-100"
          />
          <DashboardCard
            title="مبلغ تایید شده این ماه"
            value="2,170,011"
            unit="ریال"
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
            color="bg-emerald-100"
          />
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-lg font-bold text-slate-800">کارتابل درخواست‌ها</h2>
            <button
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center font-semibold text-sm"
              onClick={() => setCurrentPage('NEW_REQUEST')}
            >
              <PlusIcon className="w-5 h-5 ml-2" />
              ثبت درخواست جدید
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="p-3 font-semibold">#</th>
                  <th className="p-3 font-semibold">شماره</th>
                  <th className="p-3 font-semibold">موضوع</th>
                  <th className="p-3 font-semibold">درخواست‌کننده</th>
                  <th className="p-3 font-semibold">مبلغ</th>
                  <th className="p-3 font-semibold">تاریخ ثبت</th>
                  <th className="p-3 font-semibold">تاریخ سررسید</th>
                  <th className="p-3 font-semibold">وضعیت</th>
                  <th className="p-3 font-semibold">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {requests.map((req, index) => (
                  <tr key={req.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4 font-mono text-xs">{req.id}</td>
                    <td className="p-4 font-medium">{req.subject}</td>
                    <td className="p-4">{req.applicant}</td>
                    <td className="p-4">{req.amount.rial.toLocaleString()}</td>
                    <td className="p-4">{req.date}</td>
                    <td className="p-4">{req.deadline || '---'}</td>
                    <td className="p-4"><StatusBadge status={req.status} /></td>
                    <td className="p-4">
                      <button onClick={() => setSelectedRequestId(req.id)} className="text-indigo-600 hover:text-indigo-800 font-semibold text-xs">مشاهده</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {selectedRequestId && (
        <RequestDetailsModal 
          requestId={selectedRequestId} 
          onClose={() => setSelectedRequestId(null)} 
          currentUser={currentUser}
          onEditRequest={onEditRequest}
          onSendToAutomation={onSendToAutomation}
        />
      )}
    </>
  );
};

export default Dashboard;
