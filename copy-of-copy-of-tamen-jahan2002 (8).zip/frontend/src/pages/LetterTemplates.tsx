import React from 'react';

const LetterTemplates: React.FC = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4">مدیریت قالب نامه‌ها</h1>
      <p className="text-gray-600">این صفحه در حال ساخت است.</p>
    </div>
  );
};

export default LetterTemplates;
