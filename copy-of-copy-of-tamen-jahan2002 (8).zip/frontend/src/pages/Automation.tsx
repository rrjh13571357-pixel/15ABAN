import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { getInbox, getLetter, sendLetter } from '../services/automationService';
import { getSystemUsers, getRoles } from '../services/identityService';
import { getOrgUnits } from '../services/organizationService';
import { InboxLetter, Letter, LetterStatus, LetterPriority, Page, SystemUser, ComposeLetterPayload, LetterAttachment, OrganizationalUnit, Role } from '@shared/types';
import { timeAgo } from '../utils/time';
import { ArrowLeftIcon, PencilIcon, MagnifyingGlassIcon, ArchiveBoxIcon, ArrowUturnLeftIcon, ArrowUturnRightIcon, PaperAirplaneIcon, PaperClipIcon, XCircleIcon, ChevronUpDownIcon } from '../components/Icons';
import RichTextEditor from '../components/RichTextEditor';

// --- Default Logos (Base64) ---
const DEFAULT_IRAN_LOGO_BASE64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAd8SURBVHhe7Z1/aFxVFMfvHy/F2qAUtWJBNRj8IVaMItgoiGAFsbCLYhdsLCirELtFG2zSVrAVsIn+sFRUFGx0sVQRK/gPglJa0aZIKdgiqGAnadI2n9/Mvffe3Tfv3n0z74cveNjdOffO/e4799577j0RCAQCAQKBQCAQCAQCAQKBQCAQCAQCAQKBQCAQCAQCAQKBQCAQCAQCgeC/oE9PT/E6nZ+ff3pwcFDvW11d5W25ubl1d3e38y+jI/8kCILd3t76tbe3/fPz838gCH7Lpjl579qG4eD+5ORk21A2my3/Ly8v/91kMtlmsxms8p+bmwvz39raKnc6nXg8HhYhQRC02+2y/Pj4uD08PMjNzc1bW1s/ZavVKuvz+Vx2cnJCyM3NbXiQzc3NnZ2dFfL5/J6enraDg4NsYWEhOzo6kKurqw/39/f/vLOzQW02m1gsFga7ubmZTCaD0Ov14uFwgP50Oi0vLy+TyWQ1NTW+7Ozs/F6vV2w2m1wul91ul5TLZTaZTEilUul0OvF4PMRqtWp5eRkOh0M0Go3f7yfUarVQKIRcXV1pa2tLbW1tOp0OMpksGo1GqVQSj8fD5/ORyWQqlUq0Wi1utxsulwsulwudTgdRKBQqlQpGo1F/jUbD5/MRiURCGAwGubm5UavVyuXy7r7h4eHh3t7ePtbW1nS5XO649/X1dbVabVVVVWfPzc19m0wm3d/f96Wnp+dMJtP9/f1+f39/m81m3dXVlZqamu7u7i4Oh8PhcDiRSCSDwQCsVqvRaDTUarVYLBYOh0OkUqlcLhfL5XKw3+/F4/GQyWTSaDS+vr4qlUphMBgMBoNarYYYDAaxWCy8Xi/cbrfdbhfxeBzy+Xy5XK6jo4Pc3t6+vb0t7+7u/nF/f/83Wq02l8vV0tLiPz4+lp2cnHB3d/deXl7k5ubm4uJCtLe3v729TY/HIx6Ph9vtFovFwmaz+Xw+wuFwyGQy8Xg8YrGYWCwWNputVqtRLpdpaWlRrVbZbDYej0cwGAym02mxWCwSiQTf3t6+vLxMrlarVCpD9ff30+l0YDAYFAqFZrMZDoeDYDAYFAqFcrkcDAaDRCLh9/uVSCQcDofP5yMajeZyuTCbzWKxWDQaDSaTiUQigclk/n78G+jCwkIlEgmZTCaXy6VQKFAoFEqlkkqlEovFIpFIYLFYIpEIHo+Hy+VCrVbDbrfL5XKhVCqlUqlCoRCJRILFYolEIoFAAIvFIhKJ+L1eJBJBrVYLhUINDQ3hcrmw2WxKpRINDQ2RSCSz2ayvr6/6fD6TyRS/38/n86Fer1MoFFwuFwaDQalUYDAYJBIJ4XAYxGIxGo1GrVb7+PjQarVKpVLNZvN//z4oFIrC4fAvxGq1HhwcZPv6+pibmxtcXFwcHBzwN2w2m8vlYmdnZ2BgoN/f3yEIglAohFAohMPhEIlEMJlMGo2GVCpFqVRiNBqxWCxmshuMxt2+EgwGWV5eXjw8PFhbW1uYm5uDGhoaGBoamp6e7u/vD3d3d52dnTUaDWq1GhKJBJvNBolEApPJhMFgwGw2w2AwgNVqhcPhQKlUwmg0wmw2g8lkwmazRaNR0Gg02GxmNBohk8lQqVSo1WpCoRBSqRQikQhcLhdaWlppaWnRarWCz+dDoVAKhQIAfD4fYrEYgUAAgUAAAADL5QKv1wt+vw+FQgEAGAwG4Ha7YXK5AADg9XrF6XQAgKurqyEAAoFAoFAoFAoFAgEAAAAAgFAoAACKxWLcbjccDgeHwwEAODo6Qv8fHR0l/wG0WCzm8/lCoVCj0eg/Pj5WKBQKhUK/36/Van0+H/f7fTQaDQiF4mAwMBgMHA6HIpEIHo8HzGazXC6HZDKJXC5HoVAglUqRSqVCodBut+NyuYhEIuFwOBwOBxiNRoFA4Pf7gcFgQCaTAQAoFovJZEIMBgMAcDgcyOVyMBgMYDAYyOVyyGQyiEQisVgspFJpcDgcPp+PXC4XjUaFw+EQi8UqlUrtdrt8Ph9+vx/+/n/WUCgUg8GAWCxGJpNBpVLNZlMKheLz+XA4HKFQCB6Ph0aj0ev1wm63i0Qi4fV6oVAodDodcrkctVotk8mkUqkwmUwUCoVYLEaj0YiFw6FQyOVyYRj8X7lcrlarxWq1wufz4XA4JBIJubm5+fT0pFarxcPDIZFI+L1eOp0OALBYLDQaDQ6HI5FIJBIJg8FAoVDodDqRSCSDwSCZTDo8PBz29fUJBwfH9fV1Go2GkZGRtLS09fX1paWlRWlpaW1tbXV1dSUnJwcA+Hy+qKgoHo8Hc3NzaWlpycnJycnJSUlJycnJycXFxcnJSUpKSkpKSkpKSsrKysrOzs7Pz8/Q0NBXV1ff2toqJydnZ2cnKysrLS0tLS0tycnJiYmJycnJKSkp2djYKDc3V2JiYnBwsKurq4mJiampqaWlpaGhoaGhobm5ubm5ubmpqaGhobGxsbm5ubm5ubm5ubnJycXV1dXV1dXV1dXV1dXV1dXV1dXFxcXBwcHh4eFxcXFxcXFxcXF5eXl5eXl1dXW1tbV1dXW1tbV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXW1tbW1tbW1tbW1tbW1tbW1tbbW1tf8j3N/fT6VSiVqtFovFEggEAoHA6/WCwWCQyWRCoRBCoVAoFJBIJPAfQCAQCATyfw4FAoFAIBAIBAKBQCAQCAQCAQKBQCAQCAQCAQKBQCAQCAT6D8+8M1Zp6L1VAAAAAElFTkSuQmCC';
const DEFAULT_ORG_LOGO_BASE64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAANYSURBVHhe7d2/ThRRFMfxT4oJE1ESExMb0cbESrAVLCwtLCwtbCwstLSw8A+wsLAYgo2FjQk2JhojJsZEYzCBiSgRXPe73L0zd+6dO/O5T+5L7p577jtnbmdmJv/nCWAHk0+Q+ASJT5D4BIlPkPgEiU+Q+ASJT5D4BIlPkPgEiU+Q+ASJT5D4BIlPkPgEiU+Q+ASJT5D4BIlPkPgEie8k8k+v5+r8L1WnS7vO92k6nb49P/f3V/S4s18cHeS/YqY0zGv/L+fntXo8Hh2v1+vl4eH5n/fL+7S8vEwnk8n/+Xx+rKenJ7vdLuVwOMhkMhAej2eVSiUUCoVyuRyNRgMAgEajkUgkUq1WCwQCpVIpHo8HAACBQCAWi0WhUAQCARqNBpPJxGazWSwWAQAAoFAoEAhEo9GIxWKxWCzy+XwAAEQikUgkgiCIUqmEyWSCIAgikQiFQgEAAABBEIvFAEqlkjebzWazeTweeTyeVCp1e3tbrVarVCr5vN1uN5vNfr8/kUhkMpkYDAYAgMfjEYvFKpVKJpMJAABBEJfLRSKRCIVCSJLEer0GAACCIJFIpFAoJEnS6XSi0ShJkhQKhclkEgwGAwAAgiASiUShUJLNZqlUKgDAZrNJJBIEQQAASIJYLJYkSWq1WiwWI0kSgUAAgiASiSQWi0mlUhAEEQqFJEmxWCwWi6VSqWQyGQCAJEmj0UilUjQaDYIgPp+PQqHI5/MRCARyuRxJkmQyGZFIpFAoRCIRgUAgk8lAkiSLxSKRSCKRCDabDQDw+/1qtVqSJDUajUgkgiBIqVRarVb39/fUSqVYLJaHhwdJkslkEo1GJZPJrq6urq+vK5fLZDIZAAD5fP7g4CBJkgRBXC4XgiCAIHA6nWKxGAgEgkQioVKpNBqNJEmNRqNCoZDJZBqNRhAEvV4vEolgNps8Hg+ZTGZychIAYLPZZDIZgiBCoRDVajWbzWa1WkmlUjabDYIgFosFn89HoVB4PB739/fJZDIYDAaZTAaDwQAAwGazgSAIAgAwGAwUCoUgCEqlEhKJRCAQCIVCpFKpVCqFRqMBgOMo8E9hB5NPIOEJEp8g8QkSn2i+D2g09Ea+AAAAAElFTkSuQmCC';

const priorityStyles: Record<LetterPriority, string> = {
    [LetterPriority.Normal]: 'bg-gray-100 text-gray-800',
    [LetterPriority.Confidential]: 'bg-yellow-100 text-yellow-800',
    [LetterPriority.Urgent]: 'bg-red-100 text-red-800',
};

const PriorityBadge: React.FC<{ priority: LetterPriority }> = ({ priority }) => (
    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${priorityStyles[priority]}`}>
        {priority}
    </span>
);

interface AutomationProps {
    setCurrentPage: (page: Page) => void;
    initialPayload: ComposeLetterPayload | null;
    onPayloadConsumed: () => void;
}

type ViewState = 'LIST' | 'DETAILS' | 'COMPOSE';
type LetterDetails = Letter & { senderName: string, recipientNames: string[], senderUnitName: string, recipientUnitName: string, signatory: { name: string, title: string } };

const Field: React.FC<{label: string, children: React.ReactNode, className?: string}> = ({label, children, className=""}) => (
    <div className={`flex items-baseline ${className}`}>
        <span className="font-bold text-sm w-16 flex-shrink-0">{label}:</span>
        <div className="flex-1">{children}</div>
    </div>
);

const FinalText: React.FC<{value: string}> = ({value}) => <p className="text-sm font-medium pr-2">{value || '---'}</p>;

interface LetterViewProps {
    letter: any;
    isFinalized: boolean;
    onFieldChange?: (field: keyof ComposeState, value: any) => void;
    onFileChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onRemoveAttachment?: (fileName: string) => void;
    onViewAttachment?: (attachment: LetterAttachment) => void;
    allUsers?: SystemUser[];
    allUnits?: OrganizationalUnit[];
}
const LetterView = React.memo<LetterViewProps>(({ letter, isFinalized, onFieldChange, onFileChange, onRemoveAttachment, onViewAttachment, allUsers = [], allUnits = [] }) => {
    const [iranLogo, setIranLogo] = useState(() => localStorage.getItem('letterIranLogo') || DEFAULT_IRAN_LOGO_BASE64);
    const [orgLogo, setOrgLogo] = useState(() => localStorage.getItem('letterOrgLogo') || DEFAULT_ORG_LOGO_BASE64);
    const [iranLogoSize, setIranLogoSize] = useState(() => localStorage.getItem('letterIranLogoSize') || '64');
    const [orgLogoSize, setOrgLogoSize] = useState(() => localStorage.getItem('letterOrgLogoSize') || '64');
    
    const iranLogoInputRef = useRef<HTMLInputElement>(null);
    const orgLogoInputRef = useRef<HTMLInputElement>(null);

    const handleLogoChange = (logoType: 'iran' | 'org', file: File | null) => {
        if (!file) return;
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const base64 = reader.result as string;
            if (logoType === 'iran') {
                localStorage.setItem('letterIranLogo', base64);
                setIranLogo(base64);
            } else {
                localStorage.setItem('letterOrgLogo', base64);
                setOrgLogo(base64);
            }
        };
    };

    const handleSizeChange = (logoType: 'iran' | 'org', size: string) => {
        if (logoType === 'iran') {
            setIranLogoSize(size);
            localStorage.setItem('letterIranLogoSize', size);
        } else {
            setOrgLogoSize(size);
            localStorage.setItem('letterOrgLogoSize', size);
        }
    };

    return (
        <div className="max-w-[210mm] min-h-[297mm] mx-auto bg-white shadow-lg p-12 flex flex-col font-serif border-4 border-double border-gray-400">
            <input type="file" ref={iranLogoInputRef} onChange={e => handleLogoChange('iran', e.target.files?.[0] || null)} className="hidden" accept="image/*" />
            <input type="file" ref={orgLogoInputRef} onChange={e => handleLogoChange('org', e.target.files?.[0] || null)} className="hidden" accept="image/*" />

            {/* Header */}
            <header className="flex justify-between items-start border-b-2 border-black pb-4">
                 <div className="relative w-1/4 flex justify-start">
                    <div>
                        <img src={orgLogo} alt="لوگوی سازمان" className="object-contain" style={{width: `${orgLogoSize}px`, height: `${orgLogoSize}px`}} />
                         {!isFinalized && (
                            <>
                                <button type="button" onClick={() => orgLogoInputRef.current?.click()} className="absolute top-0 left-0 bg-white rounded-full p-1 border shadow-sm hover:bg-gray-100" title="تغییر لوگوی سازمان">
                                    <PencilIcon className="w-3 h-3 text-gray-600"/>
                                </button>
                                 <input type="range" min="40" max="200" value={orgLogoSize} onChange={e => handleSizeChange('org', e.target.value)} className="w-24 mt-2 h-1"/>
                            </>
                        )}
                    </div>
                </div>
                <div className="flex flex-col items-center w-1/2">
                    <div className="relative">
                       <img src={iranLogo} alt="لوگوی جمهوری اسلامی" className="object-contain" style={{width: `${iranLogoSize}px`, height: `${iranLogoSize}px`}} />
                       {!isFinalized && (
                            <button type="button" onClick={() => iranLogoInputRef.current?.click()} className="absolute -bottom-2 -right-2 bg-white rounded-full p-1 border shadow-sm hover:bg-gray-100" title="تغییر لوگوی جمهوری اسلامی">
                                <PencilIcon className="w-3 h-3 text-gray-600"/>
                            </button>
                        )}
                    </div>
                    {!isFinalized && (
                        <input type="range" min="40" max="200" value={iranLogoSize} onChange={e => handleSizeChange('iran', e.target.value)} className="w-24 mt-2 h-1"/>
                    )}
                </div>
                 <div className="text-xs space-y-1 text-left w-1/4">
                    <p>شماره: <span className="font-sans">{letter.id ? letter.id : 'خودکار'}</span></p>
                    <div className="flex items-center justify-end">
                        <span className="flex-shrink-0">تاریخ: </span>
                        {isFinalized ? 
                            <span className="font-sans mr-1">{letter.letterDate}</span> :
                            <input type="text" value={letter.letterDate} onChange={e => onFieldChange!('letterDate', e.target.value)} className="font-sans p-1 border-b w-24 mr-1"/>
                        }
                    </div>
                    <p>پیوست: <span className="font-sans">{letter.attachments.length > 0 ? 'دارد' : 'ندارد'}</span></p>
                </div>
            </header>
            
            {/* Body */}
            <main className="flex-1 mt-8 space-y-4">
                 <Field label="از">
                    {isFinalized ? <FinalText value={letter.senderUnitName} /> : (
                        <select value={letter.senderUnitId} onChange={e => onFieldChange!('senderUnitId', e.target.value)} className="w-full p-1 border-b bg-white text-sm font-sans">
                            <option value="">-- انتخاب واحد --</option>
                            {allUnits.map(u => <option key={u.id} value={u.id}>{u.title}</option>)}
                        </select>
                    )}
                </Field>
                <Field label="به">
                    {isFinalized ? <FinalText value={letter.recipientUnitName} /> : (
                         <select value={letter.recipientUnitId} onChange={e => onFieldChange!('recipientUnitId', e.target.value)} className="w-full p-1 border-b bg-white text-sm font-sans">
                            <option value="">-- انتخاب واحد --</option>
                            {allUnits.map(u => <option key={u.id} value={u.id}>{u.title}</option>)}
                        </select>
                    )}
                </Field>
                 <Field label="موضوع">
                    {isFinalized ? <FinalText value={letter.subject} /> : (
                        <input type="text" value={letter.subject} onChange={e => onFieldChange!('subject', e.target.value)} className="w-full p-1 border-b text-sm font-sans" />
                    )}
                </Field>

                <div className="pt-8 min-h-[10cm]">
                    {isFinalized ? (
                        <div className="prose prose-sm max-w-none ck-content" dangerouslySetInnerHTML={{ __html: letter.content }}></div>
                    ) : (
                        <div className="border rounded-lg p-2 h-full"><RichTextEditor value={letter.content} onChange={(data: string) => onFieldChange!('content', data)} /></div>
                    )}
                </div>
            </main>
            
            {/* Footer */}
            <footer className="mt-auto pt-16">
                 <div className="grid grid-cols-2">
                    <div className="col-start-2 text-center space-y-1">
                        {isFinalized ? (
                            <>
                                <p className="font-semibold">{letter.signatory.name}</p>
                                <p className="text-sm text-gray-600">{letter.signatory.title}</p>
                            </>
                        ) : (
                            <div>
                                <label className="text-xs">امضا کننده</label>
                                <select value={letter.signatoryId || ''} onChange={e => onFieldChange!('signatoryId', Number(e.target.value))} className="w-full p-1 border-b bg-white text-sm font-sans mt-2">
                                    <option value="">-- انتخاب کنید --</option>
                                    {allUsers.map(u => <option key={u.id} value={u.id}>{u.fullName}</option>)}
                                </select>
                            </div>
                        )}
                    </div>
                </div>

                {letter.attachments.length > 0 && (
                    <div className="mt-12 border-t pt-4">
                        <h3 className="font-bold text-sm mb-2">پیوست‌ها:</h3>
                        <ul className="space-y-1">
                            {letter.attachments.map((att: any, i: number) => {
                                const dataUrl = `data:${att.mimeType};base64,${att.fileContent}`;
                                return (
                                    <li key={i} className="flex items-center justify-between text-sm py-1">
                                        <div className="flex items-center">
                                            <PaperClipIcon className="w-4 h-4 ml-2" />
                                            <span className="font-sans">{att.fileName}</span>
                                        </div>
                                        <div className="flex items-center space-x-3 space-x-reverse">
                                            <button type="button" onClick={() => onViewAttachment!(att)} className="text-blue-600 hover:underline text-xs font-sans">نمایش</button>
                                            <a href={dataUrl} download={att.fileName} className="text-green-600 hover:underline text-xs font-sans">دانلود</a>
                                            {!isFinalized && (
                                                <button type="button" onClick={() => onRemoveAttachment!(att.fileName)}><XCircleIcon className="w-4 h-4 text-red-500" /></button>
                                            )}
                                        </div>
                                    </li>
                                )
                            })}
                        </ul>
                    </div>
                )}
                 {!isFinalized && onFileChange && (
                    <div className="mt-4 border-t pt-4">
                        <label className="block text-sm font-bold mb-2">افزودن پیوست</label>
                        <input type="file" multiple onChange={onFileChange} className="w-full text-sm text-gray-500 file:mr-4 file:py-1 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
                    </div>
                )}
            </footer>
        </div>
    );
});

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = (reader.result as string).split(',')[1];
            if (result) resolve(result);
            else reject(new Error("File conversion failed."));
        };
        reader.onerror = error => reject(error);
    });
};

interface ComposeViewProps {
    onCancel: () => void;
    onSuccess: () => void;
    initialPayload: ComposeLetterPayload | null;
    onPayloadConsumed: () => void;
}

type ComposeState = {
    letterDate: string;
    senderUnitId: string;
    recipientUnitId: string;
    subject: string;
    content: string;
    recipientIds: number[];
    signatoryId: number | null;
    attachments: Omit<LetterAttachment, 'id'>[];
    priority: LetterPriority;
};

const ComposeView: React.FC<ComposeViewProps> = ({ onCancel, onSuccess, initialPayload, onPayloadConsumed }) => {
    const [users, setUsers] = useState<SystemUser[]>([]);
    const [orgUnits, setOrgUnits] = useState<OrganizationalUnit[]>([]);
    const [roles, setRoles] = useState<Role[]>([]);
    const [loading, setLoading] = useState(true);
    const [isFinalized, setIsFinalized] = useState(false);
    const [isSending, setIsSending] = useState(false);
    const [viewingAttachment, setViewingAttachment] = useState<LetterAttachment | null>(null);

    const [letterState, setLetterState] = useState<ComposeState>({
        letterDate: new Date().toLocaleDateString('fa-IR-u-nu-latn', { year: 'numeric', month: '2-digit', day: '2-digit' }),
        senderUnitId: '',
        recipientUnitId: '',
        subject: '',
        content: '<p>با سلام و احترام،</p><p></p><p>با تشکر</p>',
        recipientIds: [] as number[],
        signatoryId: null as number | null,
        attachments: [] as Omit<LetterAttachment, 'id'>[],
        priority: LetterPriority.Normal,
    });
    
    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [userData, unitData, roleData] = await Promise.all([getSystemUsers(), getOrgUnits(), getRoles()]);
                setUsers(userData);
                setOrgUnits(unitData);
                setRoles(roleData);
            } catch (e) { console.error(e); } finally { setLoading(false); }
        };
        fetchData();
    }, []);
    
     useEffect(() => {
        if (initialPayload?.initialSubject) {
            setLetterState(s => ({...s, subject: initialPayload.initialSubject}));
            onPayloadConsumed();
        }
    }, [initialPayload, onPayloadConsumed]);

     const handleSend = async () => {
        if (!letterState.subject || !letterState.senderUnitId || !letterState.recipientUnitId || !letterState.signatoryId) {
            alert('لطفا تمام فیلدهای اصلی نامه (از، به، موضوع، امضا) را تکمیل کنید.');
            return;
        }
        setIsSending(true);
        try {
            await sendLetter({ ...letterState, signatoryId: letterState.signatoryId!, recipientIds: [6] }); // Mock recipient
            alert('نامه با موفقیت ارسال شد.');
            onSuccess();
        } catch (error) {
            console.error(error);
            alert('خطا در ارسال نامه.');
        } finally {
            setIsSending(false);
        }
    }
    
     const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const newAttachments: Omit<LetterAttachment, 'id'>[] = [...letterState.attachments];
            for (let i = 0; i < e.target.files.length; i++) {
                const file = e.target.files[i];
                if (file) {
                    const fileContent = await fileToBase64(file);
                    newAttachments.push({ fileName: file.name, fileContent, mimeType: file.type });
                }
            }
            setLetterState(s => ({...s, attachments: newAttachments}));
            e.target.value = '';
        }
    };
    
    const removeAttachment = (fileName: string) => {
        setLetterState(s => ({...s, attachments: s.attachments.filter(att => att.fileName !== fileName)}));
    };
    
    const letterForView = useMemo(() => {
        const signatoryUser = users.find(u => u.id === letterState.signatoryId);
        const signatoryRole = signatoryUser ? roles.find(r => r.id === signatoryUser.roleId) : null;

        return {
            ...letterState,
            senderName: '', // Not needed for compose view
            recipientNames: [], // Not needed for compose view
            senderUnitName: orgUnits.find(u => u.id === letterState.senderUnitId)?.title || '',
            recipientUnitName: orgUnits.find(u => u.id === letterState.recipientUnitId)?.title || '',
            signatory: {
                name: signatoryUser?.fullName || '',
                title: signatoryRole?.title || ''
            }
        };
    }, [letterState, users, orgUnits, roles]);
    
    const handleFieldChange = useCallback((field: keyof ComposeState, value: any) => {
        setLetterState(s => ({...s, [field]: value}));
    }, []);
    
    if (loading) return <div className="text-center p-10">در حال بارگذاری...</div>;

    return (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 h-full flex flex-col">
            <div className="p-4 border-b flex justify-between items-center flex-shrink-0">
                <h2 className="text-xl font-bold">ایجاد نامه جدید</h2>
                 <div className="flex space-x-2 space-x-reverse">
                    {isFinalized ? (
                         <>
                            <button onClick={() => setIsFinalized(false)} className="bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 font-semibold text-sm">ویرایش</button>
                            <button onClick={handleSend} disabled={isSending} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center font-semibold text-sm disabled:bg-gray-400">
                                <PaperAirplaneIcon className="w-4 h-4 ml-2 -rotate-45" />
                                {isSending ? 'در حال ارسال...' : 'ارسال نامه'}
                            </button>
                         </>
                    ) : (
                        <button onClick={() => setIsFinalized(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-semibold text-sm">ثبت نهایی</button>
                    )}
                    <button onClick={onCancel} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 font-semibold text-sm">انصراف</button>
                </div>
            </div>
             <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
                <LetterView 
                    letter={letterForView} 
                    isFinalized={isFinalized}
                    onFieldChange={handleFieldChange}
                    onFileChange={handleFileChange}
                    onRemoveAttachment={removeAttachment}
                    allUsers={users}
                    allUnits={orgUnits}
                    onViewAttachment={setViewingAttachment}
                />
            </div>
        </div>
    );
};


const Automation: React.FC<AutomationProps> = ({ setCurrentPage, initialPayload, onPayloadConsumed }) => {
    const [view, setView] = useState<ViewState>('LIST');
    const [letters, setLetters] = useState<InboxLetter[]>([]);
    const [selectedLetter, setSelectedLetter] = useState<LetterDetails | null>(null);
    const [selectedLetterId, setSelectedLetterId] = useState<number | null>(null);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [viewingAttachment, setViewingAttachment] = useState<LetterAttachment | null>(null);


    useEffect(() => {
        if (initialPayload) {
            setView('COMPOSE');
        }
    }, [initialPayload]);

    useEffect(() => {
        const fetchInbox = async () => {
            setLoading(true);
            try {
                const data = await getInbox();
                setLetters(data);
            } catch (error) {
                console.error("Failed to fetch inbox:", error);
            } finally {
                setLoading(false);
            }
        };

        if (view === 'LIST') {
            fetchInbox();
        }
    }, [view]);

    useEffect(() => {
        const fetchLetterDetails = async () => {
            if (view === 'DETAILS' && selectedLetterId !== null) {
                setLoading(true);
                try {
                    const data = await getLetter(selectedLetterId);
                    setSelectedLetter(data);
                } catch (error) {
                    console.error("Failed to fetch letter details:", error);
                } finally {
                    setLoading(false);
                }
            }
        };
        fetchLetterDetails();
    }, [view, selectedLetterId]);


    const handleViewDetails = (letterId: number) => {
        setSelectedLetterId(letterId);
        setView('DETAILS');
    };

    const handleBackToList = () => {
        setView('LIST');
        setSelectedLetter(null);
        setSelectedLetterId(null);
    };
    
    const handleCompose = () => {
        setView('COMPOSE');
    }

    const filteredLetters = useMemo(() => {
        return letters.filter(l =>
            l.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
            l.senderName.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [letters, searchTerm]);

    const renderListView = () => (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 h-full flex flex-col">
            <div className="p-4 border-b flex justify-between items-center">
                <div className="relative w-full max-w-sm">
                    <input
                        type="text"
                        placeholder="جستجو در موضوع یا فرستنده..."
                        className="w-full p-2 pl-10 border rounded-lg text-sm"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                    <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                </div>
                <button onClick={handleCompose} className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center font-semibold text-sm whitespace-nowrap">
                    <PencilIcon className="w-4 h-4 ml-2" />
                    نامه جدید
                </button>
            </div>
            <div className="overflow-x-auto flex-1">
                <table className="w-full text-sm text-right">
                    <thead className="sticky top-0 bg-gray-50 z-10">
                        <tr>
                            <th className="p-3 font-semibold w-8"></th>
                            <th className="p-3 font-semibold">فرستنده</th>
                            <th className="p-3 font-semibold">موضوع</th>
                            <th className="p-3 font-semibold"></th>
                            <th className="p-3 font-semibold">تاریخ</th>
                            <th className="p-3 font-semibold">اولویت</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={6} className="text-center p-10">در حال بارگذاری نامه‌ها...</td></tr>
                        ) : filteredLetters.length > 0 ? (
                            filteredLetters.map(letter => (
                                <tr key={letter.id} className="border-b hover:bg-gray-50 cursor-pointer" onClick={() => handleViewDetails(letter.id)}>
                                    <td className="p-3 text-center">
                                        {letter.status === LetterStatus.Unread && <div className="w-2.5 h-2.5 bg-blue-500 rounded-full mx-auto"></div>}
                                    </td>
                                    <td className={`p-3 ${letter.status === LetterStatus.Unread ? 'font-bold' : ''}`}>{letter.senderName}</td>
                                    <td className={`p-3 ${letter.status === LetterStatus.Unread ? 'font-bold' : ''}`}>{letter.subject}</td>
                                    <td className="p-3">{letter.hasAttachment && <PaperClipIcon className="w-4 h-4 text-gray-500" />}</td>
                                    <td className="p-3 text-gray-500 whitespace-nowrap">{timeAgo(letter.sentDate)}</td>
                                    <td className="p-3"><PriorityBadge priority={letter.priority} /></td>
                                </tr>
                            ))
                        ) : (
                            <tr><td colSpan={6} className="text-center p-10 text-gray-500">هیچ نامه‌ای در کارتابل شما وجود ندارد.</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
    
    const renderDetailView = () => {
        if (loading) return <div className="text-center p-10">در حال بارگذاری نامه...</div>;
        if (!selectedLetter) return <div className="text-center p-10 text-red-500">نامه مورد نظر یافت نشد.</div>;

        return (
             <div className="bg-white rounded-lg shadow-sm border border-gray-200 h-full flex flex-col">
                <div className="p-4 border-b flex justify-between items-center">
                    <button onClick={handleBackToList} className="flex items-center text-indigo-600 text-sm font-semibold hover:underline">
                        <ArrowLeftIcon className="w-4 h-4 ml-2" />
                        بازگشت به کارتابل
                    </button>
                    <div className="flex items-center space-x-2">
                         <button className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200" title="پاسخ"><ArrowUturnLeftIcon className="w-5 h-5 text-gray-600" /></button>
                         <button className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200" title="ارجاع"><ArrowUturnRightIcon className="w-5 h-5 text-gray-600" /></button>
                         <button className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200" title="بایگانی"><ArchiveBoxIcon className="w-5 h-5 text-gray-600" /></button>
                    </div>
                </div>
                 <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
                     <LetterView letter={selectedLetter} isFinalized={true} onViewAttachment={setViewingAttachment}/>
                 </div>
            </div>
        );
    };

    return (
        <>
            {viewingAttachment && (
                <div className="fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50" onClick={() => setViewingAttachment(null)}>
                    <div className="bg-white p-4 rounded-lg shadow-xl w-full max-w-4xl h-5/6 flex flex-col" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center border-b pb-2 mb-4">
                            <h3 className="font-bold">{viewingAttachment.fileName}</h3>
                             <button onClick={() => setViewingAttachment(null)} className="text-2xl font-bold">&times;</button>
                        </div>
                        <div className="flex-1 overflow-auto">
                           {viewingAttachment.mimeType.startsWith('image/') ? (
                                <img src={`data:${viewingAttachment.mimeType};base64,${viewingAttachment.fileContent}`} alt={viewingAttachment.fileName} className="max-w-full h-auto mx-auto" />
                           ) : viewingAttachment.mimeType === 'application/pdf' ? (
                               <iframe src={`data:application/pdf;base64,${viewingAttachment.fileContent}`} className="w-full h-full" title={viewingAttachment.fileName}></iframe>
                           ) : (
                                <div className="text-center p-10">
                                    <p>پیش‌نمایش برای این نوع فایل پشتیبانی نمی‌شود.</p>
                                    <a href={`data:${viewingAttachment.mimeType};base64,${viewingAttachment.fileContent}`} download={viewingAttachment.fileName} className="text-indigo-600 hover:underline mt-4 inline-block">دانلود فایل</a>
                                </div>
                           )}
                        </div>
                    </div>
                </div>
            )}
            <div className="flex h-full gap-6">
                <div className="w-64 flex-shrink-0 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                     <h2 className="text-lg font-bold mb-4">پوشه‌ها</h2>
                     <ul className="space-y-1">
                        <li className="bg-indigo-100 text-indigo-700 font-semibold p-2 rounded-md cursor-pointer">کارتابل اصلی</li>
                        <li className="text-gray-600 hover:bg-gray-100 p-2 rounded-md cursor-pointer">نامه‌های ارسالی</li>
                        <li className="text-gray-600 hover:bg-gray-100 p-2 rounded-md cursor-pointer">پیش‌نویس‌ها</li>
                        <li className="text-gray-600 hover:bg-gray-100 p-2 rounded-md cursor-pointer">بایگانی</li>
                        <li className="text-gray-600 hover:bg-gray-100 p-2 rounded-md cursor-pointer">حذف شده</li>
                     </ul>
                </div>
                <div className="flex-1 min-w-0">
                    {view === 'LIST' && renderListView()}
                    {view === 'DETAILS' && renderDetailView()}
                    {view === 'COMPOSE' && <ComposeView onCancel={handleBackToList} onSuccess={handleBackToList} initialPayload={initialPayload} onPayloadConsumed={onPayloadConsumed} />}
                </div>
            </div>
        </>
    );
};

export default Automation;
