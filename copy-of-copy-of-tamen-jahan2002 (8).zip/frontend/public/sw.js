const CACHE_NAME = 'supply-chain-cache-v49';
// Only cache the essential app shell. Vite handles the rest.
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/assets/icon.svg',
  '/libs/ckeditor.js',
  '/libs/ckeditor-fa.js'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('Opened cache for pre-caching app shell');
      return cache.addAll(urlsToCache);
    }).catch(err => {
        console.error('Failed to pre-cache app shell:', err);
    })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', event => {
  const requestUrl = new URL(event.request.url);

  // Don't cache API requests. Let them go to the network.
  if (requestUrl.pathname.startsWith('/api/')) {
    return;
  }
  
  // For non-GET requests, network only.
  if (event.request.method !== 'GET') {
      return;
  }

  event.respondWith(
    caches.match(event.request).then(cachedResponse => {
      if (cachedResponse) {
        return cachedResponse;
      }

      return fetch(event.request).then(networkResponse => {
        if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
          return networkResponse;
        }

        const responseToCache = networkResponse.clone();
        caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseToCache);
        });

        return networkResponse;
      });
    })
  );
});
