import React, { useState, useEffect, useMemo } from 'react';
import { getOrgUnits } from '../frontend/src/services/organizationService';
import { getBeneficiaries } from '../frontend/src/services/identityService';
import { getFinancialResources } from '../frontend/src/services/financialResourceService';
import { searchInvoiceItems } from '../frontend/src/services/reportService';
import { RequestStatus } from '../shared/types';
import type { OrganizationalUnit, Beneficiary, FinancialResource, InvoiceItemExplorerResult, SystemUser, RequestDetails, ComposeLetterPayload } from '../shared/types';
import { ChevronDownIcon } from '../frontend/src/components/Icons';
import RequestDetailsModal from '../frontend/src/components/RequestDetailsModal';

interface SearchFilters {
    description: string;
    requestingUnitId: string;
    beneficiaryId: string;
    dateFrom: string;
    dateTo: string;
    priceFrom: string;
    priceTo: string;
    costType: string;
    financialResourceId: string;
    requestStatus: string;
}

interface GroupedResult {
    items: InvoiceItemExplorerResult[];
    totalQuantity: number;
}

const statusStyles: Record<RequestStatus, string> = {
  [RequestStatus.InProgress]: 'bg-blue-100 text-blue-700',
  [RequestStatus.Pending]: 'bg-yellow-100 text-yellow-700',
  [RequestStatus.Rejected]: 'bg-red-100 text-red-700',
  [RequestStatus.Completed]: 'bg-green-100 text-green-700',
};

const StatusBadge: React.FC<{ status: RequestStatus }> = ({ status }) => (
  <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${statusStyles[status]}`}>
    {status}
  </span>
);

interface InvoiceExplorerProps {
    currentUser: SystemUser;
    onEditRequest: (request: RequestDetails) => void;
    onSendToAutomation: (payload: ComposeLetterPayload) => void;
}

// --- Helper Components for Form Fields ---
interface FieldProps { label: string; name: string; value: string | number; onChange: (e: any) => void; placeholder?: string; type?: string; }
const InputField: React.FC<FieldProps> = ({ label, name, value, onChange, placeholder, type = 'text' }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input type={type} name={name} value={value} onChange={onChange} placeholder={placeholder} className="w-full p-2 border border-gray-300 rounded-md text-sm focus:ring-indigo-500 focus:border-indigo-500" />
    </div>
);

interface SelectProps extends FieldProps { options: { value: string | number; label: string }[]; }
const SelectField: React.FC<SelectProps> = ({ label, name, value, onChange, options }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <select name={name} value={value} onChange={onChange} className="w-full p-2 border border-gray-300 rounded-md text-sm bg-white focus:ring-indigo-500 focus:border-indigo-500">
            <option value="all">همه</option>
            {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
        </select>
    </div>
);

const InvoiceExplorer: React.FC<InvoiceExplorerProps> = ({ currentUser, onEditRequest, onSendToAutomation }) => {
    const [filters, setFilters] = useState<SearchFilters>({
        description: '', requestingUnitId: 'all', beneficiaryId: 'all',
        dateFrom: '', dateTo: '', priceFrom: '', priceTo: '',
        costType: 'all', financialResourceId: 'all', requestStatus: 'all'
    });
    const [results, setResults] = useState<InvoiceItemExplorerResult[]>([]);
    const [loading, setLoading] = useState(false);
    const [groupByDescription, setGroupByDescription] = useState(false);
    const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);
    
    const [orgUnits, setOrgUnits] = useState<OrganizationalUnit[]>([]);
    const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
    const [financialResources, setFinancialResources] = useState<FinancialResource[]>([]);
    const costTypes = ['جاری', 'سرمایه‌ای'];

    useEffect(() => {
        const fetchDropdownData = async () => {
            try {
                const [units, benefs, finRes] = await Promise.all([
                    getOrgUnits(),
                    getBeneficiaries(),
                    getFinancialResources()
                ]);
                setOrgUnits(units);
                setBeneficiaries(benefs);
                setFinancialResources(finRes);
            } catch (error) {
                console.error("Failed to load filter data", error);
            }
        };
        fetchDropdownData();
    }, []);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSearch = async () => {
        setLoading(true);
        try {
            const data = await searchInvoiceItems(filters);
            setResults(data);
        } catch (error) {
            console.error("Failed to search invoice items", error);
        } finally {
            setLoading(false);
        }
    };
    
    const handleClear = () => {
        setFilters({
            description: '', requestingUnitId: 'all', beneficiaryId: 'all',
            dateFrom: '', dateTo: '', priceFrom: '', priceTo: '',
            costType: 'all', financialResourceId: 'all', requestStatus: 'all'
        });
        setResults([]);
    };

    const processedResults = useMemo(() => {
        if (!groupByDescription) return results;

        const grouped: Record<string, GroupedResult> = results.reduce((acc, item) => {
            const key = item.description;
            const group = acc[key] ?? { items: [], totalQuantity: 0 };
            
            group.items.push(item);
            group.totalQuantity += item.quantity;
            
            acc[key] = group;
            
            return acc;
        }, {} as Record<string, GroupedResult>);

        return Object.entries(grouped).map(([description, group]: [string, GroupedResult]) => {
            const firstItem = group.items[0]!;
            const totalGroupPrice = group.items.reduce((sum, item) => sum + item.totalPrice, 0);

            return {
                ...firstItem,
                id: description as any, 
                quantity: group.totalQuantity,
                unitPrice: group.totalQuantity > 0 ? totalGroupPrice / group.totalQuantity : 0,
                totalPrice: totalGroupPrice,
                projectName: group.items.length > 1 ? '---' : firstItem.projectName,
                beneficiaryName: group.items.length > 1 ? '---' : firstItem.beneficiaryName,
                requestingUnitName: group.items.length > 1 ? '---' : firstItem.requestingUnitName,
                requestDate: group.items.length > 1 ? '---' : firstItem.requestDate,
                requestNumber: group.items.length > 1 ? '---' : firstItem.requestNumber,
            };
        });

    }, [results, groupByDescription]);

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-xl font-bold text-gray-800 mb-4">کاوشگر اقلام فاکتور</h2>
                <details className="border rounded-lg" open>
                    <summary className="flex items-center justify-between p-4 cursor-pointer bg-gray-50 hover:bg-gray-100">
                        <h3 className="font-semibold text-gray-700">جستجوی پیشرفته اقلام</h3>
                        <ChevronDownIcon className="w-5 h-5 transition-transform" />
                    </summary>
                    <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <InputField label="شرح کالا/خدمت" name="description" value={filters.description} onChange={handleFilterChange} placeholder="مثال: هارد دیسک" />
                        <SelectField label="واحد درخواست‌کننده" name="requestingUnitId" value={filters.requestingUnitId} onChange={handleFilterChange} options={orgUnits.map(u => ({ value: u.id, label: u.title }))} />
                        <SelectField label="ذی‌نفع (فروشنده)" name="beneficiaryId" value={filters.beneficiaryId} onChange={handleFilterChange} options={beneficiaries.map(b => ({ value: b.id.toString(), label: b.fullName }))} />
                        <SelectField label="وضعیت فرآیند" name="requestStatus" value={filters.requestStatus} onChange={handleFilterChange} options={Object.values(RequestStatus).map(s => ({ value: s as string, label: s as string }))} />
                        <InputField label="تاریخ ثبت (از)" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} placeholder="مثال: ۱۴۰۴/۰۱/۰۱" />
                        <InputField label="تاریخ ثبت (تا)" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} placeholder="مثال: ۱۴۰۴/۱۲/۲۹" />
                        <InputField label="قیمت واحد (از)" name="priceFrom" value={filters.priceFrom} onChange={handleFilterChange} type="number" />
                        <InputField label="قیمت واحد (تا)" name="priceTo" value={filters.priceTo} onChange={handleFilterChange} type="number" />
                        <SelectField label="نوع هزینه" name="costType" value={filters.costType} onChange={handleFilterChange} options={costTypes.map(c => ({ value: c, label: c }))} />
                        <SelectField label="منبع اعتبار" name="financialResourceId" value={filters.financialResourceId} onChange={handleFilterChange} options={financialResources.map(r => ({ value: r.id.toString(), label: r.name }))} />
                        <div className="lg:col-span-4 flex items-end justify-start space-x-2 space-x-reverse pt-4">
                            <button onClick={handleSearch} className="bg-indigo-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-indigo-700">جستجو</button>
                            <button onClick={handleClear} className="bg-gray-200 text-gray-700 px-6 py-2 rounded-md font-semibold hover:bg-gray-300">پاک کردن</button>
                        </div>
                    </div>
                </details>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
                 <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-gray-700">نتایج جستجو</h3>
                    <div className="flex items-center">
                        <input type="checkbox" id="groupByDesc" checked={groupByDescription} onChange={e => setGroupByDescription(e.target.checked)} className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500" />
                        <label htmlFor="groupByDesc" className="mr-2 text-sm font-medium text-gray-700">گروه‌بندی بر اساس شرح</label>
                    </div>
                </div>
                <div className="overflow-x-auto border rounded-lg">
                    <table className="w-full text-sm text-right">
                        <thead className="bg-gray-50 text-xs text-gray-500 uppercase">
                            <tr>
                                <th className="p-3">شرح کالا/خدمت</th>
                                <th className="p-3">تعداد</th>
                                <th className="p-3">{groupByDescription ? 'میانگین قیمت واحد (ریال)' : 'قیمت واحد (ریال)'}</th>
                                <th className="p-3">قیمت کل (ریال)</th>
                                <th className="p-3">نام پروژه</th>
                                <th className="p-3">ذی‌نفع</th>
                                <th className="p-3">واحد درخواست‌کننده</th>
                                <th className="p-3">تاریخ درخواست</th>
                                <th className="p-3">وضعیت</th>
                                <th className="p-3">شماره درخواست</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {loading ? (
                                <tr><td colSpan={10} className="p-4 text-center">در حال بارگذاری...</td></tr>
                            ) : processedResults.length > 0 ? (
                                processedResults.map((item, index) => (
                                    <tr key={`${item.id}-${index}`} className="hover:bg-gray-50">
                                        <td className="p-3 font-medium">{item.description}</td>
                                        <td className="p-3">{item.quantity}</td>
                                        <td className="p-3">{Math.round(item.unitPrice).toLocaleString()}</td>
                                        <td className="p-3 font-semibold">{item.totalPrice.toLocaleString()}</td>
                                        <td className="p-3">{item.projectName}</td>
                                        <td className="p-3">{item.beneficiaryName}</td>
                                        <td className="p-3">{item.requestingUnitName}</td>
                                        <td className="p-3">{item.requestDate}</td>
                                        <td className="p-3"><StatusBadge status={item.requestStatus} /></td>
                                        <td className="p-3">
                                            <button 
                                                onClick={() => setSelectedRequestId(item.requestNumber)} 
                                                className="font-mono text-xs text-indigo-600 hover:underline disabled:text-gray-400 disabled:no-underline"
                                                disabled={item.requestNumber === '---'}
                                                title={item.requestNumber === '---' ? "برای مشاهده جزئیات، حالت گروه‌بندی را غیرفعال کنید" : "مشاهده جزئیات درخواست"}
                                            >
                                                {item.requestNumber}
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr><td colSpan={10} className="p-4 text-center text-gray-500">موردی یافت نشد یا جستجویی انجام نشده است.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
            
            {selectedRequestId && (
                <RequestDetailsModal 
                    requestId={selectedRequestId} 
                    onClose={() => setSelectedRequestId(null)} 
                    currentUser={currentUser}
                    onEditRequest={onEditRequest}
                    onSendToAutomation={onSendToAutomation}
                />
            )}
        </div>
    );
};

export default InvoiceExplorer;