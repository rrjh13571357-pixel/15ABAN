import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './pages/Dashboard';
import OrganizationalStructure from './pages/OrganizationalStructure';
import PersonsManagement from './pages/PersonsManagement';
import RolesManagement from './pages/RolesManagement';
import Workflows from './pages/Workflows';
import NewRequestForm from './pages/NewRequestForm';
import Projects from './pages/Projects';
import Contracts from './pages/Contracts';
import Payroll from './pages/Payroll';
import Reports from './pages/Reports';
import Automation from './pages/Automation';
import LetterTemplates from './pages/LetterTemplates';
import WorkMeasurement from './pages/WorkMeasurement';
import BankAccounts from './pages/BankAccounts';
import AccessLevels from './pages/AccessLevels';
import FinancialResources from './pages/FinancialResources';
import AiAnalyst from './pages/AiAnalyst';
import UserDefinition from './pages/UserDefinition';
import Users from './pages/Users';
import LoginPage from './pages/LoginPage';
import { login } from './services/authService';
import type { Page, RequestDetails, SystemUser, ComposeLetterPayload } from './types';
import PettyCashManagement from './pages/PettyCashManagement';
import RequestTypes from './pages/RequestTypes';
import AdvancedSearchReports from './pages/AdvancedSearchReports';


const pageTitles: Record<Page, string> = {
  DASHBOARD: 'داشبورد کارتابل درخواست‌ها',
  ORG_STRUCTURE: 'ساختار سازمانی',
  PERSONS: 'مدیریت اشخاص',
  ROLES: 'مدیریت نقش‌ها',
  WORKFLOWS: 'مدیریت گردش‌های کاری',
  NEW_REQUEST: 'ثبت درخواست جدید',
  PROJECTS: 'کنترل پروژه',
  CONTRACTS: 'مدیریت قراردادها',
  PAYROLL: 'مدیریت پرداختی کارکنان',
  REPORTS: 'داشبورد گزارش‌ها',
  INVOICE_EXPLORER: 'کاوشگر اقلام فاکتور', // This is being removed but kept here for now
  AUTOMATION: 'اتوماسیون داخلی - کارتابل',
  AUTOMATION_TEMPLATES: 'اتوماسیون داخلی - مدیریت قالب نامه‌ها',
  WORK_MEASUREMENT: 'کارسنجی',
  BANK_ACCOUNTS: 'مدیریت شماره حساب‌ها',
  ACCESS_LEVELS: 'سطوح دسترسی',
  FINANCIAL_RESOURCES: 'مدیریت منابع مالی',
  AI_ANALYST: 'تحلیلگر هوشمند',
  WORKFLOWS_PURCHASE: 'گردش کار: فرایندهای تامین و خرید',
  WORKFLOWS_PETTY_CASH: 'گردش کار: فرایندهای تنخواه',
  WORKFLOWS_CONTRACT: 'گردش کار: فرایندهای قرارداد',
  WORKFLOWS_PAYROLL: 'گردش کار: فرایندهای حقوق و مزایا',
  USER_DEFINITION: 'تعریف کاربر جدید',
  USERS: 'مدیریت کاربران',
  PETTY_CASH_MANAGEMENT: 'مدیریت تنخواه بگیران',
  REQUEST_TYPES: 'مدیریت انواع درخواست',
  ADVANCED_SEARCH_REPORTS: 'گزارش‌ها و جستجوی پیشرفته',
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('DASHBOARD');
  const [editingRequest, setEditingRequest] = useState<RequestDetails | null>(null);
  const [currentUser, setCurrentUser] = useState<SystemUser | null>(null);
  const [composeLetterPayload, setComposeLetterPayload] = useState<ComposeLetterPayload | null>(null);


  const handleEditRequest = (request: RequestDetails) => {
    setEditingRequest(request);
    setCurrentPage('NEW_REQUEST');
  };

  const handleFormClose = () => {
    setEditingRequest(null);
    setCurrentPage('DASHBOARD');
  };

  const handleLogin = async (username: string, password: string): Promise<string | null> => {
    try {
      const user = await login(username, password);
      setCurrentUser(user);
      return null;
    } catch (error: any) {
      return error.message || 'خطای ناشناخته در ورود.';
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentPage('DASHBOARD'); // Reset to default page on logout
  };

  const handleSendToAutomation = (payload: ComposeLetterPayload) => {
    setComposeLetterPayload(payload);
    setCurrentPage('AUTOMATION');
  };


  const renderPage = () => {
    switch (currentPage) {
      case 'DASHBOARD':
        return <Dashboard setCurrentPage={setCurrentPage} onEditRequest={handleEditRequest} currentUser={currentUser!} onSendToAutomation={handleSendToAutomation} />;
      case 'ORG_STRUCTURE':
        return <OrganizationalStructure />;
      case 'PERSONS':
        return <PersonsManagement />;
      case 'ROLES':
        return <RolesManagement />;
      case 'WORKFLOWS':
        return <Workflows />;
      case 'NEW_REQUEST':
        return <NewRequestForm setCurrentPage={handleFormClose} requestToEdit={editingRequest} currentUser={currentUser!} />;
      case 'PROJECTS':
        return <Projects />;
      case 'CONTRACTS':
        return <Contracts />;
      case 'PAYROLL':
        return <Payroll />;
      case 'REPORTS':
        return <Reports />;
      case 'AUTOMATION':
        return <Automation setCurrentPage={setCurrentPage} initialPayload={composeLetterPayload} onPayloadConsumed={() => setComposeLetterPayload(null)} />;
      case 'AUTOMATION_TEMPLATES':
        return <LetterTemplates />;
      case 'WORK_MEASUREMENT':
        return <WorkMeasurement />;
      case 'BANK_ACCOUNTS':
        return <BankAccounts />;
      case 'ACCESS_LEVELS':
        return <AccessLevels />;
       case 'FINANCIAL_RESOURCES':
        return <FinancialResources />;
      case 'AI_ANALYST':
        return <AiAnalyst />;
      case 'WORKFLOWS_PURCHASE':
        return <Workflows category="purchase" />;
      case 'WORKFLOWS_PETTY_CASH':
        return <Workflows category="petty_cash" />;
      case 'WORKFLOWS_CONTRACT':
        return <Workflows category="contract" />;
      case 'WORKFLOWS_PAYROLL':
        return <Workflows category="payroll" />;
      case 'USER_DEFINITION':
        return <UserDefinition setCurrentPage={setCurrentPage} />;
      case 'USERS':
        return <Users />;
      case 'PETTY_CASH_MANAGEMENT':
        return <PettyCashManagement currentUser={currentUser!} />;
      case 'REQUEST_TYPES':
        return <RequestTypes />;
      case 'ADVANCED_SEARCH_REPORTS':
        return <AdvancedSearchReports />;
      default:
        return <Dashboard setCurrentPage={setCurrentPage} onEditRequest={handleEditRequest} currentUser={currentUser!} onSendToAutomation={handleSendToAutomation}/>;
    }
  };

  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="bg-slate-100 min-h-screen flex text-slate-800">
      <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} onLogout={handleLogout} />
      <main className="flex-1 flex flex-col min-w-0">
        <Header title={pageTitles[currentPage]} setCurrentPage={setCurrentPage} currentUser={currentUser} onLogout={handleLogout} />
        <div className="flex-1 p-4 sm:p-6 lg:p-8 overflow-auto">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}
