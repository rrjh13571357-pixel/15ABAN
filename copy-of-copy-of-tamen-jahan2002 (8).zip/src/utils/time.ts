export function timeAgo(isoString: string): string {
  // Simple check for non-ISO date format (like Solar)
  if (isoString.includes('/')) {
    return isoString;
  }
  
  const date = new Date(isoString);
  // Check if date is valid
  if (isNaN(date.getTime())) {
      return isoString; // Return original string if date is invalid
  }

  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (seconds < 60) {
    return "همین الان";
  }

  let interval = seconds / 31536000; // years
  if (interval > 1) {
    return `حدود ${Math.floor(interval)} سال پیش`;
  }
  interval = seconds / 2592000; // months
  if (interval > 1) {
    return `حدود ${Math.floor(interval)} ماه پیش`;
  }
  interval = seconds / 86400; // days
  if (interval > 1) {
    return `حدود ${Math.floor(interval)} روز پیش`;
  }
  interval = seconds / 3600; // hours
  if (interval > 1) {
    return `حدود ${Math.floor(interval)} ساعت پیش`;
  }
  interval = seconds / 60; // minutes
  if (interval > 1) {
    return `حدود ${Math.floor(interval)} دقیقه پیش`;
  }
  return "همین الان";
}
