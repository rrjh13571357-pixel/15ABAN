export type Page = 
  | 'DASHBOARD' 
  | 'ORG_STRUCTURE' 
  | 'PERSONS' 
  | 'ROLES' 
  | 'WORKFLOWS'
  | 'NEW_REQUEST'
  | 'PROJECTS'
  | 'CONTRACTS'
  | 'PAYROLL'
  | 'REPORTS'
  | 'INVOICE_EXPLORER'
  | 'AUTOMATION'
  | 'AUTOMATION_TEMPLATES'
  | 'WORK_MEASUREMENT'
  | 'BANK_ACCOUNTS'
  | 'ACCESS_LEVELS'
  | 'FINANCIAL_RESOURCES'
  | 'AI_ANALYST'
  | 'WORKFLOWS_PURCHASE'
  | 'WORKFLOWS_PETTY_CASH'
  | 'WORKFLOWS_CONTRACT'
  | 'WORKFLOWS_PAYROLL'
  | 'USER_DEFINITION'
  | 'USERS'
  | 'PETTY_CASH_MANAGEMENT'
  | 'REQUEST_TYPES'
  | 'ADVANCED_SEARCH_REPORTS';

export interface User {
  id: number;
  name: string;
  role: string;
  avatarUrl: string;
}

export interface OrganizationalUnit {
  id: string;
  title: string;
  code: string;
  managerId: number;
  parent: string | null;
}

// Renamed from Person, this represents a user who can log in.
export interface SystemUser {
  id: number;
  fullName: string;
  nationalCode: string;
  unitId: string; // link to OrganizationalUnit
  roleId: number; // link to Role
  username: string | null;
  password?: string;
  status: 'active' | 'inactive';
  forcePasswordChange: boolean;
  passwordNeverExpires: boolean;
  description?: string;
}

// A person/entity who receives payments.
export interface Beneficiary {
  id: number;
  fullName: string;
  nationalCode: string;
}

// A person responsible for petty cash.
export interface PettyCashHolder {
  id: number;
  fullName: string;
  nationalCode: string;
  associatedCenterId: string | null; // link to OrganizationalUnit
  pettyCashLimit: number;
}

export interface BankAccount {
    id: number;
    bankName: string;
    accountNumber: string;
    iban: string;
    ownerId: number | null; // Can be SystemUser, Beneficiary, or PettyCashHolder ID
    ownerType: 'user' | 'beneficiary' | 'pettyCash' | null;
}


export interface Role {
    id: number;
    title: string;
    description: string;
    userCount: number;
    status: 'فعال' | 'غیرفعال';
}

export interface AccessLevel {
    id: number;
    title: string;
    description: string;
    roleIds: number[];
    permissions: string[];
}

export interface Workflow {
    id: number;
    name: string;
    steps: { name: string; responsible: string }[];
    requirements?: string[];
    icon: string;
}

export interface RequestType {
    id: number;
    title: string;
    deadline: number | null;
    attachedFileRequired: boolean;
    workflowId: number;
}

export interface CurrencyAmount {
  rial: number;
  usd: number;
  eur: number;
}

export interface Project {
  id: number;
  name: string;
  budget: CurrencyAmount;
  spentAmount: CurrencyAmount;
  orgUnitId: string; // link to OrganizationalUnit
  startDate: string; // ISO 8601 format: "YYYY-MM-DD"
  financialResourceId: number; // link to FinancialResource
}

export interface FinancialResource {
  id: number;
  name: string;
}

export interface FundInjection {
  id: number;
  projectId: number;
  amount: CurrencyAmount;
  allocationNumber: string;
  allocationDate: string;
  financialResourceId: number;
}


export enum RequestStatus {
  InProgress = 'در حال بررسی',
  Pending = 'در انتظار تایید',
  Rejected = 'رد شده',
  Completed = 'تایید نهایی',
}

export interface Request {
  id: string;
  subject: string;
  applicant: string;
  amount: CurrencyAmount;
  date: string;
  deadline: string | null;
  status: RequestStatus;
  projectId?: number;
  contractId?: number;
  // New fields for workflow control
  originalApplicantId: number;
  currentStepOwnerId: number;
  isConsultation?: boolean; // Flag for dashboard display
  lastModified: string;
  requestTypeId: number;
  workflowId: number;
}

export enum TaskStatus {
    Completed = 'تکمیل شده',
    InProgress = 'در حال انجام',
    NotStarted = 'شروع نشده',
    Blocked = 'مسدود شده',
}

export interface Task {
    id: number;
    title: string;
    responsible: string;
    status: TaskStatus;
    progress: number;
    lastUpdate: string;
    deadline: string | null;
}

export enum ContractStatus {
    Active = 'فعال',
    Pending = 'در دست بررسی',
    Archived = 'آرشیو شده',
}

// For the list view
export interface Contract {
    id: number;
    contractNumber: string;
    title: string;
    party: string;
    amount: number | null;
    endDate: string;
    status: ContractStatus;
}

// For the details view
export interface ContractDetails extends Contract {
    manualContractNumber: string;
    employer: string; // کارفرما
    ourRole: 'payer' | 'payee'; // پرداخت کننده یا دریافت کننده
    contractType: string;
    category: string;
    projectType: string;
    relatedCenter: string;
    startDate: string;
    guarantees: Guarantee[];
    payments: Payment[];
    addendums: Addendum[];
    attachments: Attachment[];
}

export interface Payment {
    id: number;
    contractId: number;
    type: string;
    date: string;
    amount: CurrencyAmount;
    description: string;
    referenceNumber: string;
}

export interface Guarantee {
    id: number;
    contractId: number;
    type: string;
    issuer: string; // صادرکننده
    referenceNumber: string;
    amount: CurrencyAmount;
    issueDate: string;
    expiryDate: string;
    relatedCenter: string;
}

export interface Addendum {
    id: number;
    contractId: number;
    type: string;
    date: string;
    number: string;
    amountChange: CurrencyAmount;
    description: string;
}

export interface Attachment {
    id: number;
    contractId: number;
    fileName: string;
    fileType: string;
    uploadDate: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export type EntityType = 'project' | 'contract' | 'user';

export interface TemplatedQuery {
  id: string;
  displayText: string;
  template: string;
  entityType: EntityType;
  description: string;
  command?: string;
}

export interface Notification {
  id: number;
  type: 'request' | 'contract' | 'system' | 'consultation';
  title: string;
  description: string;
  timestamp: string; // ISO 8601 format
  isRead: boolean;
  link?: Page; 
  requestId?: string;
}


// Reports
export interface ProjectFinancialSummary {
  labels: string[]; // project names
  datasets: [
    {
      label: 'بودجه کل';
      data: number[];
      backgroundColor: string;
    },
    {
      label: 'مبلغ هزینه شده';
      data: number[];
      backgroundColor: string;
    }
  ]
}

export interface StatusDistribution {
  labels: string[]; // status names
  datasets: [{
    data: number[];
    backgroundColor: string[];
  }]
}

export interface MonthlyRequestVolume {
    labels: string[]; // month names
    datasets: [{
        label: 'تعداد درخواست‌ها';
        data: number[];
        borderColor: string;
        tension: number;
    }]
}


export interface Invoice {
  id: number;
  requestId: string;
  invoiceNumber: string;
  beneficiaryId: number;
}

export interface InvoiceItem {
  id: number;
  invoiceId: number;
  description: string;
  quantity: number;
  unitPrice: number;
  costType: string;
}

export interface InvoiceItemExplorerResult {
  id: number; // item id
  description: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  beneficiaryName: string;
  requestingUnitName: string;
  requestDate: string;
  requestNumber: string;
  projectName: string;
  requestStatus: RequestStatus;
}
export enum PayrollStatus {
    Draft = 'پیش‌نویس',
    Paid = 'پرداخت شده',
    Canceled = 'لغو شده',
}

export interface Payroll {
    id: number;
    period: string; // e.g., "تیر 1403"
    employeeCount: number;
    totalAmount: CurrencyAmount;
    status: PayrollStatus;
    paymentDate: string | null; // ISO Date "YYYY-MM-DD"
}

export interface PayrollItem {
    id: number;
    payrollId: number;
    employeeId: number; // links to SystemUser
    baseSalary: number;
    overtime: number;
    bonus: number;
    deductions: number;
    netPay: number;
}

export interface PayrollDetails extends Payroll {
    items: (PayrollItem & { employeeName: string; nationalCode: string })[];
}

// --- Request Details Modal Types ---

export interface InvoiceDetails extends Invoice {
  items: InvoiceItem[];
  beneficiaryName: string;
}

export interface WorkflowStepState {
  name: string;
  status: 'completed' | 'current' | 'pending';
  actor?: string;
}

export interface Rejection {
    stepName: string;
    rejectedBy: string;
    reason: string;
    date: string;
}

export interface Consultation {
    id: number;
    requestId: string;
    fromUserId: number;
    toUserId: number;
    question: string;
    answer: string | null;
    status: 'pending' | 'answered';
    questionDate: string;
    answerDate: string | null;
}

export interface RequestDetails extends Request {
  requestingUnit: string;
  creditSource: string;
  invoices: InvoiceDetails[];
  workflow: {
      steps: WorkflowStepState[];
      currentActionBy: string;
  };
  rejectionHistory: Rejection[];
  consultations: (Consultation & {fromUserName: string, toUserName: string})[];
}


// --- Automation Module Types ---
export enum LetterStatus {
    Read = 'خوانده شده',
    Unread = 'خوانده نشده',
}

export enum LetterPriority {
    Normal = 'عادی',
    Confidential = 'محرمانه',
    Urgent = 'فوری',
}

export interface LetterAttachment {
    id: number;
    fileName: string;
    fileContent: string; // base64
    mimeType: string;
}

export interface Letter {
    id: number;
    subject: string;
    content: string; // HTML content from rich text editor
    senderId: number; // The user who sent it
    recipientIds: number[]; // Users to receive it in their inbox
    sentDate: string; // ISO 8601 format
    priority: LetterPriority;
    status: Record<number, LetterStatus>; // key is recipientId
    
    // New structured fields
    letterDate: string; // Solar date string e.g., "1403/05/06"
    senderUnitId: string; // OrganizationalUnit ID
    recipientUnitId: string; // OrganizationalUnit ID
    signatoryId: number; // SystemUser ID
    attachments: LetterAttachment[];
}

// Flattened type for inbox list
export interface InboxLetter {
    id: number;
    subject: string;
    senderName: string;
    sentDate: string;
    priority: LetterPriority;
    status: LetterStatus;
    hasAttachment: boolean;
}

export interface LetterTemplate {
    id: number;
    name: string;
    fileName: string; // The original .docx filename
    templateBody: string; // base64 content of the .docx file
}

export interface ComposeLetterPayload {
  initialSubject: string;
}
