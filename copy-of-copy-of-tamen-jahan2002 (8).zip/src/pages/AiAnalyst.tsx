import React, { useState, useRef, useEffect } from 'react';
import { getAnalysis } from '../services/analysisService';
import { ChatMessage } from '../types';
import { PaperAirplaneIcon, SparklesIcon } from '../components/Icons';
import TemplatedQueryBuilder from '../components/TemplatedQueryBuilder';

const AiAnalyst: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { role: 'assistant', content: 'سلام! من تحلیلگر هوشمند شما هستم. می‌توانید از پرسش‌های الگو استفاده کنید یا سوال خود را مستقیما در کادر پایین بپرسید.' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSendMessage = async (query?: string) => {
        const userMessage = query || input;
        if (!userMessage.trim()) return;

        setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
        setInput('');
        setIsLoading(true);

        try {
            const response = await getAnalysis(userMessage);
            setMessages(prev => [...prev, { role: 'assistant', content: response }]);
        } catch (error) {
            console.error("Error fetching analysis:", error);
            setMessages(prev => [...prev, { role: 'assistant', content: 'متاسفانه در پردازش درخواست شما خطایی رخ داد.' }]);
        } finally {
            setIsLoading(false);
        }
    };
    
    const suggestedQuestions = [
        "پروژه‌هایی که بیشترین بودجه را دارند کدامند؟",
        "گزارش مالی پروژه‌ها را به من نشان بده.",
        "بودجه پروژه آلفا چقدر است؟",
        "آخرین قرارداد با هیدروفن کوانتومی چیست؟",
        "لیست قراردادهای فعال را نشان بده.",
    ];

    return (
        <div className="flex flex-col h-full max-w-4xl mx-auto bg-white rounded-lg shadow-lg">
            <header className="p-4 border-b flex items-center">
                <SparklesIcon className="w-6 h-6 text-purple-600" />
                <h1 className="text-xl font-semibold ml-2">تحلیلگر هوشمند</h1>
            </header>
            
            <div className="flex-1 p-6 overflow-y-auto">
                <div className="space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-start ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xl p-3 rounded-lg ${msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-800'}`}>
                                <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                         <div className="flex items-start justify-start">
                            <div className="max-w-lg p-3 rounded-lg bg-slate-200 text-slate-800">
                                <div className="flex items-center space-x-1 space-x-reverse">
                                    <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse"></div>
                                    <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                                    <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
            </div>
            
            {messages.length <= 1 && (
                 <div className="p-6 pt-0">
                    <h3 className="text-sm font-semibold text-gray-600 mb-2">چند نمونه سوال:</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {suggestedQuestions.map((q, i) => (
                            <button key={i} onClick={() => handleSendMessage(q)} className="text-right text-sm text-blue-600 bg-blue-50 p-2 rounded-md hover:bg-blue-100 transition-colors">
                                {q}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            <div className="p-4 border-t space-y-4">
                <TemplatedQueryBuilder onQuerySubmit={handleSendMessage} isLoading={isLoading} />
                <div className="relative">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSendMessage()}
                        placeholder="یا سوال خود را اینجا تایپ کنید..."
                        className="w-full p-3 pr-12 border border-gray-300 rounded-full focus:ring-purple-500 focus:border-purple-500"
                        disabled={isLoading}
                    />
                    <button onClick={() => handleSendMessage()} disabled={isLoading || !input.trim()} className="absolute inset-y-0 right-0 flex items-center pr-4">
                        <PaperAirplaneIcon className={`w-6 h-6 transform -rotate-45 ${isLoading || !input.trim() ? 'text-gray-400' : 'text-purple-600'}`} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AiAnalyst;