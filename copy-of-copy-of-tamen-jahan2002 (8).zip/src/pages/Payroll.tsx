import React, { useState, useEffect, useMemo } from 'react';
import { Payroll, PayrollDetails, PayrollStatus } from '../types';
import { getPayrolls, getPayrollDetails } from '../services/payrollService';
import { ArrowLeftIcon, PlusIcon } from '../components/Icons';

const statusStyles: Record<PayrollStatus, string> = {
  [PayrollStatus.Draft]: 'bg-yellow-100 text-yellow-800',
  [PayrollStatus.Paid]: 'bg-green-100 text-green-800',
  [PayrollStatus.Canceled]: 'bg-red-100 text-red-800',
};

const StatusBadge: React.FC<{ status: PayrollStatus }> = ({ status }) => (
  <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${statusStyles[status]}`}>
    {status}
  </span>
);

const PayrollDetailView: React.FC<{payroll: PayrollDetails, onBack: () => void}> = ({ payroll, onBack }) => {
    return (
        <div className="bg-white p-6 rounded-lg shadow">
            <button onClick={onBack} className="flex items-center text-blue-600 mb-4 text-sm"><ArrowLeftIcon className="w-4 h-4 ml-2" /> بازگشت به لیست</button>
            <div className="flex justify-between items-start mb-4 pb-4 border-b">
                <div>
                    <h2 className="text-xl font-bold">جزئیات لیست حقوق - {payroll.period}</h2>
                    <div className="flex items-center space-x-2 text-sm text-gray-500 mt-1">
                        <StatusBadge status={payroll.status} />
                        <span>مبلغ کل: {payroll.totalAmount.rial.toLocaleString()} ریال</span>
                    </div>
                </div>
                 {payroll.status === PayrollStatus.Draft && (
                    <div className="flex space-x-2">
                        <button className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600">لغو لیست</button>
                        <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">پرداخت و نهایی کردن</button>
                    </div>
                 )}
            </div>
            <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm text-right">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="p-3 font-semibold">نام کارمند</th>
                            <th className="p-3 font-semibold">کد ملی</th>
                            <th className="p-3 font-semibold">حقوق پایه</th>
                            <th className="p-3 font-semibold">اضافه کار</th>
                            <th className="p-3 font-semibold">پاداش</th>
                            <th className="p-3 font-semibold">کسورات</th>
                            <th className="p-3 font-semibold">پرداختی خالص</th>
                        </tr>
                    </thead>
                    <tbody>
                        {payroll.items.map(item => (
                            <tr key={item.id} className="border-b hover:bg-gray-50">
                                <td className="p-3 font-medium">{item.employeeName}</td>
                                <td className="p-3">{item.nationalCode}</td>
                                <td className="p-3">{item.baseSalary.toLocaleString()}</td>
                                <td className="p-3 text-green-600">{item.overtime > 0 ? `+${item.overtime.toLocaleString()}`: '0'}</td>
                                <td className="p-3 text-green-600">{item.bonus > 0 ? `+${item.bonus.toLocaleString()}`: '0'}</td>
                                <td className="p-3 text-red-600">{item.deductions > 0 ? `-${item.deductions.toLocaleString()}`: '0'}</td>
                                <td className="p-3 font-bold">{item.netPay.toLocaleString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

const PayrollPage: React.FC = () => {
    const [view, setView] = useState<'LIST' | 'DETAILS'>('LIST');
    const [payrolls, setPayrolls] = useState<Payroll[]>([]);
    const [selectedPayroll, setSelectedPayroll] = useState<PayrollDetails | null>(null);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        if (view === 'LIST') {
            const fetchData = async () => {
                setLoading(true);
                try {
                    const data = await getPayrolls();
                    setPayrolls(data);
                } catch (error) {
                    console.error("Failed to fetch payrolls:", error);
                } finally {
                    setLoading(false);
                }
            };
            fetchData();
        }
    }, [view]);

    const handleViewDetails = async (payrollId: number) => {
        setLoading(true);
        try {
            const details = await getPayrollDetails(payrollId);
            setSelectedPayroll(details);
            setView('DETAILS');
        } catch (error) {
            console.error("Failed to fetch payroll details:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleBackToList = () => {
        setView('LIST');
        setSelectedPayroll(null);
    };
    
    const filteredPayrolls = useMemo(() => {
        return payrolls.filter(p => p.period.toLowerCase().includes(searchTerm.toLowerCase()));
    }, [payrolls, searchTerm]);

    if (loading) return <div className="text-center p-10">در حال بارگذاری...</div>;

    if (view === 'DETAILS' && selectedPayroll) {
        return <PayrollDetailView payroll={selectedPayroll} onBack={handleBackToList} />;
    }

    return (
        <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">لیست‌های حقوق و دستمزد</h2>
                <div className="flex items-center space-x-2">
                     <input type="text" placeholder="جستجو بر اساس دوره..." className="p-2 border border-gray-300 rounded-md text-sm w-60" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                    <button className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 flex items-center">
                        <PlusIcon className="w-5 h-5 ml-2" />
                        ایجاد لیست جدید
                    </button>
                </div>
            </div>
             <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm text-right">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="p-3 font-semibold">دوره</th>
                            <th className="p-3 font-semibold">تعداد کارکنان</th>
                            <th className="p-3 font-semibold">مبلغ کل (ریال)</th>
                            <th className="p-3 font-semibold">تاریخ پرداخت</th>
                            <th className="p-3 font-semibold">وضعیت</th>
                            <th className="p-3 font-semibold">عملیات</th>
                        </tr>
                    </thead>
                     <tbody>
                        {filteredPayrolls.map(p => (
                            <tr key={p.id} className="border-b hover:bg-gray-50 cursor-pointer" onClick={() => handleViewDetails(p.id)}>
                                <td className="p-3 font-medium">{p.period}</td>
                                <td className="p-3">{p.employeeCount} نفر</td>
                                <td className="p-3">{p.totalAmount.rial.toLocaleString()}</td>
                                <td className="p-3">{p.paymentDate || '---'}</td>
                                <td className="p-3"><StatusBadge status={p.status} /></td>
                                <td className="p-3"><button className="text-blue-600 hover:underline text-xs">مشاهده جزئیات</button></td>
                            </tr>
                        ))}
                     </tbody>
                </table>
            </div>
        </div>
    );
};

export default PayrollPage;