import type { RequestType, Workflow } from '../types';
import { api } from './api';

export const getRequestTypes = (): Promise<RequestType[]> => {
    return api.get<RequestType[]>('/request-types');
};

export const addRequestType = async (requestType: Omit<RequestType, 'id'>): Promise<RequestType[]> => {
    await api.post<RequestType>('/request-types', requestType);
    return getRequestTypes();
};

export const updateRequestType = async (requestType: RequestType): Promise<RequestType[]> => {
    await api.put<RequestType>(`/request-types/${requestType.id}`, requestType);
    return getRequestTypes();
};

export const deleteRequestType = async (requestTypeId: number): Promise<RequestType[]> => {
    await api.del(`/request-types/${requestTypeId}`);
    return getRequestTypes();
};

export const getWorkflows = (): Promise<Workflow[]> => {
    return api.get<Workflow[]>('/workflows');
};

export const addWorkflow = async (workflow: Omit<Workflow, 'id'>): Promise<Workflow[]> => {
    await api.post<Workflow>('/workflows', workflow);
    return getWorkflows();
};

export const updateWorkflow = async (workflow: Workflow): Promise<Workflow[]> => {
    await api.put<Workflow>(`/workflows/${workflow.id}`, workflow);
    return getWorkflows();
};

export const deleteWorkflow = async (workflowId: number): Promise<Workflow[]> => {
    await api.del(`/workflows/${workflowId}`);
    return getWorkflows();
};
