import type { SystemUser } from '../types';
import { api } from './api';

export const login = (username: string, password: string): Promise<SystemUser> => {
    return api.post<SystemUser>('/auth/login', { username, password });
};
