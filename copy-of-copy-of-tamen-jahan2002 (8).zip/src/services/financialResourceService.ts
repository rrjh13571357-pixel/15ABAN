import type { FinancialResource } from '../types';
import { api } from './api';

export const getFinancialResources = (): Promise<FinancialResource[]> => {
    return api.get<FinancialResource[]>('/financial-resources');
};

export const addFinancialResource = async (resource: Omit<FinancialResource, 'id'>): Promise<FinancialResource[]> => {
    await api.post<FinancialResource>('/financial-resources', resource);
    return getFinancialResources();
}

export const updateFinancialResource = async (resource: FinancialResource): Promise<FinancialResource[]> => {
    await api.put<FinancialResource>(`/financial-resources/${resource.id}`, resource);
    return getFinancialResources();
}

export const deleteFinancialResource = async (resourceId: number): Promise<FinancialResource[]> => {
    await api.del(`/financial-resources/${resourceId}`);
    return getFinancialResources();
}
