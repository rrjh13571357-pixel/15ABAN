import type { OrganizationalUnit } from '../types';
import { api } from './api';

export const getOrgUnits = (): Promise<OrganizationalUnit[]> => {
    return api.get<OrganizationalUnit[]>('/org-units');
};

export const addOrgUnit = async (unit: Omit<OrganizationalUnit, 'id'>): Promise<OrganizationalUnit[]> => {
    await api.post<OrganizationalUnit>('/org-units', unit);
    return getOrgUnits();
}

export const updateOrgUnit = async (unit: OrganizationalUnit): Promise<OrganizationalUnit[]> => {
    await api.put<OrganizationalUnit>(`/org-units/${unit.id}`, unit);
    return getOrgUnits();
}

export const deleteOrgUnit = async (unitId: string): Promise<OrganizationalUnit[]> => {
    await api.del(`/org-units/${unitId}`);
    return getOrgUnits();
}
