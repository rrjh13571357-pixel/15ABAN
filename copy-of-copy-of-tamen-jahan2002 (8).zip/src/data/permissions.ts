// A registry of all available permissions in the system.
// Key: A unique string identifier for the permission.
// Value: A user-friendly description in Persian.

export interface PermissionGroup {
    title: string;
    items: Record<string, string>;
}

export const PERMISSIONS: Record<string, PermissionGroup> = {
    dashboard: {
        title: 'داشبورد',
        items: {
            'dashboard:view': 'مشاهده داشبورد اصلی',
        },
    },
    requests: {
        title: 'درخواست‌ها',
        items: {
            'requests:create': 'ایجاد درخواست جدید',
            'requests:view:own': 'مشاهده درخواست‌های خود',
            'requests:view:all': 'مشاهده تمام درخواست‌ها',
            'requests:delete': 'حذف درخواست',
            'requests:approve': 'تایید/رد مراحل درخواست',
        },
    },
    projects: {
        title: 'پروژه‌ها',
        items: {
            'projects:view': 'مشاهده پروژه‌ها',
            'projects:create': 'ایجاد پروژه جدید',
            'projects:edit': 'ویرایش پروژه‌ها',
            'projects:delete': 'حذف پروژه‌ها',
            'projects:manage_funds': 'مدیریت اعتبار (تزریق/انتقال)',
        }
    },
    contracts: {
        title: 'قراردادها',
        items: {
            'contracts:view': 'مشاهده قراردادها',
            'contracts:create': 'ایجاد قرارداد جدید',
            'contracts:edit': 'ویرایش قراردادها',
            'contracts:delete': 'حذف قراردادها',
            'contracts:manage_payments': 'مدیریت پرداخت‌های قرارداد',
        }
    },
    payroll: {
        title: 'حقوق و دستمزد',
        items: {
            'payroll:view': 'مشاهده لیست‌های حقوق',
            'payroll:create': 'ایجاد لیست حقوق جدید',
            'payroll:finalize': 'نهایی کردن و پرداخت لیست',
        }
    },
    reports: {
        title: 'گزارش‌گیری',
        items: {
            'reports:view:dashboard': 'مشاهده داشبورد گزارش‌ها',
            'reports:view:invoice_explorer': 'استفاده از کاوشگر فاکتور',
        }
    },
    automation: {
        title: 'اتوماسیون داخلی',
        items: {
            'automation:view:inbox': 'مشاهده کارتابل اتوماسیون',
            'automation:send': 'ارسال نامه جدید',
            'automation:manage_templates': 'مدیریت قالب نامه‌ها',
        }
    },
    baseInfo: {
        title: 'اطلاعات پایه',
        items: {
            'baseinfo:manage:org_structure': 'مدیریت ساختار سازمانی',
            'baseinfo:manage:persons': 'مدیریت اشخاص',
            'baseinfo:manage:bank_accounts': 'مدیریت شماره حساب‌ها',
            'baseinfo:manage:financial_resources': 'مدیریت منابع مالی',
        }
    },
    system: {
        title: 'مدیریت سیستم',
        items: {
            'system:manage:users': 'مدیریت کاربران و تعریف کاربر جدید',
            'system:manage:roles': 'مدیریت نقش‌ها',
            'system:manage:access_levels': 'مدیریت سطوح دسترسی',
            'system:manage:workflows': 'مدیریت گردش‌های کاری',
        }
    },
    ai: {
        title: 'تحلیلگر هوشمند',
        items: {
            'ai:use': 'استفاده از تحلیلگر هوشمند',
        }
    }
};
