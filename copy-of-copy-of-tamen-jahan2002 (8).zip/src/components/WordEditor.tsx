import React, { useRef, useEffect, useState } from 'react';

declare global {
    interface Window {
        WebViewer: any;
    }
}

interface WordEditorProps {
    file: File | null;
}

const WordEditor: React.FC<WordEditorProps> = ({ file }) => {
    const viewerDiv = useRef<HTMLDivElement>(null);
    const instanceRef = useRef<any>(null);
    const [isReady, setIsReady] = useState(false);

    useEffect(() => {
        if (!file || !viewerDiv.current) {
            return;
        }

        const container = viewerDiv.current;
        let isComponentMounted = true;

        const initialize = async (WebViewer: any) => {
            try {
                const instance = await WebViewer({
                    path: 'https://pdftron.s3.amazonaws.com/webviewer/10.7.0/public',
                    licenseKey: 'demo:1721245812971:7ff35f660300000000958b41703650222f7b8893d56f5195b058c42a5c', // Demo key
                    fullAPI: true,
                    enableOfficeEditing: true,
                }, container);

                if (!isComponentMounted) {
                    instance.UI.dispose();
                    return;
                }

                instanceRef.current = instance;
                const { documentViewer } = instance.Core;
                
                instance.UI.setLanguage('fa');
                
                documentViewer.addEventListener('documentLoaded', () => {
                    if (isComponentMounted) {
                        setIsReady(true);
                    }
                });
                
                instance.UI.loadDocument(file, { extension: 'docx' });

            } catch (error) {
                console.error("WebViewer initialization failed:", error);
            }
        };

        const pollForWebViewer = () => {
            if (window.WebViewer) {
                initialize(window.WebViewer);
            } else if (isComponentMounted) {
                setTimeout(pollForWebViewer, 100);
            }
        };

        pollForWebViewer();

        // Cleanup function
        return () => {
            isComponentMounted = false;
            if (instanceRef.current) {
                instanceRef.current.UI.dispose();
                instanceRef.current = null;
            }
            setIsReady(false);
        };
    }, [file]);

    const addSignature = () => {
        if (!instanceRef.current || !isReady) return;

        const { annotationManager, Annotations } = instanceRef.current.Core;
        
        const freeText = new Annotations.FreeTextAnnotation();
        freeText.PageNumber = 1;
        freeText.X = 100;
        freeText.Y = 150;
        freeText.Width = 150;
        freeText.Height = 50;
        freeText.setContents('علی احمدی'); // Example Signature
        freeText.Font = 'Vazirmatn';
        freeText.FontSize = '20pt';
        freeText.TextColor = new Annotations.Color(0, 0, 200);
        freeText.StrokeColor = new Annotations.Color(255, 255, 255, 0);
        freeText.FillColor = new Annotations.Color(255, 255, 255, 0);
        freeText.setPadding(new Annotations.Rect(0, 0, 0, 0));

        annotationManager.addAnnotation(freeText);
        annotationManager.redrawAnnotation(freeText);
    };

    return (
        <div className="flex flex-col h-full">
            <div className="bg-white p-2 border-b flex items-center space-x-4 space-x-reverse shadow-sm">
                <button
                    onClick={addSignature}
                    className="bg-gray-200 text-gray-800 px-4 py-1.5 rounded-md text-sm font-semibold hover:bg-gray-300 disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors"
                    disabled={!isReady}
                >
                    درج امضا (نمونه)
                </button>
                <span className="text-xs text-gray-600">فایل شما برای ویرایش آماده است. تغییرات به صورت خودکار ذخیره می‌شوند.</span>
            </div>
            <div className="webviewer w-full flex-1" ref={viewerDiv}>
                 {!instanceRef.current && (
                    <div className="flex items-center justify-center h-full text-gray-500">
                        در حال آماده سازی ویرایشگر...
                    </div>
                )}
            </div>
        </div>
    );
};

export default WordEditor;
