
import type { SystemUser, Beneficiary, PettyCashHolder, Role, AccessLevel } from '../shared/types';
import { db } from './db';

// --- System Users ---
export const getSystemUsers = (): SystemUser[] => {
    return db.systemUsers.get();
};

export const addSystemUser = (user: Omit<SystemUser, 'id'>): SystemUser[] => {
    const users = db.systemUsers.get();
    const newUser: SystemUser = { ...user, id: Date.now() };
    users.push(newUser);
    db.systemUsers.set(users);
    return users;
};

export const updateSystemUser = (user: SystemUser): SystemUser[] => {
    let users = db.systemUsers.get();
    const index = users.findIndex(u => u.id === user.id);
    if (index !== -1) {
        users[index] = user;
        db.systemUsers.set(users);
        return users;
    }
    throw new Error('SystemUser not found');
};

export const deleteSystemUser = (userId: number): SystemUser[] => {
    let users = db.systemUsers.get();
    const updatedUsers = users.filter(u => u.id !== userId);
    if (users.length === updatedUsers.length) {
       throw new Error('SystemUser not found');
    }
    db.systemUsers.set(updatedUsers);
    return updatedUsers;
};

// --- Beneficiaries ---
export const getBeneficiaries = (): Beneficiary[] => {
    return db.beneficiaries.get();
};

export const addBeneficiary = (beneficiary: Omit<Beneficiary, 'id'>): Beneficiary[] => {
    const beneficiaries = db.beneficiaries.get();
    const newBeneficiary: Beneficiary = { ...beneficiary, id: Date.now() };
    beneficiaries.push(newBeneficiary);
    db.beneficiaries.set(beneficiaries);
    return beneficiaries;
};

export const updateBeneficiary = (beneficiary: Beneficiary): Beneficiary[] => {
    let beneficiaries = db.beneficiaries.get();
    const index = beneficiaries.findIndex(b => b.id === beneficiary.id);
    if (index !== -1) {
        beneficiaries[index] = beneficiary;
        db.beneficiaries.set(beneficiaries);
        return beneficiaries;
    }
    throw new Error('Beneficiary not found');
};

export const deleteBeneficiary = (beneficiaryId: number): Beneficiary[] => {
    let beneficiaries = db.beneficiaries.get();
    const updatedBeneficiaries = beneficiaries.filter(b => b.id !== beneficiaryId);
    if (beneficiaries.length === updatedBeneficiaries.length) {
       throw new Error('Beneficiary not found');
    }
    db.beneficiaries.set(updatedBeneficiaries);
    return updatedBeneficiaries;
};

// --- Petty Cash Holders ---
export const getPettyCashHolders = (): PettyCashHolder[] => {
    return db.pettyCashHolders.get();
};

export const addPettyCashHolder = (holder: Omit<PettyCashHolder, 'id'>): PettyCashHolder[] => {
    const holders = db.pettyCashHolders.get();
    const newHolder: PettyCashHolder = { ...holder, id: Date.now() };
    holders.push(newHolder);
    db.pettyCashHolders.set(holders);
    return holders;
};

export const updatePettyCashHolder = (holder: PettyCashHolder): PettyCashHolder[] => {
    let holders = db.pettyCashHolders.get();
    const index = holders.findIndex(h => h.id === holder.id);
    if (index !== -1) {
        holders[index] = holder;
        db.pettyCashHolders.set(holders);
        return holders;
    }
    throw new Error('PettyCashHolder not found');
};

export const deletePettyCashHolder = (holderId: number): PettyCashHolder[] => {
    let holders = db.pettyCashHolders.get();
    const updatedHolders = holders.filter(h => h.id !== holderId);
    if (holders.length === updatedHolders.length) {
       throw new Error('PettyCashHolder not found');
    }
    db.pettyCashHolders.set(updatedHolders);
    return updatedHolders;
};

// --- Roles ---
export const getRoles = (): Role[] => {
    return db.roles.get();
};

export const addRole = (role: Omit<Role, 'id'>): Role[] => {
    const roles = db.roles.get();
    const newRole: Role = {
        ...role,
        id: Date.now(),
        userCount: role.userCount || 0,
    };
    roles.push(newRole);
    db.roles.set(roles);
    return roles;
};

export const updateRole = (role: Role): Role[] => {
    let roles = db.roles.get();
    const index = roles.findIndex(r => r.id === role.id);
    if (index !== -1) {
        roles[index] = role;
        db.roles.set(roles);
        return roles;
    }
    throw new Error('Role not found');
};

export const deleteRole = (roleId: number): Role[] => {
    let roles = db.roles.get();
    const updatedRoles = roles.filter(r => r.id !== roleId);
     if (roles.length === updatedRoles.length) {
       throw new Error('Role not found');
    }
    db.roles.set(updatedRoles);
    return updatedRoles;
};


// --- Access Levels ---
export const getAccessLevels = (): AccessLevel[] => {
    return db.accessLevels.get();
};

export const addAccessLevel = (level: Omit<AccessLevel, 'id'>): AccessLevel[] => {
    const levels = db.accessLevels.get();
    const newLevel: AccessLevel = {
        ...level,
        id: Date.now(),
    };
    levels.push(newLevel);
    db.accessLevels.set(levels);
    return levels;
};

export const updateAccessLevel = (level: AccessLevel): AccessLevel[] => {
    let levels = db.accessLevels.get();
    const index = levels.findIndex(l => l.id === level.id);
    if (index !== -1) {
        levels[index] = level;
        db.accessLevels.set(levels);
        return levels;
    }
    throw new Error('AccessLevel not found');
};

export const deleteAccessLevel = (levelId: number): AccessLevel[] => {
    let levels = db.accessLevels.get();
    const updatedLevels = levels.filter(l => l.id !== levelId);
     if (levels.length === updatedLevels.length) {
       throw new Error('AccessLevel not found');
    }
    db.accessLevels.set(updatedLevels);
    return updatedLevels;
};