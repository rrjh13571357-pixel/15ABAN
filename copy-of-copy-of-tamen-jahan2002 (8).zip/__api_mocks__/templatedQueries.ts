import type { TemplatedQuery } from '../shared/types';

const templates: TemplatedQuery[] = [
    {
        id: 'project_full_analysis',
        displayText: 'تحلیل کامل یک پروژه...',
        template: 'تحلیل کامل پروژه {{entity}}',
        entityType: 'project',
        description: 'اطلاعات کامل یک پروژه شامل بودجه، هزینه‌ها و مانده را نمایش می‌دهد.',
        command: 'project_full_analysis',
    },
    {
        id: 'contract_status_check',
        displayText: 'بررسی وضعیت یک قرارداد...',
        template: 'وضعیت قرارداد {{entity}} چیست؟',
        entityType: 'contract',
        description: 'وضعیت فعلی (فعال، در حال بررسی، آرشیو شده) یک قرارداد را برمی‌گرداند.',
        command: 'contract_status_check',
    },
];

export const getTemplates = (): TemplatedQuery[] => {
    return templates;
};