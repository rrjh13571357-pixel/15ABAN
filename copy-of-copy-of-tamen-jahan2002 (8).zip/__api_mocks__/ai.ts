
import * as projects from '@virtual-backend/controllers/projectController';
import * as contracts from '@virtual-backend/controllers/contractController';
import * as organization from '@virtual-backend/controllers/organizationController';
import * as reports from '@virtual-backend/controllers/reportController';
import { ContractStatus, Project, Contract } from '@shared/types';

// --- Entity Extraction ---
const extractEntity = (question: string, entities: {id: any, name?: string, title?: string, party?: string}[]): {id: any, name: string} | null => {
    const q = question.toLowerCase();
    for (const entity of entities) {
        const entityName = entity.name || entity.title || entity.party || '';
        if (q.includes(entityName.toLowerCase())) {
            return { id: entity.id, name: entityName };
        }
    }
    return null;
};


// --- Intent Recognition ---
const getIntent = (question: string): { intent: string; params: any } => {
    const q = question.toLowerCase();

    // --- Templated Query Intents ---
    if (q.startsWith('تحلیل کامل پروژه')) {
        const projectList = projects.getProjects();
        const projectEntity = extractEntity(question, projectList);
        if (projectEntity) {
            return { intent: 'GET_FULL_PROJECT_ANALYSIS', params: { projectId: projectEntity.id, projectName: projectEntity.name } };
        }
    }
    if (q.startsWith('وضعیت قرارداد')) {
        const contractList = contracts.getContractList();
        const contractEntity = extractEntity(question, contractList);
        if (contractEntity) {
            return { intent: 'GET_CONTRACT_STATUS', params: { contractId: contractEntity.id, contractTitle: contractEntity.name } };
        }
    }

    // Report intents
    if (q.includes('گزارش') && q.includes('مالی') && q.includes('پروژه')) {
        return { intent: 'GET_PROJECT_FINANCIAL_REPORT', params: {} };
    }

    // --- Specific Entity Intents (must come first) ---
    if (q.includes('بودجه') && q.includes('پروژه')) {
        const projectList = projects.getProjects();
        const projectEntity = extractEntity(question, projectList);
        if(projectEntity) {
            return { intent: 'GET_PROJECT_BUDGET', params: { projectId: projectEntity.id, projectName: projectEntity.name } };
        }
    }
    
    if (q.includes('آخرین') && q.includes('قرارداد')) {
        const contractList = contracts.getContractList();
        const contractPartyEntity = extractEntity(question, contractList);
        if(contractPartyEntity) {
            return { intent: 'GET_LAST_CONTRACT_WITH_PARTY', params: { partyName: contractPartyEntity.name } };
        }
    }


    // --- General List/Sort Intents ---
    if (q.includes('پروژه') && (q.includes('بیشترین') || q.includes('بالاترین')) && q.includes('بودجه')) {
        return { intent: 'GET_PROJECTS_BY_BUDGET', params: { sort: 'desc' } };
    }
    if (q.includes('پروژه') && (q.includes('کمترین') || q.includes('پایین‌ترین')) && q.includes('بودجه')) {
        return { intent: 'GET_PROJECTS_BY_BUDGET', params: { sort: 'asc' } };
    }
    if (q.includes('پروژه') && (q.includes('خارج از بودجه') || q.includes('کسری') || q.includes('بیشتر از بودجه'))) {
        return { intent: 'GET_OVER_BUDGET_PROJECTS', params: {} };
    }
     if (q.includes('تعداد') && q.includes('پروژه')) {
        return { intent: 'COUNT_PROJECTS', params: {} };
    }
     if (q.includes('لیست') && q.includes('پروژه')) {
        return { intent: 'LIST_PROJECTS', params: {} };
    }

    if ((q.includes('قرارداد') || q.includes('قراردادهای')) && (q.includes('فعال'))) {
        return { intent: 'GET_CONTRACTS_BY_STATUS', params: { status: ContractStatus.Active } };
    }
    if ((q.includes('قرارداد') || q.includes('قراردادهای')) && (q.includes('در دست بررسی') || q.includes('منتظر'))) {
        return { intent: 'GET_CONTRACTS_BY_STATUS', params: { status: ContractStatus.Pending } };
    }
    if ((q.includes('قرارداد') || q.includes('قراردادهای')) && (q.includes('آرشیو'))) {
        return { intent: 'GET_CONTRACTS_BY_STATUS', params: { status: ContractStatus.Archived } };
    }
    if (q.includes('تعداد') && q.includes('قرارداد')) {
        const statusMatch = q.match(/فعال|در دست بررسی|آرشیو/);
        const status = statusMatch ? statusMatch[0] as ContractStatus : 'all';
        return { intent: 'COUNT_CONTRACTS', params: { status } };
    }

    if (q.includes('سلام') || q.includes('وقت بخیر') || q.includes('چطوری')) {
        return { intent: 'GREETING', params: {} };
    }

    return { intent: 'UNKNOWN', params: {} };
};

// --- Response Generation ---
export const getAnalysis = (question: string): string => {
    const { intent, params } = getIntent(question);

    try {
        switch (intent) {
            case 'GREETING':
                return 'سلام! من آماده‌ام تا به سوالات شما درباره داده‌های سیستم پاسخ دهم.';

            case 'GET_FULL_PROJECT_ANALYSIS': {
                const project = projects.getProjects().find((p: Project) => p.id === params.projectId);
                if (!project) return `متاسفانه پروژه‌ای با نام "${params.projectName}" یافت نشد.`;

                const remaining = {
                    rial: project.budget.rial - project.spentAmount.rial,
                    usd: project.budget.usd - project.spentAmount.usd,
                    eur: project.budget.eur - project.spentAmount.eur,
                };
                const orgUnits = organization.getOrgUnits();
                const unit = orgUnits.find(u => u.id === project.orgUnitId);
                
                let response = `تحلیل کامل پروژه "${params.projectName}":\n\n`;
                response += `- واحد سازمانی: ${unit ? unit.title : 'نامشخص'}\n`;
                response += `- تاریخ شروع: ${project.startDate}\n\n`;
                response += `بودجه کل:\n`;
                response += `  - ${project.budget.rial.toLocaleString()} ریال\n`;
                response += `  - ${project.budget.usd.toLocaleString()} دلار\n`;
                response += `  - ${project.budget.eur.toLocaleString()} یورو\n\n`;
                response += `هزینه شده:\n`;
                response += `  - ${project.spentAmount.rial.toLocaleString()} ریال\n`;
                response += `  - ${project.spentAmount.usd.toLocaleString()} دلار\n`;
                response += `  - ${project.spentAmount.eur.toLocaleString()} یورو\n\n`;
                response += `مانده اعتبار:\n`;
                response += `  - ${remaining.rial.toLocaleString()} ریال\n`;
                response += `  - ${remaining.usd.toLocaleString()} دلار\n`;
                response += `  - ${remaining.eur.toLocaleString()} یورو\n`;

                return response;
            }

            case 'GET_CONTRACT_STATUS': {
                const contract = contracts.getContractDetails(params.contractId);
                 if (!contract) return `متاسفانه قراردادی با عنوان "${params.contractTitle}" یافت نشد.`;
                 return `وضعیت فعلی قرارداد "${contract.title}"، "${contract.status}" می‌باشد.`
            }
            
            case 'GET_PROJECT_BUDGET': {
                const project = projects.getProjects().find((p: Project) => p.id === params.projectId);
                if (!project) return `متاسفانه پرو‌ای با نام "${params.projectName}" یافت نشد.`;
                let response = `بودجه پروژه "${params.projectName}":\n\n`;
                response += `- ریال: ${project.budget.rial.toLocaleString()}\n`;
                response += `- دلار: ${project.budget.usd.toLocaleString()}\n`;
                response += `- یورو: ${project.budget.eur.toLocaleString()}`;
                return response;
            }

            case 'GET_PROJECT_FINANCIAL_REPORT': {
                const summary = reports.getProjectFinancialSummary();
                if (summary.labels.length === 0) {
                    return 'هیچ پروژه‌ای برای گزارش‌گیری مالی یافت نشد.';
                }
                let response = `گزارش مالی برای ${summary.labels.length} پروژه برتر:\n\n`;
                summary.labels.forEach((label, index) => {
                    const budget = summary.datasets[0].data[index];
                    const spent = summary.datasets[1].data[index];
                    response += `- ${label}:\n`;
                    response += `  - بودجه: ${budget.toLocaleString()} ریال\n`;
                    response += `  - هزینه: ${spent.toLocaleString()} ریال\n`;
                    response += `  - مانده: ${(budget - spent).toLocaleString()} ریال\n\n`;
                });
                return response;
            }

            case 'GET_LAST_CONTRACT_WITH_PARTY': {
                const contractList = contracts.getContractList();
                const partyContracts = contractList.filter((c: Contract) => c.party === params.partyName);
                if (partyContracts.length === 0) return `هیچ قراردادی با طرف قرارداد "${params.partyName}" یافت نشد.`;
                
                const lastContract = partyContracts.sort((a: Contract, b: Contract) => b.id - a.id)[0];

                return `آخرین قرارداد با "${params.partyName}"، قرارداد "${lastContract.title}" به شماره ${lastContract.contractNumber} است که در تاریخ ${lastContract.endDate} به پایان می‌رسد.`;
            }

            case 'GET_PROJECTS_BY_BUDGET': {
                const projectList = projects.getProjects();
                const sortedProjects = [...projectList].sort((a, b) => {
                    if (params.sort === 'desc') return b.budget.rial - a.budget.rial;
                    return a.budget.rial - b.budget.rial;
                });
                const topProjects = sortedProjects.slice(0, 3);
                if (topProjects.length === 0) return 'در حال حاضر هیچ پروژه‌ای در سیستم ثبت نشده است.';
                
                let response = `لیست ${topProjects.length} پروژه با ${params.sort === 'desc' ? 'بیشترین' : 'کمترین'} بودجه ریالی:\n\n`;
                topProjects.forEach((p, i) => {
                    response += `${i + 1}. ${p.name} - بودجه: ${p.budget.rial.toLocaleString()} ریال\n`;
                });
                return response;
            }
            
            case 'GET_OVER_BUDGET_PROJECTS': {
                const projectList = projects.getProjects();
                const overBudgetProjects = projectList.filter((p: Project) => p.spentAmount.rial > p.budget.rial);

                if (overBudgetProjects.length === 0) {
                    return 'خوشبختانه هیچ پروژه‌ای خارج از بودجه مصوب ریالی خود نیست.';
                }

                let response = `تعداد ${overBudgetProjects.length} پروژه خارج از بودجه ریالی یافت شد:\n\n`;
                overBudgetProjects.forEach((p: Project, i: number) => {
                    const deficit = p.spentAmount.rial - p.budget.rial;
                    response += `${i + 1}. ${p.name} - کسری بودجه: ${deficit.toLocaleString()} ریال\n`;
                });
                return response;
            }
            
             case 'COUNT_PROJECTS': {
                const projectList = projects.getProjects();
                return `در حال حاضر تعداد ${projectList.length} پروژه در سیستم ثبت شده است.`;
            }
            
            case 'LIST_PROJECTS': {
                const projectList = projects.getProjects();
                if (projectList.length === 0) return 'در حال حاضر هیچ پروژه‌ای در سیستم ثبت نشده است.';
                let response = `لیست کل پروژه‌ها:\n\n`;
                projectList.forEach((p: Project, i: number) => {
                    response += `${i + 1}. ${p.name}\n`;
                });
                return response;
            }

            case 'GET_CONTRACTS_BY_STATUS': {
                const contractList = contracts.getContractList();
                const filteredContracts = contractList.filter((c: Contract) => c.status === params.status);
                if (filteredContracts.length === 0) return `در حال حاضر هیچ قراردادی با وضعیت "${params.status}" وجود ندارد.`;

                let response = `لیست قراردادهای با وضعیت "${params.status}":\n\n`;
                filteredContracts.forEach((c: Contract, i: number) => {
                    response += `${i + 1}. ${c.title} (شماره: ${c.contractNumber})\n`;
                });
                return response;
            }

            case 'COUNT_CONTRACTS': {
                const contractList = contracts.getContractList();
                if (params.status === 'all') {
                    return `در مجموع ${contractList.length} قرارداد در سیستم وجود دارد.`;
                }
                const count = contractList.filter((c: Contract) => c.status === params.status).length;
                return `تعداد ${count} قرارداد با وضعیت "${params.status}" وجود دارد.`;
            }

            case 'UNKNOWN':
            default:
                return 'متاسفانه متوجه سوال شما نشدم. می‌توانید سوال خود را به شکل دیگری بپرسید؟ برای مثال: "کدام پروژه‌ها بیشترین بودجه را دارند؟"';
        }
    } catch (error) {
        console.error("Analysis controller error:", error);
        return "خطایی در هنگام تحلیل داده‌ها رخ داد. لطفاً با پشتیبانی تماس بگیرید.";
    }
};
