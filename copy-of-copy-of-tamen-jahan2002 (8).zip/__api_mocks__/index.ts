

import * as auth from '@mocks/auth';
import * as organization from '@virtual-backend/controllers/organizationController';
import * as requests from '@mocks/requests';
import * as workflow from '@virtual-backend/controllers/workflowController';
import * as projects from '@virtual-backend/controllers/projectController';
import * as contracts from '@virtual-backend/controllers/contractController';
import * as ai from '@mocks/ai';
import * as notifications from '@mocks/notifications';
import * as templatedQueries from '@mocks/templatedQueries';
import * as payroll from '@mocks/payroll';
import * as reports from '@mocks/reports';

// A helper to simulate network delay for API calls
const simulateApiCall = <T>(data: T, delay: number = 500): Promise<T> => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve(data);
        }, delay);
    });
};

const createApiController = <T extends Record<string, (...args: any[]) => any>>(controller: T): { [K in keyof T]: (...args: Parameters<T[K]>) => Promise<ReturnType<T[K]>> } => {
    return Object.keys(controller).reduce((acc, key) => {
        acc[key as keyof T] = (...args: Parameters<T[keyof T]>) => {
            try {
                const result = controller[key as keyof T](...args);
                return simulateApiCall(result);
            } catch (error) {
                return Promise.reject(error);
            }
        };
        return acc;
    }, {} as { [K in keyof T]: (...args: Parameters<T[K]>) => Promise<ReturnType<T[K]>> });
};

export const api = {
    auth: createApiController(auth),
    organization: createApiController(organization),
    requests: createApiController(requests),
    workflow: createApiController(workflow),
    projects: createApiController(projects),
    contracts: createApiController(contracts),
    ai: createApiController(ai),
    notifications: createApiController(notifications),
    templatedQueries: createApiController(templatedQueries),
    payroll: createApiController(payroll),
    reports: createApiController(reports),
};
