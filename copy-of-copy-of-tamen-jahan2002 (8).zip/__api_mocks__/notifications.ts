
import type { Notification } from '../shared/types';
import { db } from './db';

export const getNotifications = (): Notification[] => {
    return db.notifications.get().sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

export const markNotificationAsRead = (notificationId: number): Notification[] => {
    let notifications = db.notifications.get();
    const index = notifications.findIndex(n => n.id === notificationId);
    if (index !== -1) {
        notifications[index].isRead = true;
        db.notifications.set(notifications);
        return getNotifications();
    }
    throw new Error('Notification not found');
};

export const markAllNotificationsAsRead = (): Notification[] => {
    let notifications = db.notifications.get();
    notifications.forEach(n => n.isRead = true);
    db.notifications.set(notifications);
    return getNotifications();
};