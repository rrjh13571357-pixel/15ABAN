import type { SystemUser, Beneficiary, PettyCashHolder, Role, OrganizationalUnit, Request, RequestType, Workflow, BankAccount, AccessLevel, Project, FinancialResource, Task, Contract, Payment, Guarantee, Addendum, Attachment, ContractDetails, Notification, Payroll, PayrollItem, Invoice, InvoiceItem } from '../shared/types';
import { RequestStatus, TaskStatus, ContractStatus, PayrollStatus } from '../shared/types';

// Storage Keys
const SYSTEM_USERS_STORAGE_KEY = 'mockSystemUsers';
const BENEFICIARIES_STORAGE_KEY = 'mockBeneficiaries';
const PETTY_CASH_HOLDERS_STORAGE_KEY = 'mockPettyCashHolders';
const BANK_ACCOUNTS_STORAGE_KEY = 'mockBankAccounts';
const ACCESS_LEVELS_STORAGE_KEY = 'mockAccessLevels';
const PROJECTS_STORAGE_KEY = 'mockProjects';
const FINANCIAL_RESOURCES_STORAGE_KEY = 'mockFinancialResources';
const TASKS_STORAGE_KEY = 'mockTasks';
const CONTRACTS_STORAGE_KEY = 'mockContracts';
const PAYMENTS_STORAGE_KEY = 'mockPayments';
const GUARANTEES_STORAGE_KEY = 'mockGuarantees';
const ADDENDUMS_STORAGE_KEY = 'mockAddendums';
const ATTACHMENTS_STORAGE_KEY = 'mockAttachments';
const NOTIFICATIONS_STORAGE_KEY = 'mockNotifications';
const PAYROLLS_STORAGE_KEY = 'mockPayrolls';
const PAYROLL_ITEMS_STORAGE_KEY = 'mockPayrollItems';
const INVOICES_STORAGE_KEY = 'mockInvoices';
const INVOICE_ITEMS_STORAGE_KEY = 'mockInvoiceItems';


const ROLES_STORAGE_KEY = 'mockRoles';
const ORG_UNITS_STORAGE_KEY = 'mockOrgUnits';
const REQUEST_TYPES_STORAGE_KEY = 'mockRequestTypes';
const WORKFLOWS_STORAGE_KEY = 'mockWorkflows';
// FIX: Add requests storage key
const REQUESTS_STORAGE_KEY = 'mockRequests';


// --- Initial Data ---
// FIX: Added missing properties to SystemUser objects to match the type definition.
const initialSystemUsers: SystemUser[] = [
    {id: 1, fullName: 'علی احمدی', nationalCode: '1234567890', unitId: '2', roleId: 1, username: 'ali.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 6, fullName: 'مدیر سیستم', nationalCode: '1010101010', unitId: '4', roleId: 4, username: 'admin', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: true },
    {id: 7, fullName: 'سارا احمدی', nationalCode: '111222333', unitId: '1', roleId: 2, username: 'sara.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 8, fullName: 'علی رضایی', nationalCode: '444555666', unitId: '2', roleId: 1, username: 'ali.rezaei', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 9, fullName: 'مریم حسینی', nationalCode: '777888999', unitId: '3', roleId: 1, username: 'maryam.hosseini', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 10, fullName: 'رضا قاسمی', nationalCode: '121212121', unitId: '4', roleId: 1, username: 'reza.ghasemi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
];

const initialBeneficiaries: Beneficiary[] = [
    {id: 2, fullName: 'شرکت داده‌پردازان نوین', nationalCode: '0987654321'},
    {id: 3, fullName: 'کیومرث حسن پور (پیمانکار)', nationalCode: '1122334455'},
    {id: 11, fullName: 'علی اصغری نژاد', nationalCode: '223344556'},
    {id: 12, fullName: 'آقای محمدی', nationalCode: '778899001'},
    {id: 13, fullName: 'هیدروفن کوانتومی', nationalCode: '555666777'},
];

// FIX: Added missing 'pettyCashLimit' property to PettyCashHolder objects.
const initialPettyCashHolders: PettyCashHolder[] = [
    {id: 4, fullName: 'روح الله جهان پناه', nationalCode: '5566778899', associatedCenterId: '1', pettyCashLimit: 50000000},
    {id: 5, fullName: 'محسن سعادتی', nationalCode: '0000000000', associatedCenterId: '2', pettyCashLimit: 75000000},
];

const initialBankAccounts: BankAccount[] = [
    {id: 1, bankName: 'ملت', accountNumber: '123-456-789', iban: '210120000000001234567890', ownerId: 2, ownerType: 'beneficiary'},
    {id: 2, bankName: 'صادرات', accountNumber: '987-654-321', iban: '110190000000009876543210', ownerId: 4, ownerType: 'pettyCash'},
    {id: 3, bankName: 'ملی', accountNumber: '111-222-333', iban: '150170000000101112223330', ownerId: 3, ownerType: 'beneficiary'},
];

const initialRoles: Role[] = [
    { id: 1, title: 'کارمند', description: 'نقش پیش فرض برای کاربران', userCount: 1, status: 'فعال' },
    { id: 2, title: 'مدیر واحد', description: 'اداری', userCount: 0, status: 'فعال' },
    { id: 3, title: 'پیمانکار', description: '-', userCount: 0, status: 'فعال' },
    { id: 4, title: 'مدیر سیستم', description: 'این نقش بالاترین سطح دسترسی را در کل سیستم دارد.', userCount: 1, status: 'فعال' },
];

// FIX: Added missing 'permissions' property to AccessLevel objects.
const initialAccessLevels: AccessLevel[] = [
    { id: 1, title: 'دسترسی کامل مدیریتی', description: 'دسترسی به تمام بخش‌های سیستم', roleIds: [4], permissions: [] },
    { id: 2, title: 'دسترسی کارمندان مالی', description: 'دسترسی به ثبت و مشاهده درخواست‌ها', roleIds: [1, 2], permissions: [] },
];

const initialFinancialResources: FinancialResource[] = [
    { id: 1, name: 'منابع جاری' },
    { id: 2, name: 'منابع عمرانی' },
    { id: 3, name: 'سایر منابع' },
];

const initialProjects: Project[] = [
    { id: 1, name: 'پروژه آلفا', orgUnitId: '2', startDate: '1401/10/25', financialResourceId: 1, budget: { rial: 1000000000, usd: 5000, eur: 0 }, spentAmount: { rial: 450000000, usd: 1200, eur: 0 } },
    { id: 2, name: 'پروژه بتا', orgUnitId: '2', startDate: '1402/02/30', financialResourceId: 1, budget: { rial: 500000000, usd: 0, eur: 0 }, spentAmount: { rial: 100000000, usd: 0, eur: 0 } },
    { id: 3, name: 'پروژه گاما', orgUnitId: '3', startDate: '1401/08/10', financialResourceId: 2, budget: { rial: 2500000000, usd: 10000, eur: 15000 }, spentAmount: { rial: 2600000000, usd: 10500, eur: 14000 } }, // Over budget
    { id: 4, name: 'پروژه توسعه زیرساخت', orgUnitId: '4', startDate: '1402/10/11', financialResourceId: 2, budget: { rial: 5000000000, usd: 0, eur: 50000 }, spentAmount: { rial: 1200000000, usd: 0, eur: 10000 } },
];

// FIX: Replaced 'manager' property with 'managerId' and used appropriate user IDs.
const initialOrgUnits: OrganizationalUnit[] = [
    { id: '1', title: 'مدیریت مالی', code: '100', managerId: 7, parent: null },
    { id: '2', title: 'حسابداری', code: '101', managerId: 8, parent: '1' },
    { id: '3', title: 'خزانه', code: '102', managerId: 9, parent: '1' },
    { id: '4', title: 'فناوری اطلاعات', code: '200', managerId: 6, parent: null },
];

// FIX: Changed 'amount' from a number to a CurrencyAmount object to match the type definition.
export const initialRequests: Request[] = [
  { id: 'SR-1761155412530', subject: 'هارد دیسک', applicant: 'مدیر سیستم', amount: { rial: 200, usd: 0, eur: 0 }, date: '1404/07/30', deadline: null, status: RequestStatus.Completed, projectId: 4, originalApplicantId: 6, currentStepOwnerId: 6, requestTypeId: 3, workflowId: 3, lastModified: new Date().toISOString() },
  { id: 'SR-1761155000398', subject: 'خرید سرور', applicant: 'مدیر سیستم', amount: { rial: 2535, usd: 0, eur: 0 }, date: '1404/07/30', deadline: null, status: RequestStatus.Completed, projectId: 4, originalApplicantId: 6, currentStepOwnerId: 6, requestTypeId: 3, workflowId: 3, lastModified: new Date().toISOString() },
  { id: 'SR-1760960436510', subject: 'خرید تجهیزات شبکه', applicant: 'مدیر سیستم', amount: { rial: 25, usd: 0, eur: 0 }, date: '1404/07/28', deadline: null, status: RequestStatus.InProgress, projectId: 4, originalApplicantId: 6, currentStepOwnerId: 6, requestTypeId: 3, workflowId: 3, lastModified: new Date().toISOString() },
  { id: 'SR-1760927118147', subject: 'ارسال هزینه تنخواه', applicant: 'روح الله جهان پناه', amount: { rial: 232232232, usd: 0, eur: 0 }, date: '1404/07/27', deadline: null, status: RequestStatus.InProgress, originalApplicantId: 4, currentStepOwnerId: 7, requestTypeId: 2, workflowId: 2, lastModified: new Date().toISOString() },
  { id: 'SR-1760808382915', subject: 'هزینه های جاری', applicant: 'ممیزی', amount: { rial: 111111, usd: 0, eur: 0 }, date: '1404/07/26', deadline: null, status: RequestStatus.Pending, originalApplicantId: 1, currentStepOwnerId: 7, requestTypeId: 5, workflowId: 1, lastModified: new Date().toISOString() },
  { id: 'SR-1760751389869', subject: 'خرید تجهیزات اداری', applicant: 'مدیر سیستم', amount: { rial: 1000000, usd: 0, eur: 0 }, date: '1404/07/25', deadline: null, status: RequestStatus.Rejected, projectId: 2, originalApplicantId: 6, currentStepOwnerId: 6, requestTypeId: 3, workflowId: 3, lastModified: new Date().toISOString() },
];

// FIX: Added missing 'workflowId' property to RequestType objects.
const initialRequestTypes: RequestType[] = [
    { id: 1, title: 'تامین پیش پرداخت قرارداد', deadline: null, attachedFileRequired: false, workflowId: 5 },
    { id: 2, title: 'ارسال هزینه تنخواه', deadline: null, attachedFileRequired: true, workflowId: 2 },
    { id: 3, title: 'خرید', deadline: 7, attachedFileRequired: true, workflowId: 3 },
    { id: 4, title: 'تامین تنخواه گردان', deadline: 10, attachedFileRequired: false, workflowId: 1 },
    { id: 5, title: 'دیون', deadline: null, attachedFileRequired: false, workflowId: 1 },
];

const initialWorkflows: Workflow[] = [
    { id: 1, name: 'PettyCashWorkflow', steps: [{name: 'مرحله مدیریتی', responsible: 'مدیر واحد'}, {name: 'مرحله بعدی', responsible: 'حسابداری'}], icon: 'P' },
    { id: 2, name: 'ارسال هزینه تنخواه - گردش پیش فرض', steps: [{name: 'مرحله اولیه', responsible: 'درخواست کننده'}, {name: 'تایید مدیریتی', responsible: 'مدیر مافوق'}, {name: 'بررسی مدیر', responsible: 'مدیر واحد'}, {name: 'تصویب', responsible: 'مسئول واحد در عملیات'}], icon: 'A' },
    { id: 3, name: 'خرید مستقیم', steps: [{name: 'ثبت اولیه', responsible: 'مسئول سیستم'}, {name: 'تایید', responsible: 'مدیر'}, {name: 'بررسی', responsible: 'مدیر مالی'}, {name: 'تایید مدیر عامل', responsible: 'مدیر عامل'}], icon: 'K' },
    { id: 4, name: 'PettyCash WF', steps: [{name: 'Step 1', responsible: 'کاربر'}, {name: 'تایید', responsible: 'مسئول واحد'}, {name: 'تایید مدیر عامل', responsible: 'مدیر عامل'}], icon: 'P' },
];

const initialTasks: Task[] = [
    { id: 1, title: 'تهیه گزارش ماهانه فروش', responsible: 'سارا احمدی', status: TaskStatus.Completed, progress: 100, lastUpdate: '1403/04/18', deadline: null },
    { id: 2, title: 'بررسی و تطبیق حساب‌های بانکی', responsible: 'علی رضایی', status: TaskStatus.InProgress, progress: 50, lastUpdate: '1403/04/22', deadline: '1403/05/10' },
    { id: 3, title: 'آماده‌سازی لیست حقوق و دستمزد تیر ماه', responsible: 'سارا احمدی', status: TaskStatus.InProgress, progress: 100, lastUpdate: '1403/04/22', deadline: '1403/05/02' },
    { id: 4, title: 'پیگیری مطالبات معوق از مشتریان', responsible: 'مریم حسینی', status: TaskStatus.NotStarted, progress: 22, lastUpdate: '1403/04/19', deadline: '1403/04/28' },
    { id: 5, title: 'ثبت اسناد حسابداری خرید', responsible: 'رضا قاسمی', status: TaskStatus.Blocked, progress: 10, lastUpdate: '1403/04/19', deadline: '1403/04/20' },
    { id: 6, title: 'تهیه اظهارنامه مالیات بر ارزش افزوده فصل بهار', responsible: 'علی رضایی', status: TaskStatus.Completed, progress: 100, lastUpdate: '1403/04/18', deadline: null },
];

const initialContracts: ContractDetails[] = [
    { id: 1, contractNumber: '1403-04-0001', title: 'دستگاه فیلامنت کامپیوتری', party: 'هیدروفن کوانتومی', amount: 102000000, endDate: '1404/02/17', status: ContractStatus.Pending, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/02/17', guarantees: [], payments: [], addendums: [], attachments: [] },
    { id: 2, contractNumber: '1403-01-0001', title: 'هیدروفن کوانتومی', party: 'علی اصغری نژاد', amount: 60000000, endDate: '1404/01/10', status: ContractStatus.Pending, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/01/10', guarantees: [], payments: [], addendums: [], attachments: [] },
    { id: 3, contractNumber: '1403-05-0001', title: 'مشاوره و تحلیل سیستم', party: 'آقای محمدی', amount: null, endDate: '1404/11/13', status: ContractStatus.Active, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/11/13', guarantees: [], payments: [], addendums: [], attachments: [] },
];

const initialPayments: Payment[] = [];
const initialGuarantees: Guarantee[] = [];
const initialAddendums: Addendum[] = [];
const initialAttachments: Attachment[] = [];
const initialNotifications: Notification[] = [
    { id: 1, type: 'request', title: 'درخواست جدید', description: 'درخواست "خرید مستقیم" با شماره SR-1768773879181 ثبت شد.', timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(), isRead: false, link: 'DASHBOARD' },
    { id: 2, type: 'contract', title: 'قرارداد تایید شد', description: 'قرارداد "هیدروفن کوانتومی" به وضعیت فعال تغییر یافت.', timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(), isRead: false, link: 'CONTRACTS' },
    { id: 3, type: 'system', title: 'بروزرسانی سیستم', description: 'سیستم به نسخه 2.1 بروزرسانی شد. ماژول کارسنجی اضافه گردید.', timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), isRead: false, link: 'WORK_MEASUREMENT' },
    { id: 4, type: 'request', title: 'درخواست رد شد', description: 'درخواست تنخواه با شماره SR-176121541238 رد شد.', timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), isRead: true },
    { id: 5, type: 'contract', title: 'قرارداد در انتظار', description: 'قرارداد "دستگاه فیلامنت" منتظر بررسی شماست.', timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), isRead: true },
];

const initialPayrolls: Payroll[] = [
    { id: 1, period: "خرداد 1403", employeeCount: 5, totalAmount: { rial: 980000000, usd: 0, eur: 0 }, status: PayrollStatus.Paid, paymentDate: "1403/04/05" },
    { id: 2, period: "تیر 1403", employeeCount: 5, totalAmount: { rial: 985000000, usd: 0, eur: 0 }, status: PayrollStatus.Draft, paymentDate: null },
];

const initialPayrollItems: PayrollItem[] = [
    // Payroll 1
    { id: 1, payrollId: 1, employeeId: 1, baseSalary: 180000000, overtime: 15000000, bonus: 5000000, deductions: 20000000, netPay: 180000000 },
    { id: 2, payrollId: 1, employeeId: 7, baseSalary: 250000000, overtime: 0, bonus: 10000000, deductions: 30000000, netPay: 230000000 },
    { id: 3, payrollId: 1, employeeId: 8, baseSalary: 180000000, overtime: 20000000, bonus: 0, deductions: 20000000, netPay: 180000000 },
    { id: 4, payrollId: 1, employeeId: 9, baseSalary: 180000000, overtime: 10000000, bonus: 0, deductions: 20000000, netPay: 170000000 },
    { id: 5, payrollId: 1, employeeId: 10, baseSalary: 200000000, overtime: 20000000, bonus: 20000000, deductions: 20000000, netPay: 220000000 },
    // Payroll 2
    { id: 6, payrollId: 2, employeeId: 1, baseSalary: 180000000, overtime: 18000000, bonus: 5000000, deductions: 20000000, netPay: 183000000 },
    { id: 7, payrollId: 2, employeeId: 7, baseSalary: 250000000, overtime: 0, bonus: 10000000, deductions: 30000000, netPay: 230000000 },
    { id: 8, payrollId: 2, employeeId: 8, baseSalary: 180000000, overtime: 22000000, bonus: 0, deductions: 20000000, netPay: 182000000 },
    { id: 9, payrollId: 2, employeeId: 9, baseSalary: 180000000, overtime: 10000000, bonus: 0, deductions: 20000000, netPay: 170000000 },
    { id: 10, payrollId: 2, employeeId: 10, baseSalary: 200000000, overtime: 20000000, bonus: 20000000, deductions: 20000000, netPay: 220000000 },
];

const initialInvoices: Invoice[] = [
    { id: 1, requestId: 'SR-1761155412530', invoiceNumber: 'F-9876', beneficiaryId: 2 },
    { id: 2, requestId: 'SR-1761155000398', invoiceNumber: 'F-9877', beneficiaryId: 2 },
    { id: 3, requestId: 'SR-1760960436510', invoiceNumber: 'F-9878', beneficiaryId: 2 },
    { id: 4, requestId: 'SR-1760927118147', invoiceNumber: 'F-1122', beneficiaryId: 3 },
    { id: 5, requestId: 'SR-1760751389869', invoiceNumber: 'F-3344', beneficiaryId: 11 },
];

const initialInvoiceItems: InvoiceItem[] = [
    { id: 1, invoiceId: 1, description: 'هارد دیسک SSD 1TB', quantity: 1, unitPrice: 200, costType: 'سرمایه‌ای' },
    { id: 2, invoiceId: 2, description: 'سرور HP Proliant DL380', quantity: 1, unitPrice: 2535, costType: 'سرمایه‌ای' },
    { id: 3, invoiceId: 3, description: 'سوییچ شبکه Cisco 24-port', quantity: 1, unitPrice: 25, costType: 'سرمایه‌ای' },
    { id: 4, invoiceId: 4, description: 'هزینه ایاب و ذهاب', quantity: 1, unitPrice: 232232232, costType: 'جاری' },
    { id: 5, invoiceId: 5, description: 'صندلی اداری', quantity: 10, unitPrice: 100000, costType: 'سرمایه‌ای' },
];


// --- Generic DB Handler ---
const initializeDb = <T>(key: string, initialData: T) => {
    if (!sessionStorage.getItem(key)) {
        sessionStorage.setItem(key, JSON.stringify(initialData));
    }
};

const getFromDb = <T>(key: string): T[] => {
    const data = sessionStorage.getItem(key);
    return data ? JSON.parse(data) : [];
};

const saveToDb = <T>(key: string, data: T[]) => {
    sessionStorage.setItem(key, JSON.stringify(data));
};

// --- Initialization Call ---
initializeDb(SYSTEM_USERS_STORAGE_KEY, initialSystemUsers);
initializeDb(BENEFICIARIES_STORAGE_KEY, initialBeneficiaries);
initializeDb(PETTY_CASH_HOLDERS_STORAGE_KEY, initialPettyCashHolders);
initializeDb(BANK_ACCOUNTS_STORAGE_KEY, initialBankAccounts);
initializeDb(ACCESS_LEVELS_STORAGE_KEY, initialAccessLevels);
initializeDb(PROJECTS_STORAGE_KEY, initialProjects);
initializeDb(FINANCIAL_RESOURCES_STORAGE_KEY, initialFinancialResources);
initializeDb(TASKS_STORAGE_KEY, initialTasks);
initializeDb(CONTRACTS_STORAGE_KEY, initialContracts);
initializeDb(PAYMENTS_STORAGE_KEY, initialPayments);
initializeDb(GUARANTEES_STORAGE_KEY, initialGuarantees);
initializeDb(ADDENDUMS_STORAGE_KEY, initialAddendums);
initializeDb(ATTACHMENTS_STORAGE_KEY, initialAttachments);
initializeDb(NOTIFICATIONS_STORAGE_KEY, initialNotifications);
initializeDb(PAYROLLS_STORAGE_KEY, initialPayrolls);
initializeDb(PAYROLL_ITEMS_STORAGE_KEY, initialPayrollItems);
initializeDb(INVOICES_STORAGE_KEY, initialInvoices);
initializeDb(INVOICE_ITEMS_STORAGE_KEY, initialInvoiceItems);


initializeDb(ROLES_STORAGE_KEY, initialRoles);
initializeDb(ORG_UNITS_STORAGE_KEY, initialOrgUnits);
initializeDb(REQUEST_TYPES_STORAGE_KEY, initialRequestTypes);
initializeDb(WORKFLOWS_STORAGE_KEY, initialWorkflows);
// FIX: Initialize requests in storage
initializeDb(REQUESTS_STORAGE_KEY, initialRequests);


// --- Exported DB Accessors ---
// FIX: Completed the db object to export all entity accessors, resolving multiple downstream errors.
export const db = {
    systemUsers: {
        get: () => getFromDb<SystemUser>(SYSTEM_USERS_STORAGE_KEY),
        set: (data: SystemUser[]) => saveToDb(SYSTEM_USERS_STORAGE_KEY, data),
    },
    beneficiaries: {
        get: () => getFromDb<Beneficiary>(BENEFICIARIES_STORAGE_KEY),
        set: (data: Beneficiary[]) => saveToDb(BENEFICIARIES_STORAGE_KEY, data),
    },
    pettyCashHolders: {
        get: () => getFromDb<PettyCashHolder>(PETTY_CASH_HOLDERS_STORAGE_KEY),
        set: (data: PettyCashHolder[]) => saveToDb(PETTY_CASH_HOLDERS_STORAGE_KEY, data),
    },
    bankAccounts: {
        get: () => getFromDb<BankAccount>(BANK_ACCOUNTS_STORAGE_KEY),
        set: (data: BankAccount[]) => saveToDb(BANK_ACCOUNTS_STORAGE_KEY, data),
    },
    accessLevels: {
        get: () => getFromDb<AccessLevel>(ACCESS_LEVELS_STORAGE_KEY),
        set: (data: AccessLevel[]) => saveToDb(ACCESS_LEVELS_STORAGE_KEY, data),
    },
    projects: {
        get: () => getFromDb<Project>(PROJECTS_STORAGE_KEY),
        set: (data: Project[]) => saveToDb(PROJECTS_STORAGE_KEY, data),
    },
    financialResources: {
        get: () => getFromDb<FinancialResource>(FINANCIAL_RESOURCES_STORAGE_KEY),
        set: (data: FinancialResource[]) => saveToDb(FINANCIAL_RESOURCES_STORAGE_KEY, data),
    },
    tasks: {
        get: () => getFromDb<Task>(TASKS_STORAGE_KEY),
        set: (data: Task[]) => saveToDb(TASKS_STORAGE_KEY, data),
    },
    contracts: {
        get: () => getFromDb<ContractDetails>(CONTRACTS_STORAGE_KEY),
        set: (data: ContractDetails[]) => saveToDb(CONTRACTS_STORAGE_KEY, data),
    },
    payments: {
        get: () => getFromDb<Payment>(PAYMENTS_STORAGE_KEY),
        set: (data: Payment[]) => saveToDb(PAYMENTS_STORAGE_KEY, data),
    },
    guarantees: {
        get: () => getFromDb<Guarantee>(GUARANTEES_STORAGE_KEY),
        set: (data: Guarantee[]) => saveToDb(GUARANTEES_STORAGE_KEY, data),
    },
    addendums: {
        get: () => getFromDb<Addendum>(ADDENDUMS_STORAGE_KEY),
        set: (data: Addendum[]) => saveToDb(ADDENDUMS_STORAGE_KEY, data),
    },
    attachments: {
        get: () => getFromDb<Attachment>(ATTACHMENTS_STORAGE_KEY),
        set: (data: Attachment[]) => saveToDb(ATTACHMENTS_STORAGE_KEY, data),
    },
    notifications: {
        get: () => getFromDb<Notification>(NOTIFICATIONS_STORAGE_KEY),
        set: (data: Notification[]) => saveToDb(NOTIFICATIONS_STORAGE_KEY, data),
    },
    payrolls: {
        get: () => getFromDb<Payroll>(PAYROLLS_STORAGE_KEY),
        set: (data: Payroll[]) => saveToDb(PAYROLLS_STORAGE_KEY, data),
    },
    payrollItems: {
        get: () => getFromDb<PayrollItem>(PAYROLL_ITEMS_STORAGE_KEY),
        set: (data: PayrollItem[]) => saveToDb(PAYROLL_ITEMS_STORAGE_KEY, data),
    },
    invoices: {
        get: () => getFromDb<Invoice>(INVOICES_STORAGE_KEY),
        set: (data: Invoice[]) => saveToDb(INVOICES_STORAGE_KEY, data),
    },
    invoiceItems: {
        get: () => getFromDb<InvoiceItem>(INVOICE_ITEMS_STORAGE_KEY),
        set: (data: InvoiceItem[]) => saveToDb(INVOICE_ITEMS_STORAGE_KEY, data),
    },
    roles: {
        get: () => getFromDb<Role>(ROLES_STORAGE_KEY),
        set: (data: Role[]) => saveToDb(ROLES_STORAGE_KEY, data),
    },
    orgUnits: {
        get: () => getFromDb<OrganizationalUnit>(ORG_UNITS_STORAGE_KEY),
        set: (data: OrganizationalUnit[]) => saveToDb(ORG_UNITS_STORAGE_KEY, data),
    },
    requestTypes: {
        get: () => getFromDb<RequestType>(REQUEST_TYPES_STORAGE_KEY),
        set: (data: RequestType[]) => saveToDb(REQUEST_TYPES_STORAGE_KEY, data),
    },
    workflows: {
        get: () => getFromDb<Workflow>(WORKFLOWS_STORAGE_KEY),
        set: (data: Workflow[]) => saveToDb(WORKFLOWS_STORAGE_KEY, data),
    },
    requests: {
        get: () => getFromDb<Request>(REQUESTS_STORAGE_KEY),
        set: (data: Request[]) => saveToDb(REQUESTS_STORAGE_KEY, data),
    }
};
