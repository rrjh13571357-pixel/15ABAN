
import type { Request } from '../shared/types';
import { db } from './db';

// Note: This data is not persisted in sessionStorage yet as there's no mutation logic.
export const getRequests = (): Request[] => {
    // FIX: Use persisted data from db instead of initial constant.
    return db.requests.get();
};