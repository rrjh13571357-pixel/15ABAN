const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// --- IN-MEMORY DATABASE (from backend/db.ts) ---
const RequestStatus = {
  InProgress: 'در حال بررسی',
  Pending: 'در انتظار تایید',
  Rejected: 'رد شده',
  Completed: 'تایید نهایی',
};
const ContractStatus = {
    Active: 'فعال',
    Pending: 'در دست بررسی',
    Archived: 'آرشیو شده',
};
const LetterStatus = {
    Read: 'خوانده شده',
    Unread: 'خوانده نشده',
};
const LetterPriority = {
    Normal: 'عادی',
    Confidential: 'محرمانه',
    Urgent: 'فوری',
};

let dbStore = {};

const initialData = {
    systemUsers: [
        {id: 1, fullName: 'علی احمدی', nationalCode: '1234567890', unitId: '2', roleId: 1, username: 'ali.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
        {id: 6, fullName: 'مدیر سیستم', nationalCode: '1010101010', unitId: '4', roleId: 4, username: 'admin', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: true },
        {id: 7, fullName: 'سارا احمدی', nationalCode: '111222333', unitId: '1', roleId: 2, username: 'sara.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
        {id: 8, fullName: 'علی رضایی', nationalCode: '444555666', unitId: '2', roleId: 1, username: 'ali.rezaei', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
        {id: 9, fullName: 'مریم حسینی', nationalCode: '777888999', unitId: '3', roleId: 1, username: 'maryam.hosseini', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
        {id: 10, fullName: 'رضا قاسمی', nationalCode: '121212121', unitId: '4', roleId: 1, username: 'reza.ghasemi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
        {id: 4, fullName: 'روح الله جهان پناه', nationalCode: '5566778899', unitId: '1', roleId: 1, username: 'roohollah.j', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
        {id: 5, fullName: 'محسن سعادتی', nationalCode: '0000000000', unitId: '2', roleId: 1, username: 'mohsen.s', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    ],
    beneficiaries: [
        {id: 2, fullName: 'شرکت داده‌پردازان نوین', nationalCode: '0987654321'},
        {id: 3, fullName: 'کیومرث حسن پور (پیمانکار)', nationalCode: '1122334455'},
        {id: 11, fullName: 'علی اصغری نژاد', nationalCode: '223344556'},
        {id: 12, fullName: 'آقای محمدی', nationalCode: '778899001'},
        {id: 13, fullName: 'هیدروفن کوانتومی', nationalCode: '555666777'},
    ],
    pettyCashHolders: [
        {id: 4, fullName: 'روح الله جهان پناه', nationalCode: '5566778899', associatedCenterId: '1', pettyCashLimit: 50000000},
        {id: 5, fullName: 'محسن سعادتی', nationalCode: '0000000000', associatedCenterId: '2', pettyCashLimit: 75000000},
    ],
    bankAccounts: [
        {id: 1, bankName: 'ملت', accountNumber: '123-456-789', iban: '210120000000001234567890', ownerId: 2, ownerType: 'beneficiary'},
        {id: 2, bankName: 'صادرات', accountNumber: '987-654-321', iban: '110190000000009876543210', ownerId: 4, ownerType: 'pettyCash'},
        {id: 3, bankName: 'ملی', accountNumber: '111-222-333', iban: '150170000000101112223330', ownerId: 3, ownerType: 'beneficiary'},
    ],
    roles: [
        { id: 1, title: 'کارمند', description: 'نقش پیش فرض برای کاربران', userCount: 1, status: 'فعال' },
        { id: 2, title: 'مدیر واحد', description: 'اداری', userCount: 0, status: 'فعال' },
        { id: 3, title: 'پیمانکار', description: '-', userCount: 0, status: 'فعال' },
        { id: 4, title: 'مدیر سیستم', description: 'این نقش بالاترین سطح دسترسی را در کل سیستم دارد.', userCount: 1, status: 'فعال' },
    ],
    accessLevels: [
        { id: 1, title: 'دسترسی کامل مدیریتی', description: 'دسترسی به تمام بخش‌های سیستم', roleIds: [4], permissions: ['dashboard:view', 'requests:create', 'requests:view:all', 'requests:delete', 'requests:approve', 'projects:view', 'projects:create', 'projects:edit', 'projects:delete', 'projects:manage_funds', 'contracts:view', 'contracts:create', 'contracts:edit', 'contracts:delete', 'contracts:manage_payments', 'payroll:view', 'payroll:create', 'payroll:finalize', 'reports:view:dashboard', 'reports:view:invoice_explorer', 'automation:view:inbox', 'automation:send', 'automation:manage_templates', 'baseinfo:manage:org_structure', 'baseinfo:manage:persons', 'baseinfo:manage:bank_accounts', 'baseinfo:manage:financial_resources', 'system:manage:users', 'system:manage:roles', 'system:manage:access_levels', 'system:manage:workflows', 'ai:use'] },
        { id: 2, title: 'دسترسی کارمندان مالی', description: 'دسترسی به ثبت و مشاهده درخواست‌ها', roleIds: [1, 2], permissions: ['dashboard:view', 'requests:create', 'requests:view:own', 'projects:view', 'contracts:view', 'payroll:view'] },
    ],
    financialResources: [
        { id: 1, name: 'منابع جاری' },
        { id: 2, name: 'منابع عمرانی' },
        { id: 3, name: 'سایر منابع' },
    ],
    projects: [
        { id: 1, name: 'پروژه آلفا', orgUnitId: '2', startDate: '1401/10/25', financialResourceId: 1, budget: { rial: 1000000000, usd: 5000, eur: 0 }, spentAmount: { rial: 450000000, usd: 1200, eur: 0 } },
        { id: 2, name: 'پروژه بتا', orgUnitId: '2', startDate: '1402/02/30', financialResourceId: 1, budget: { rial: 500000000, usd: 0, eur: 0 }, spentAmount: { rial: 100000000, usd: 0, eur: 0 } },
        { id: 3, name: 'پروژه گاما', orgUnitId: '3', startDate: '1401/08/10', financialResourceId: 2, budget: { rial: 2500000000, usd: 10000, eur: 15000 }, spentAmount: { rial: 2600000000, usd: 10500, eur: 14000 } },
        { id: 4, name: 'پروژه توسعه زیرساخت', orgUnitId: '4', startDate: '1402/10/11', financialResourceId: 2, budget: { rial: 5000000000, usd: 0, eur: 50000 }, spentAmount: { rial: 1200000000, usd: 0, eur: 10000 } },
    ],
    fundInjections: [],
    orgUnits: [
        { id: '1', title: 'مدیریت مالی', code: '100', managerId: 7, parent: null },
        { id: '2', title: 'حسابداری', code: '101', managerId: 8, parent: '1' },
        { id: '3', title: 'خزانه', code: '102', managerId: 9, parent: '1' },
        { id: '4', title: 'فناوری اطلاعات', code: '200', managerId: 6, parent: null },
    ],
    requests: [
      { id: 'SR-176121541238', subject: 'ارسال هزینه تنخواه', applicant: 'روح الله جهان پناه', amount: { rial: 200, usd: 0, eur: 0 }, date: '1403/04/30', deadline: null, status: RequestStatus.Rejected, originalApplicantId: 4, currentStepOwnerId: 4, lastModified: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), requestTypeId: 2, workflowId: 2 },
      { id: 'SR-176121588086', subject: 'ارسال هزینه تنخواه', applicant: 'روح الله جهان پناه', amount: { rial: 2028, usd: 0, eur: 0 }, date: '1403/04/30', deadline: null, status: RequestStatus.Pending, originalApplicantId: 4, currentStepOwnerId: 7, lastModified: new Date(Date.now() - 1000 * 60 * 10).toISOString(), requestTypeId: 2, workflowId: 2 },
      { id: 'SR-1768773879181', subject: 'خرید مستقیم', applicant: 'مدیر سیستم', amount: { rial: 82000, usd: 0, eur: 0 }, date: '1403/04/30', deadline: null, status: RequestStatus.InProgress, originalApplicantId: 6, currentStepOwnerId: 6, lastModified: new Date().toISOString(), requestTypeId: 3, workflowId: 3 },
      { id: 'SR-1761868196150', subject: 'تامین تنخواه گردان', applicant: 'محسن سعادتی', amount: { rial: 81222, usd: 0, eur: 0 }, date: '1403/04/27', deadline: null, status: RequestStatus.Completed, originalApplicantId: 5, currentStepOwnerId: 8, lastModified: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(), requestTypeId: 4, workflowId: 1 },
      { id: 'SR-176982711847', subject: 'خرید', applicant: 'مدیر سیستم', amount: { rial: 122222222, usd: 0, eur: 0 }, date: '1401/07/27', deadline: '1401/07/27', status: RequestStatus.InProgress, originalApplicantId: 6, currentStepOwnerId: 6, lastModified: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(), requestTypeId: 3, workflowId: 3 },
      { id: 'SR-1770000000001', subject: 'تامین پیش پرداخت قرارداد', applicant: 'مدیر سیستم', amount: { rial: 15300000, usd: 0, eur: 0 }, date: '1404/08/01', deadline: null, status: RequestStatus.Pending, projectId: 1, contractId: 1, originalApplicantId: 6, currentStepOwnerId: 7, lastModified: new Date(Date.now() - 1000 * 60 * 30).toISOString(), requestTypeId: 1, workflowId: 5 },
    ],
    requestTypes: [
        { id: 1, title: 'تامین پیش پرداخت قرارداد', deadline: null, attachedFileRequired: false, workflowId: 5 },
        { id: 2, title: 'ارسال هزینه تنخواه', deadline: null, attachedFileRequired: true, workflowId: 2 },
        { id: 3, title: 'خرید', deadline: 7, attachedFileRequired: true, workflowId: 3 },
        { id: 4, title: 'تامین تنخواه گردان', deadline: 10, attachedFileRequired: false, workflowId: 1 },
        { id: 5, title: 'دیون', deadline: null, attachedFileRequired: false, workflowId: 1 },
    ],
    workflows: [
        { id: 1, name: 'PettyCashWorkflow', steps: [{name: 'مرحله مدیریتی', responsible: 'مدیر واحد'}, {name: 'مرحله بعدی', responsible: 'حسابداری'}], icon: 'P', requirements: [] },
        { id: 2, name: 'ارسال هزینه تنخواه - گردش پیش فرض', steps: [{name: 'مرحله اولیه', responsible: 'درخواست کننده'}, {name: 'تایید مدیریتی', responsible: 'مدیر مافوق'}, {name: 'بررسی مدیر', responsible: 'مدیر واحد'}, {name: 'تصویب', responsible: 'مسئول واحد در عملیات'}], icon: 'A', requirements: [] },
        { id: 3, name: 'خرید مستقیم', steps: [{name: 'ثبت اولیه', responsible: 'مدیر سیستم'}, {name: 'تایید', responsible: 'مدیر'}, {name: 'بررسی', responsible: 'مدیر مالی'}, {name: 'تایید مدیر عامل', responsible: 'مدیر عامل'}], icon: 'K', requirements: [] },
        { id: 4, name: 'PettyCash WF', steps: [{name: 'Step 1', responsible: 'کاربر'}, {name: 'تایید', responsible: 'مسئول واحد'}, {name: 'تایید مدیر عامل', responsible: 'مدیر عامل'}], icon: 'P', requirements: [] },
        { id: 5, name: 'فرایند قرارداد خرید', steps: [{ name: 'ثبت اولیه', responsible: 'ALL_USERS' }, { name: 'بررسی درخواست', responsible: 'PERSON:7' }, { name: 'تایید نهایی', responsible: 'مدیر واحد' }], icon: 'B', requirements: ['ثبت درخواست تامین', 'پیش پرداخت قرارداد خرید'] }
    ],
    contracts: [
        { id: 1, contractNumber: '1403-04-0001', title: 'دستگاه فیلامنت کامپیوتری', party: 'هیدروفن کوانتومی', amount: 102000000, endDate: '1404/02/17', status: ContractStatus.Pending, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/02/17', guarantees: [], payments: [], addendums: [], attachments: [] },
        { id: 2, contractNumber: '1403-01-0001', title: 'هیدروفن کوانتومی', party: 'علی اصغری نژاد', amount: 60000000, endDate: '1404/01/10', status: ContractStatus.Pending, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/01/10', guarantees: [], payments: [], addendums: [], attachments: [] },
        { id: 3, contractNumber: '1403-05-0001', title: 'مشاوره و تحلیل سیستم', party: 'آقای محمدی', amount: null, endDate: '1404/11/13', status: ContractStatus.Active, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/11/13', guarantees: [], payments: [], addendums: [], attachments: [] },
    ],
    payments: [],
    guarantees: [],
    addendums: [],
    attachments: [],
    notifications: [
        { id: 1, type: 'request', title: 'درخواست جدید', description: 'درخواست "خرید مستقیم" با شماره SR-1768773879181 ثبت شد.', timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(), isRead: false, link: 'DASHBOARD' },
        { id: 2, type: 'contract', title: 'قرارداد تایید شد', description: 'قرارداد "هیدروفن کوانتومی" به وضعیت فعال تغییر یافت.', timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(), isRead: false, link: 'CONTRACTS' },
        { id: 3, type: 'system', title: 'بروزرسانی سیستم', description: 'سیستم به نسخه 2.1 بروزرسانی شد. ماژول کارسنجی اضافه گردید.', timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), isRead: false, link: 'WORK_MEASUREMENT' },
        { id: 4, type: 'request', title: 'درخواست رد شد', description: 'درخواست تنخواه با شماره SR-176121541238 رد شد.', timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), isRead: true },
        { id: 5, type: 'contract', title: 'قرارداد در انتظار', description: 'قرارداد "دستگاه فیلامنت" منتظر بررسی شماست.', timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), isRead: true },
        { id: 6, type: 'consultation', title: 'نظرخواهی جدید', description: 'آقای احمدی در مورد درخواست SR-1768773879181 از شما نظرخواهی کرده است.', timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(), isRead: false, link: 'DASHBOARD', requestId: 'SR-1768773879181' },
    ],
    invoices: [
        { id: 1, requestId: 'SR-176121541238', invoiceNumber: 'F-9876', beneficiaryId: 2 },
        { id: 2, requestId: 'SR-176121588086', invoiceNumber: 'F-9877', beneficiaryId: 2 },
        { id: 3, requestId: 'SR-1768773879181', invoiceNumber: 'F-9878', beneficiaryId: 2 },
        { id: 4, requestId: 'SR-1761868196150', invoiceNumber: 'F-1122', beneficiaryId: 3 },
        { id: 5, requestId: 'SR-176982711847', invoiceNumber: 'F-3344', beneficiaryId: 11 },
    ],
    invoiceItems: [
        { id: 1, invoiceId: 1, description: 'هارد دیسک SSD 1TB', quantity: 1, unitPrice: 200, costType: 'سرمایه‌ای' },
        { id: 2, invoiceId: 2, description: 'سرور HP Proliant DL380', quantity: 1, unitPrice: 2028, costType: 'سرمایه‌ای' },
        { id: 3, invoiceId: 3, description: 'سوییچ شبکه Cisco 24-port', quantity: 1, unitPrice: 82000, costType: 'سرمایه‌ای' },
        { id: 4, invoiceId: 4, description: 'هزینه ایاب و ذهاب', quantity: 1, unitPrice: 81222, costType: 'جاری' },
        { id: 5, invoiceId: 5, description: 'صندلی اداری', quantity: 10, unitPrice: 100000, costType: 'سرمایه‌ای' },
    ],
    letters: [
        { id: 1, subject: 'گزارش عملکرد ماهانه - تیر ۱۴۰۳', content: 'به پیوست گزارش عملکرد ماهانه واحد مالی جهت استحضار ارسال می‌گردد.', senderId: 7, recipientIds: [6], sentDate: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), priority: LetterPriority.Normal, status: { 6: LetterStatus.Unread }, letterDate: '1403/05/01', senderUnitId: '1', recipientUnitId: '4', signatoryId: 7, attachments: [ { id: 1, fileName: 'report.pdf', fileContent: 'dummy-base64-pdf', mimeType: 'application/pdf' } ] },
        { id: 2, subject: 'درخواست فوری: نیاز به مجوز خرید سرور', content: 'با توجه به مشکلات پیش آمده در سرور فعلی، خواهشمند است مجوز خرید یک دستگاه سرور جدید را صادر فرمایید.', senderId: 10, recipientIds: [6, 7], sentDate: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), priority: LetterPriority.Urgent, status: { 6: LetterStatus.Unread, 7: LetterStatus.Read }, letterDate: '1403/04/30', senderUnitId: '4', recipientUnitId: '1', signatoryId: 10, attachments: [] },
    ],
    letterTemplates: [
        { id: 1, name: 'نامه رسمی اداری', fileName: 'official-template.docx', templateBody: 'UEsDBBQAAAAIA...' },
        { id: 2, name: 'نامه درخواست مرخصی', fileName: 'leave-request.docx', templateBody: 'UEsDBBQAAAAIB...' },
    ],
    payrolls: [
        { id: 1, period: "خرداد 1403", employeeCount: 5, totalAmount: { rial: 980000000, usd: 0, eur: 0 }, status: 'پرداخت شده', paymentDate: "1403/04/05" },
        { id: 2, period: "تیر 1403", employeeCount: 5, totalAmount: { rial: 985000000, usd: 0, eur: 0 }, status: 'پیش‌نویس', paymentDate: null },
    ],
    payrollItems: [
        { id: 1, payrollId: 1, employeeId: 1, baseSalary: 180000000, overtime: 15000000, bonus: 5000000, deductions: 20000000, netPay: 180000000 },
        { id: 2, payrollId: 1, employeeId: 7, baseSalary: 250000000, overtime: 0, bonus: 10000000, deductions: 30000000, netPay: 230000000 },
        { id: 6, payrollId: 2, employeeId: 1, baseSalary: 180000000, overtime: 18000000, bonus: 5000000, deductions: 20000000, netPay: 183000000 },
    ],
    consultations: [],
    rejections: [
        { requestId: 'SR-176121541238', stepName: 'تایید اولیه', rejectedBy: 'سارا احمدی', reason: 'مبلغ تنخواه بیش از حد مجاز است.', date: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString() }
    ],
    requestCounters: {},
};

function initializeDb() {
    // Deep clone initial data to prevent mutations from affecting the source
    dbStore = JSON.parse(JSON.stringify(initialData));
    console.log('[Mock DB] In-memory store initialized.');
}

const db = {
    get: (key) => dbStore[key],
    set: (key, data) => { dbStore[key] = data; }
};

initializeDb();

// --- CONTROLLERS (from backend/controllers/*) ---
const asyncHandler = (fn) => (req, res) => {
    try {
        const result = fn(req, res);
        res.json(result);
    } catch (error) {
        console.error(`Error in ${req.method} ${req.path}:`, error);
        res.status(400).json({ message: error.message });
    }
};

const identityController = {
    login: (req, res) => {
        const { username, password } = req.body;
        const users = db.get('systemUsers');
        const user = users.find(u => u.username?.toLowerCase() === username.toLowerCase());

        if (!user || user.password !== password) {
            throw new Error('نام کاربری یا رمز عبور اشتباه است.');
        }
        if (user.status === 'inactive') {
            throw new Error('حساب کاربری شما غیرفعال است.');
        }
        const { password: _, ...userToReturn } = user;
        return { token: `mock-token-for-${user.id}`, user: userToReturn };
    },
    getSystemUsers: () => db.get('systemUsers'),
    getBeneficiaries: () => db.get('beneficiaries'),
    getPettyCashHolders: () => db.get('pettyCashHolders'),
    updateAllPettyCashLimits: (req) => {
        let holders = db.get('pettyCashHolders');
        holders = holders.map(h => ({ ...h, pettyCashLimit: req.body.limit }));
        db.set('pettyCashHolders', holders);
        return holders;
    },
    getRoles: () => db.get('roles'),
};

const organizationController = {
    getOrgUnits: () => db.get('orgUnits'),
    deleteOrgUnit: (req) => {
        const unitId = req.params.id;
        // Simplified dependency check
        if (db.get('systemUsers').some(u => u.unitId === unitId)) {
            throw new Error('Cannot delete unit: It has users assigned to it.');
        }
        let units = db.get('orgUnits');
        const updatedUnits = units.filter(u => u.id !== unitId);
        db.set('orgUnits', updatedUnits);
        return updatedUnits;
    },
     addOrgUnit: (req) => {
        const newUnit = { ...req.body, id: Date.now().toString() };
        const units = db.get('orgUnits');
        units.push(newUnit);
        db.set('orgUnits', units);
        return units;
    },
    updateOrgUnit: (req) => {
        const updatedUnit = { ...req.body, id: req.params.id };
        let units = db.get('orgUnits');
        const index = units.findIndex(u => u.id === updatedUnit.id);
        if (index > -1) units[index] = updatedUnit;
        db.set('orgUnits', units);
        return units;
    }
};

const requestController = {
    getRequests: () => db.get('requests'),
    getConsultations: () => db.get('consultations'),
    getRequestDetails: (req) => {
        const request = db.get('requests').find(r => r.id === req.params.id);
        if (!request) throw new Error('Request not found');
        // In a real app, this would involve more joins/queries. We mock it.
        const applicant = db.get('systemUsers').find(u => u.id === request.originalApplicantId);
        const requestingUnit = applicant ? db.get('orgUnits').find(ou => ou.id === applicant.unitId) : null;
        
        return {
            ...request,
            requestingUnit: requestingUnit?.title || 'نامشخص',
            creditSource: 'منابع جاری',
            invoices: db.get('invoices').filter(inv => inv.requestId === req.params.id).map(inv => ({
                ...inv,
                items: db.get('invoiceItems').filter(item => item.invoiceId === inv.id),
                beneficiaryName: db.get('beneficiaries').find(b => b.id === inv.beneficiaryId)?.fullName || ''
            })),
            workflow: { steps: [], currentActionBy: 'مسئول فعلی' },
            rejectionHistory: db.get('rejections').filter(r => r.requestId === req.params.id),
            consultations: db.get('consultations').filter(c => c.requestId === req.params.id),
        };
    },
    addRequest: (req, res) => {
        // Simplified version
        const { requestData } = req.body;
        const newId = `SR-${Date.now()}`;
        const newRequest = {
            ...requestData,
            id: newId,
            status: RequestStatus.Pending,
            date: new Date().toLocaleDateString('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' }),
            lastModified: new Date().toISOString(),
        };
        const requests = db.get('requests');
        requests.unshift(newRequest);
        db.set('requests', requests);
        return requests;
    },
    // Other request actions...
};

const contractController = {
    getContractList: () => db.get('contracts').map(c => ({ id: c.id, contractNumber: c.contractNumber, title: c.title, party: c.party, amount: c.amount, endDate: c.endDate, status: c.status })),
    getContractDetails: (req) => {
         const contract = db.get('contracts').find(c => c.id === Number(req.params.id));
         if (!contract) throw new Error('Contract not found');
         return {
            ...contract,
            payments: db.get('payments').filter(p => p.contractId === contract.id),
         };
    },
    addPayment: (req) => {
        const contractId = Number(req.params.id);
        const newPayment = { ...req.body, id: Date.now(), contractId };
        const payments = db.get('payments');
        payments.push(newPayment);
        db.set('payments', payments);
        return contractController.getContractDetails(req);
    },
    addContract: (req) => {
        const newContract = { ...req.body, id: Date.now(), contractNumber: `C-${Date.now()}`, status: ContractStatus.Pending, payments: [], guarantees: [], addendums: [], attachments: [] };
        const contracts = db.get('contracts');
        contracts.push(newContract);
        db.set('contracts', contracts);
        return contractController.getContractList();
    }
};

const payrollController = {
    getPayrolls: () => db.get('payrolls'),
    getPayrollDetails: (req) => {
        const payroll = db.get('payrolls').find(p => p.id === Number(req.params.id));
        if (!payroll) throw new Error('Payroll not found');
        return {
            ...payroll,
            items: db.get('payrollItems').filter(i => i.payrollId === payroll.id).map(item => {
                const emp = db.get('systemUsers').find(u => u.id === item.employeeId);
                return { ...item, employeeName: emp?.fullName || '', nationalCode: emp?.nationalCode || '' };
            })
        };
    }
};

const reportController = {
    getProjectFinancialSummary: () => {
        const projects = db.get('projects').slice(0, 5);
        return {
            labels: projects.map(p => p.name),
            datasets: [
                { label: 'بودجه کل', data: projects.map(p => p.budget.rial), backgroundColor: 'rgba(54, 162, 235, 0.6)'},
                { label: 'مبلغ هزینه شده', data: projects.map(p => p.spentAmount.rial), backgroundColor: 'rgba(255, 99, 132, 0.6)'}
            ]
        };
    },
    getStatusDistribution: () => {
        const distribution = db.get('contracts').reduce((acc, c) => {
            acc[c.status] = (acc[c.status] || 0) + 1;
            return acc;
        }, {});
        return {
            labels: Object.keys(distribution),
            datasets: [{ data: Object.values(distribution), backgroundColor: ['rgba(75, 192, 192, 0.6)', 'rgba(255, 206, 86, 0.6)', 'rgba(201, 203, 207, 0.6)'] }]
        };
    },
     getMonthlyRequestVolume: () => ({
        labels: ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور'],
        datasets: [{ label: 'تعداد درخواست‌ها', data: [12, 19, 3, 5, 2, 8], borderColor: 'rgba(255, 99, 132, 1)', tension: 0.1 }]
    }),
    searchInvoiceItems: (req) => {
        const filters = req.query;
        let results = db.get('invoiceItems').map(item => {
            const invoice = db.get('invoices').find(i => i.id === item.invoiceId);
            if (!invoice) return null;
            const request = db.get('requests').find(r => r.id === invoice.requestId);
            if (!request) return null;
            const beneficiary = db.get('beneficiaries').find(b => b.id === invoice.beneficiaryId);
            const applicant = db.get('systemUsers').find(u => u.id === request.originalApplicantId);
            const unit = applicant ? db.get('orgUnits').find(ou => ou.id === applicant.unitId) : null;
            const project = request.projectId ? db.get('projects').find(p => p.id === request.projectId) : null;

            return {
                id: item.id,
                description: item.description,
                quantity: item.quantity,
                unitPrice: item.unitPrice,
                totalPrice: item.quantity * item.unitPrice,
                beneficiaryName: beneficiary?.fullName || '---',
                requestingUnitName: unit?.title || '---',
                requestDate: request.date,
                requestNumber: request.id,
                projectName: project?.name || '---',
                requestStatus: request.status,
            };
        }).filter(Boolean);
        
        // Apply simple filters
        if (filters.description) results = results.filter(i => i.description.includes(filters.description));
        if (filters.requestStatus && filters.requestStatus !== 'all') results = results.filter(i => i.requestStatus === filters.requestStatus);

        return results;
    }
};

const otherControllers = {
    getBankAccounts: () => db.get('bankAccounts'),
    getAccessLevels: () => db.get('accessLevels'),
    getProjects: () => db.get('projects'),
    getFinancialResources: () => db.get('financialResources'),
    getTasks: () => db.get('tasks'),
    getRequestTypes: () => db.get('requestTypes'),
    getWorkflows: () => db.get('workflows'),
    getNotifications: () => db.get('notifications'),
    markNotificationAsRead: (req) => {
        const notifs = db.get('notifications');
        const notif = notifs.find(n => n.id === Number(req.params.id));
        if (notif) notif.isRead = true;
        db.set('notifications', notifs);
        return notifs;
    },
    markAllNotificationsAsRead: () => {
        const notifs = db.get('notifications').map(n => ({...n, isRead: true}));
        db.set('notifications', notifs);
        return notifs;
    },
};

// --- ROUTES ---
app.post('/api/login', asyncHandler(identityController.login));
app.get('/api/users', asyncHandler(identityController.getSystemUsers));
app.get('/api/beneficiaries', asyncHandler(identityController.getBeneficiaries));
app.get('/api/petty-cash-holders', asyncHandler(identityController.getPettyCashHolders));
app.post('/api/petty-cash-holders/set-global-limit', asyncHandler(identityController.updateAllPettyCashLimits));
app.get('/api/roles', asyncHandler(identityController.getRoles));
app.get('/api/org-units', asyncHandler(organizationController.getOrgUnits));
app.delete('/api/org-units/:id', asyncHandler(organizationController.deleteOrgUnit));
app.post('/api/org-units', asyncHandler(organizationController.addOrgUnit));
app.put('/api/org-units/:id', asyncHandler(organizationController.updateOrgUnit));
app.get('/api/requests', asyncHandler(requestController.getRequests));
app.get('/api/requests/:id', asyncHandler(requestController.getRequestDetails));
app.post('/api/requests', asyncHandler(requestController.addRequest));
app.get('/api/consultations', asyncHandler(requestController.getConsultations));
app.get('/api/contracts', asyncHandler(contractController.getContractList));
app.get('/api/contracts/:id', asyncHandler(contractController.getContractDetails));
app.post('/api/contracts/:id/payments', asyncHandler(contractController.addPayment));
app.post('/api/contracts', asyncHandler(contractController.addContract));
app.get('/api/payrolls', asyncHandler(payrollController.getPayrolls));
app.get('/api/payrolls/:id', asyncHandler(payrollController.getPayrollDetails));
app.get('/api/reports/project-financial-summary', asyncHandler(reportController.getProjectFinancialSummary));
app.get('/api/reports/status-distribution', asyncHandler(reportController.getStatusDistribution));
app.get('/api/reports/monthly-request-volume', asyncHandler(reportController.getMonthlyRequestVolume));
app.get('/api/invoice-items/search', asyncHandler(reportController.searchInvoiceItems));
app.get('/api/bank-accounts', asyncHandler(otherControllers.getBankAccounts));
app.get('/api/access-levels', asyncHandler(otherControllers.getAccessLevels));
app.get('/api/projects', asyncHandler(otherControllers.getProjects));
app.get('/api/financial-resources', asyncHandler(otherControllers.getFinancialResources));
app.get('/api/tasks', asyncHandler(otherControllers.getTasks));
app.get('/api/request-types', asyncHandler(otherControllers.getRequestTypes));
app.get('/api/workflows', asyncHandler(otherControllers.getWorkflows));
app.get('/api/notifications', asyncHandler(otherControllers.getNotifications));
app.post('/api/notifications/:id/read', asyncHandler(otherControllers.markNotificationAsRead));
app.post('/api/notifications/read-all', asyncHandler(otherControllers.markAllNotificationsAsRead));

// --- CATCH-ALL for un-implemented POST/PUT/DELETE ---
app.post('/api/*', (req, res) => res.status(201).json({ message: 'Created (mock)'}));
app.put('/api/*', (req, res) => res.json({ message: 'Updated (mock)'}));
app.delete('/api/*', (req, res) => res.json({ message: 'Deleted (mock)'}));


app.listen(PORT, () => {
    console.log(`✅ Mock server is running on http://localhost:${PORT}`);
});
