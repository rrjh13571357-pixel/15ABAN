const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://postgres:admin@localhost:5432/tamin_db',
});

module.exports = {
    query: (text, params) => pool.query(text, params),
    pool,
};