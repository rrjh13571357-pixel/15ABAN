const { pool } = require('./index');

const initialOrgUnits = [
    { id: '1', title: 'مدیریت مالی', code: '100', managerId: 7, parent: null },
    { id: '2', title: 'حسابداری', code: '101', managerId: 8, parent: '1' },
    { id: '3', title: 'خزانه', code: '102', managerId: 9, parent: '1' },
    { id: '4', title: 'فناوری اطلاعات', code: '200', managerId: 6, parent: null },
];

const initialBeneficiaries = [
    {id: 2, fullName: 'شرکت داده‌پردازان نوین', nationalCode: '0987654321'},
    {id: 3, fullName: 'کیومرث حسن پور (پیمانکار)', nationalCode: '1122334455'},
];

const initialPettyCashHolders = [
    {id: 4, fullName: 'روح الله جهان پناه', nationalCode: '5566778899', associatedCenterId: '1', pettyCashLimit: 50000000},
    {id: 5, fullName: 'محسن سعادتی', nationalCode: '0000000000', associatedCenterId: '2', pettyCashLimit: 75000000},
];

const initialBankAccounts = [
    {id: 1, bankName: 'ملت', accountNumber: '123-456-789', iban: 'IR210120000000001234567890', ownerId: 2, ownerType: 'beneficiary'},
    {id: 2, bankName: 'صادرات', accountNumber: '987-654-321', iban: 'IR110190000000009876543210', ownerId: 4, ownerType: 'pettyCash'},
];

const initialFinancialResources = [
    { id: 1, name: 'منابع جاری' },
    { id: 2, name: 'منابع عمرانی' },
];

const initialRequestTypes = [
    { id: 1, title: 'تامین پیش پرداخت قرارداد', deadline: null, attachedFileRequired: false, workflowId: 5 },
    { id: 2, title: 'ارسال هزینه تنخواه', deadline: null, attachedFileRequired: true, workflowId: 2 },
];

const initialRoles = [
    { id: 1, title: 'کارمند', description: 'نقش پیش فرض برای کاربران', userCount: 1, status: 'فعال' },
    { id: 2, title: 'مدیر واحد', description: 'اداری', userCount: 0, status: 'فعال' },
];

async function executeDDL() {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        await client.query(`
            CREATE TABLE IF NOT EXISTS org_units (
                id TEXT PRIMARY KEY, title TEXT NOT NULL, code TEXT, manager_id INTEGER, parent TEXT
            );
            CREATE TABLE IF NOT EXISTS beneficiaries (
                id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, national_code TEXT
            );
            CREATE TABLE IF NOT EXISTS petty_cash_holders (
                id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, national_code TEXT, associated_center_id TEXT, petty_cash_limit NUMERIC
            );
            CREATE TABLE IF NOT EXISTS bank_accounts (
                id INTEGER PRIMARY KEY, bank_name TEXT, account_number TEXT, iban TEXT, owner_id INTEGER, owner_type TEXT
            );
            CREATE TABLE IF NOT EXISTS financial_resources (
                id INTEGER PRIMARY KEY, name TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS request_types (
                id INTEGER PRIMARY KEY, title TEXT NOT NULL, deadline INTEGER, attached_file_required BOOLEAN, workflow_id INTEGER
            );
            CREATE TABLE IF NOT EXISTS roles (
                id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT, user_count INTEGER, status TEXT
            );
        `);
        
        await client.query('COMMIT');
    } catch (e) {
        await client.query('ROLLBACK');
        throw e;
    } finally {
        client.release();
    }
}

async function seedData() {
     const client = await pool.connect();
    try {
        // Simple seeding logic: check count for one table.
        const { rows } = await client.query('SELECT COUNT(*) FROM org_units');
        if (rows[0].count > 0) return; // Data already exists

        console.log('[BaseInfo Service] Seeding initial data...');
        for(const u of initialOrgUnits) await client.query('INSERT INTO org_units VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING', [u.id, u.title, u.code, u.managerId, u.parent]);
        for(const b of initialBeneficiaries) await client.query('INSERT INTO beneficiaries VALUES ($1, $2, $3) ON CONFLICT DO NOTHING', [b.id, b.fullName, b.nationalCode]);
        for(const p of initialPettyCashHolders) await client.query('INSERT INTO petty_cash_holders VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING', [p.id, p.fullName, p.nationalCode, p.associatedCenterId, p.pettyCashLimit]);
        for(const ba of initialBankAccounts) await client.query('INSERT INTO bank_accounts VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT DO NOTHING', [ba.id, ba.bankName, ba.accountNumber, ba.iban, ba.ownerId, ba.ownerType]);
        for(const fr of initialFinancialResources) await client.query('INSERT INTO financial_resources VALUES ($1, $2) ON CONFLICT DO NOTHING', [fr.id, fr.name]);
        for(const rt of initialRequestTypes) await client.query('INSERT INTO request_types VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING', [rt.id, rt.title, rt.deadline, rt.attachedFileRequired, rt.workflowId]);
        for(const r of initialRoles) await client.query('INSERT INTO roles VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING', [r.id, r.title, r.description, r.userCount, r.status]);

    } finally {
        client.release();
    }
}


async function initializeDb() {
    try {
        await executeDDL();
        await seedData();
        console.log("✅ [BaseInfo Service] PostgreSQL database is ready.");
    } catch (err) {
        console.error("❌ [BaseInfo Service] Error initializing database:", err);
        throw err;
    }
}

module.exports = { initializeDb };