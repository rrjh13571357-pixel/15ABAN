const asyncHandler = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(error => {
        console.error(`[BaseInfo Service] Error:`, error);
        res.status(400).json({ message: error.message || 'An unexpected error occurred.' });
    });
};

module.exports = asyncHandler;
