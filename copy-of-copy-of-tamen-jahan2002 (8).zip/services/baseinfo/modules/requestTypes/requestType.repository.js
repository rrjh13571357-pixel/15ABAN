const db = require('../../db');

const findAll = async () => {
    const { rows } = await db.query('SELECT id, title, deadline, attached_file_required as "attachedFileRequired", workflow_id as "workflowId" FROM request_types ORDER BY title');
    return rows;
};

module.exports = { findAll };
