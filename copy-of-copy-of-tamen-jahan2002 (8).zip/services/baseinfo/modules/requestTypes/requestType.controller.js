const service = require('./requestType.service');
const asyncHandler = require('../../utils/asyncHandler');

const getRequestTypes = asyncHandler(async (req, res) => {
    const data = await service.getAll();
    res.json(data);
});

module.exports = { getRequestTypes };
