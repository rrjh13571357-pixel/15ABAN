const service = require('./persons.service');
const asyncHandler = require('../../utils/asyncHandler');

const getBeneficiaries = asyncHandler(async (req, res) => {
    const data = await service.getAllBeneficiaries();
    res.json(data);
});

const getPettyCashHolders = asyncHandler(async (req, res) => {
    const data = await service.getAllPettyCashHolders();
    res.json(data);
});

const updateAllPettyCashLimits = asyncHandler(async (req, res) => {
    const data = await service.updateAllPettyCashLimits(req.body.limit);
    res.json(data);
});


module.exports = {
    getBeneficiaries,
    getPettyCashHolders,
    updateAllPettyCashLimits
};
