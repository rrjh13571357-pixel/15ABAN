const service = require('./role.service');
const asyncHandler = require('../../utils/asyncHandler');

const getRoles = asyncHandler(async (req, res) => {
    const data = await service.getAll();
    res.json(data);
});

module.exports = { getRoles };
