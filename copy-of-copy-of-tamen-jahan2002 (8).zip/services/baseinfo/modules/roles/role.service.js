const repository = require('./role.repository');

const getAll = () => repository.findAll();

module.exports = { getAll };
