const express = require('express');
const router = express.Router();
const controller = require('./organization.controller');

router.get('/org-units', controller.getOrgUnits);
router.post('/org-units', controller.addOrgUnit);
router.put('/org-units/:id', controller.updateOrgUnit);
router.delete('/org-units/:id', controller.deleteOrgUnit);

module.exports = router;
