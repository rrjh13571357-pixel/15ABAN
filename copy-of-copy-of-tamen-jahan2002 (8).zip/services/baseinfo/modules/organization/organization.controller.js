const service = require('./organization.service');
const asyncHandler = require('../../utils/asyncHandler');

const getOrgUnits = asyncHandler(async (req, res) => {
    const data = await service.getAll();
    res.json(data);
});

const addOrgUnit = asyncHandler(async (req, res) => {
    const data = await service.create(req.body);
    res.status(201).json(data);
});

const updateOrgUnit = asyncHandler(async (req, res) => {
    const data = await service.update(req.params.id, req.body);
    res.json(data);
});

const deleteOrgUnit = asyncHandler(async (req, res) => {
    const data = await service.remove(req.params.id);
    res.json(data);
});

module.exports = {
    getOrgUnits,
    addOrgUnit,
    updateOrgUnit,
    deleteOrgUnit
};
