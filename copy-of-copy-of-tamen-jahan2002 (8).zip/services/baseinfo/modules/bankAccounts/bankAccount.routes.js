const express = require('express');
const router = express.Router();
const controller = require('./bankAccount.controller');

router.get('/bank-accounts', controller.getBankAccounts);

module.exports = router;
