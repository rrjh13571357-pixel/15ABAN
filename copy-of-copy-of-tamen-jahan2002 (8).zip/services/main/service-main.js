const express = require("express");
const dotenv = require("dotenv");
const cors = require('cors');
const { Pool } = require("pg");

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3002;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const initializeDb = async () => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        // This service is now responsible for a smaller set of tables.
        // The tables for org_units, beneficiaries, etc., are now in service-baseinfo.
        await client.query(`
            CREATE TABLE IF NOT EXISTS tasks (
                id BIGINT PRIMARY KEY,
                title TEXT,
                responsible TEXT,
                status TEXT,
                progress INTEGER,
                last_update TEXT,
                deadline TEXT
            );
        `);
        // Add more table creations for payroll, reports, automation...
        
        await client.query('COMMIT');
        console.log("✅ [Main Service] PostgreSQL database is ready.");
    } catch (err) {
        await client.query('ROLLBACK');
        console.error("❌ [Main Service] Error initializing database:", err);
        process.exit(1);
    } finally {
        client.release();
    }
};
initializeDb();

const asyncHandler = (fn) => async (req, res, next) => {
    try { await fn(req, res, next); } catch (error) {
        console.error(`[Main Service] Error:`, error);
        res.status(400).json({ message: error.message });
    }
};

// --- API Routes for Main Service ---
// This service provides the API for all modules NOT yet extracted to their own service.
// Endpoints for org-units, beneficiaries, petty-cash, roles, etc., have been removed.

const getPayrolls = async (req, res) => {
    // const { rows } = await pool.query('SELECT * FROM payrolls');
    res.json([]); // Placeholder
};
app.get('/api/payrolls', asyncHandler(getPayrolls));
// Add other endpoints for main service here... (e.g., reports, automation, etc.)

app.get("/health", (req, res) => res.json({ status: "ok" }));

app.listen(PORT, () => {
  console.log(`📦 Main Service (remaining modules) running on http://localhost:${PORT}`);
});