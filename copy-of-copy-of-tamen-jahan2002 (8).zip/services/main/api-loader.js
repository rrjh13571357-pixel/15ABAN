// This file dynamically creates a mock 'require' for the virtual backend,
// as it's not a real module but a collection of TypeScript files. This allows
// the CommonJS services to use the existing in-memory database logic.
const path = require('path');
const fs = require('fs');

// A simple in-memory cache for loaded controllers
const controllerCache = {};

function loadController(name) {
    if (controllerCache[name]) {
        return controllerCache[name];
    }
    // This is a simplified "loader". In a real scenario, you'd transpile TS.
    // Here we just read the file content. Since it's mock data, we can get away with it.
    // We point to the db, which is central.
    if (name === './db') {
        const dbPath = path.join(__dirname, 'db.ts');
        if (fs.existsSync(dbPath)) {
           // This is a mock; we just need it to not crash. The db is already initialized in memory.
           return require(dbPath.replace('.ts', '.js')); 
        }
    }
    const controllerPath = path.join(__dirname, 'controllers', `${name}.ts`);
     if (fs.existsSync(controllerPath)) {
        // Mocking the require for TS files.
        // This is highly simplified and depends on the specific structure of the controller files.
        const moduleContent = fs.readFileSync(controllerPath, 'utf8');
        const exports = {};
        // This is a very brittle way to parse exports, but works for the current file structures.
        const exportRegex = /export const (\w+)/g;
        let match;
        while ((match = exportRegex.exec(moduleContent)) !== null) {
            exports[match[1]] = () => { /* mock function */ };
        }
        controllerCache[name] = exports;
        return exports;
    }
    return {};
}

const createApiController = (controller) => {
    return Object.keys(controller).reduce((acc, key) => {
        acc[key] = (...args) => {
            try {
                const result = controller[key](...args);
                return Promise.resolve(result); // Simulate async for consistency
            } catch (error) => {
                return Promise.reject(error);
            }
        };
        return acc;
    }, {});
};


const identityController = require('./controllers/identityController.ts');
const organizationController = require('./controllers/organizationController.ts');
const requestController = require('./controllers/requestController.ts');
const workflowController = require('./controllers/workflowController.ts');
const bankAccountController = require('./controllers/bankAccountController.ts');
const accessController = require('./controllers/accessController.ts');
const projectController = require('./controllers/projectController.ts');
const financialResourceController = require('./controllers/financialResourceController.ts');
const workMeasurementController = require('./controllers/workMeasurementController.ts');
const contractController = require('./controllers/contractController.ts');
const analysisController = require('./controllers/analysisController.ts');
const notificationController = require('./controllers/notificationController.ts');
const payrollController = require('./controllers/payrollController.ts');
const reportController = require('./controllers/reportController.ts');
const automationController = require('./controllers/automationController.ts');


exports.virtualApi = {
    identity: createApiController(identityController),
    organization: createApiController(organizationController),
    request: createApiController(requestController),
    workflow: createApiController(workflowController),
    bankAccount: createApiController(bankAccountController),
    access: createApiController(accessController),
    project: createApiController(projectController),
    financialResource: createApiController(financialResourceController),
    workMeasurement: createApiController(workMeasurementController),
    contract: createApiController(contractController),
    analysis: createApiController(analysisController),
    notification: createApiController(notificationController),
    payroll: createApiController(payrollController),
    report: createApiController(reportController),
    automation: createApiController(automationController),
};
