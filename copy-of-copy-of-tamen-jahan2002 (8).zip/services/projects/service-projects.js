const express = require("express");
const dotenv = require("dotenv");
const cors = require('cors');
const { Pool } = require("pg");

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3003;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const initialProjects = [
    { id: 1, name: 'پروژه آلفا', orgUnitId: '2', startDate: '1401/10/25', financialResourceId: 1, budget: { rial: 1000000000, usd: 5000, eur: 0 }, spentAmount: { rial: 450000000, usd: 1200, eur: 0 } },
    { id: 2, name: 'پروژه بتا', orgUnitId: '2', startDate: '1402/02/30', financialResourceId: 1, budget: { rial: 500000000, usd: 0, eur: 0 }, spentAmount: { rial: 100000000, usd: 0, eur: 0 } },
    { id: 3, name: 'پروژه گاما', orgUnitId: '3', startDate: '1401/08/10', financialResourceId: 2, budget: { rial: 2500000000, usd: 10000, eur: 15000 }, spentAmount: { rial: 2600000000, usd: 10500, eur: 14000 } },
    { id: 4, name: 'پروژه توسعه زیرساخت', orgUnitId: '4', startDate: '1402/10/11', financialResourceId: 2, budget: { rial: 5000000000, usd: 0, eur: 50000 }, spentAmount: { rial: 1200000000, usd: 0, eur: 10000 } },
];

const initializeDb = async () => {
    const client = await pool.connect();
    try {
        await client.query(`
            CREATE TABLE IF NOT EXISTS projects (
                id BIGINT PRIMARY KEY,
                name TEXT NOT NULL,
                org_unit_id TEXT,
                start_date TEXT,
                financial_resource_id INTEGER,
                budget JSONB,
                spent_amount JSONB
            );
        `);
        
        const { rows } = await client.query('SELECT COUNT(*) FROM projects');
        if (rows[0].count === '0') {
            console.log('[Projects Service] Seeding initial project data...');
            for (const p of initialProjects) {
                await client.query(
                    `INSERT INTO projects (id, name, org_unit_id, start_date, financial_resource_id, budget, spent_amount)
                     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
                    [p.id, p.name, p.orgUnitId, p.startDate, p.financialResourceId, p.budget, p.spentAmount]
                );
            }
        }
        console.log("✅ [Projects Service] PostgreSQL database is ready.");
    } catch (err) {
        console.error("❌ [Projects Service] Error initializing database:", err);
        process.exit(1);
    } finally {
        client.release();
    }
};

initializeDb();

const asyncHandler = (fn) => async (req, res, next) => {
    try {
        await fn(req, res, next);
    } catch (error) {
        console.error(`[Projects Service] Error:`, error);
        res.status(400).json({ message: error.message });
    }
};

// --- Controller Logic ---
const getProjects = async (req, res) => {
    const { rows } = await pool.query('SELECT id, name, org_unit_id AS "orgUnitId", start_date AS "startDate", financial_resource_id AS "financialResourceId", budget, spent_amount AS "spentAmount" FROM projects ORDER BY id DESC');
    res.json(rows);
};

const addProject = async (req, res) => {
    const p = req.body;
    const newId = Date.now();
    await pool.query(
        `INSERT INTO projects (id, name, org_unit_id, start_date, financial_resource_id, budget, spent_amount)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [newId, p.name, p.orgUnitId, p.startDate, p.financialResourceId, p.budget, { rial: 0, usd: 0, eur: 0 }]
    );
    const { rows } = await pool.query('SELECT * FROM projects ORDER BY id DESC');
    res.status(201).json(rows);
};

const updateProject = async (req, res) => {
    const { id } = req.params;
    const p = req.body;
    await pool.query(
        `UPDATE projects SET name = $1, org_unit_id = $2, start_date = $3, financial_resource_id = $4, budget = $5 WHERE id = $6`,
        [p.name, p.orgUnitId, p.startDate, p.financialResourceId, p.budget, id]
    );
    const { rows } = await pool.query('SELECT * FROM projects ORDER BY id DESC');
    res.json(rows);
};

const deleteProject = async (req, res) => {
    const { id } = req.params;
    // In a real microservice, we would need to call the requests service to check for dependencies.
    // We skip this check for now.
    await pool.query('DELETE FROM projects WHERE id = $1', [id]);
    const { rows } = await pool.query('SELECT * FROM projects ORDER BY id DESC');
    res.json(rows);
};

// --- API Endpoints ---
app.get("/api/projects", asyncHandler(getProjects));
app.post("/api/projects", asyncHandler(addProject));
app.put("/api/projects/:id", asyncHandler(updateProject));
app.delete("/api/projects/:id", asyncHandler(deleteProject));

app.get("/health", (req, res) => res.json({ status: "ok" }));

app.listen(PORT, () => console.log(`🏗️  Projects service running on http://localhost:${PORT}`));
