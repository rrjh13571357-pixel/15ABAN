const express = require("express");
const pg = require("pg");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const cors = require('cors');

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const JWT_SECRET = process.env.JWT_SECRET || "secret-key";

const initialSystemUsers = [
    {id: 1, fullName: 'علی احمدی', nationalCode: '1234567890', unitId: '2', roleId: 1, username: 'ali.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 6, fullName: 'مدیر سیستم', nationalCode: '1010101010', unitId: '4', roleId: 4, username: 'admin', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: true },
    {id: 7, fullName: 'سارا احمدی', nationalCode: '111222333', unitId: '1', roleId: 2, username: 'sara.ahmadi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 8, fullName: 'علی رضایی', nationalCode: '444555666', unitId: '2', roleId: 1, username: 'ali.rezaei', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 9, fullName: 'مریم حسینی', nationalCode: '777888999', unitId: '3', roleId: 1, username: 'maryam.hosseini', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 10, fullName: 'رضا قاسمی', nationalCode: '121212121', unitId: '4', roleId: 1, username: 'reza.ghasemi', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 4, fullName: 'روح الله جهان پناه', nationalCode: '5566778899', unitId: '1', roleId: 1, username: 'roohollah.j', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
    {id: 5, fullName: 'محسن سعادتی', nationalCode: '0000000000', unitId: '2', roleId: 1, username: 'mohsen.s', password: 'password', status: 'active', forcePasswordChange: false, passwordNeverExpires: false },
];

const initializeDb = async () => {
    const client = await pool.connect();
    try {
        await client.query(`
          CREATE TABLE IF NOT EXISTS system_users (
            id INTEGER PRIMARY KEY,
            full_name TEXT NOT NULL,
            national_code TEXT,
            unit_id TEXT,
            role_id INTEGER,
            username TEXT UNIQUE,
            password TEXT,
            status TEXT DEFAULT 'active',
            force_password_change BOOLEAN DEFAULT false,
            password_never_expires BOOLEAN DEFAULT false,
            description TEXT
          )
        `);

        const { rows } = await client.query('SELECT COUNT(*) FROM system_users');
        if (rows[0].count === '0') {
            console.log('[Users Service] Seeding initial user data...');
            const saltRounds = 10;
            for (const user of initialSystemUsers) {
                const hash = user.password ? await bcrypt.hash(user.password, saltRounds) : null;
                await client.query(
                    `INSERT INTO system_users (id, full_name, national_code, unit_id, role_id, username, password, status, force_password_change, password_never_expires) 
                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) ON CONFLICT (id) DO NOTHING`,
                    [user.id, user.fullName, user.nationalCode, user.unitId, user.roleId, user.username, hash, user.status, user.forcePasswordChange, user.passwordNeverExpires]
                );
            }
        }
        console.log("✅ [Users Service] PostgreSQL user database is ready.");
    } catch (err) {
        console.error("❌ [Users Service] Error initializing database:", err);
        process.exit(1);
    } finally {
        client.release();
    }
};
initializeDb();


// --- Controller Logic ---
const asyncHandler = (fn) => async (req, res, next) => {
    try {
        await fn(req, res, next);
    } catch (error) {
        console.error(`[Users Service] Error:`, error);
        res.status(400).json({ message: error.message });
    }
};

const login = async (req, res) => {
  const { username, password } = req.body;
  const result = await pool.query("SELECT * FROM system_users WHERE username=$1", [username]);
  const user = result.rows[0];
  if (!user) return res.status(401).json({ message: "نام کاربری یا رمز عبور اشتباه است." });
  if (user.status !== 'active') return res.status(403).json({ message: "حساب کاربری شما غیرفعال است." });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ message: "نام کاربری یا رمز عبور اشتباه است." });

  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "8h" });
  const { password: _, ...userToReturn } = user;
  res.json({ token, user: userToReturn });
};

const getSystemUsers = async (req, res) => {
    const { rows } = await pool.query('SELECT id, full_name AS "fullName", national_code AS "nationalCode", unit_id AS "unitId", role_id AS "roleId", username, status, force_password_change AS "forcePasswordChange", password_never_expires AS "passwordNeverExpires", description FROM system_users ORDER BY id');
    res.json(rows);
};

const addSystemUser = async (req, res) => {
    const { fullName, nationalCode, unitId, roleId, description } = req.body;
    const { rows } = await pool.query(
        'INSERT INTO system_users (id, full_name, national_code, unit_id, role_id, description, status, force_password_change) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
        [Date.now(), fullName, nationalCode, unitId, roleId, description, 'active', true]
    );
    res.status(201).json(rows);
};

const updateSystemUser = async (req, res) => {
    const { id } = req.params;
    const { fullName, nationalCode, unitId, roleId, description, status } = req.body;
    const { rows } = await pool.query(
        'UPDATE system_users SET full_name = $1, national_code = $2, unit_id = $3, role_id = $4, description = $5, status = $6 WHERE id = $7 RETURNING *',
        [fullName, nationalCode, unitId, roleId, description, status, id]
    );
    res.json(rows);
};

const deleteSystemUser = async (req, res) => {
    const { id } = req.params;
    // Soft delete
    const { rows } = await pool.query(
        "UPDATE system_users SET status = 'inactive', username = null WHERE id = $1 RETURNING *",
        [id]
    );
    res.json(rows);
};

// --- Routes ---
app.post("/api/login", asyncHandler(login));
app.get("/api/users", asyncHandler(getSystemUsers));
app.post("/api/users", asyncHandler(addSystemUser));
app.put("/api/users/:id", asyncHandler(updateSystemUser));
app.delete("/api/users/:id", asyncHandler(deleteSystemUser));

app.get("/health", (req, res) => res.json({ status: "ok" }));

app.listen(process.env.PORT || 3001, () => console.log(`👤 Users service running on port ${process.env.PORT || 3001}`));
