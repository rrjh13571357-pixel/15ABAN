const express = require("express");
const dotenv = require("dotenv");
const cors = require('cors');
const { Pool } = require("pg");

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3005;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const RequestStatus = {
  InProgress: 'در حال بررسی',
  Pending: 'در انتظار تایید',
  Rejected: 'رد شده',
  Completed: 'تایید نهایی',
};

const initialRequests = [
  { id: 'SR-176121541238', subject: 'ارسال هزینه تنخواه', applicant: 'روح الله جهان پناه', amount: { rial: 200, usd: 0, eur: 0 }, date: '1403/04/30', deadline: null, status: RequestStatus.Rejected, originalApplicantId: 4, currentStepOwnerId: 4, lastModified: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), requestTypeId: 2, workflowId: 2 },
  { id: 'SR-176121588086', subject: 'ارسال هزینه تنخواه', applicant: 'روح الله جهان پناه', amount: { rial: 2028, usd: 0, eur: 0 }, date: '1403/04/30', deadline: null, status: RequestStatus.Pending, originalApplicantId: 4, currentStepOwnerId: 7, lastModified: new Date(Date.now() - 1000 * 60 * 10).toISOString(), requestTypeId: 2, workflowId: 2 },
];
const initialInvoices = [
    { id: 1, requestId: 'SR-176121541238', invoiceNumber: 'F-9876', beneficiaryId: 2 },
    { id: 2, requestId: 'SR-176121588086', invoiceNumber: 'F-9877', beneficiaryId: 2 },
];
const initialInvoiceItems = [
    { id: 1, invoiceId: 1, description: 'هارد دیسک SSD 1TB', quantity: 1, unitPrice: 200, costType: 'سرمایه‌ای' },
    { id: 2, invoiceId: 2, description: 'سرور HP Proliant DL380', quantity: 1, unitPrice: 2028, costType: 'سرمایه‌ای' },
];

const initializeDb = async () => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        await client.query(`
            CREATE TABLE IF NOT EXISTS requests (
                id TEXT PRIMARY KEY,
                subject TEXT NOT NULL,
                applicant TEXT,
                amount JSONB,
                date TEXT,
                deadline TEXT,
                status TEXT,
                project_id BIGINT,
                contract_id BIGINT,
                original_applicant_id INTEGER,
                current_step_owner_id INTEGER,
                is_consultation BOOLEAN,
                last_modified TIMESTAMPTZ,
                request_type_id INTEGER,
                workflow_id INTEGER
            );
        `);
        await client.query(`CREATE TABLE IF NOT EXISTS invoices ( id BIGINT PRIMARY KEY, request_id TEXT, invoice_number TEXT, beneficiary_id INTEGER );`);
        await client.query(`CREATE TABLE IF NOT EXISTS invoice_items ( id BIGINT PRIMARY KEY, invoice_id BIGINT, description TEXT, quantity INTEGER, unit_price NUMERIC, cost_type TEXT );`);
        await client.query(`CREATE TABLE IF NOT EXISTS consultations ( id BIGINT PRIMARY KEY, request_id TEXT, from_user_id INTEGER, to_user_id INTEGER, question TEXT, answer TEXT, status TEXT, question_date TIMESTAMPTZ, answer_date TIMESTAMPTZ );`);
        await client.query(`CREATE TABLE IF NOT EXISTS rejections ( id SERIAL PRIMARY KEY, request_id TEXT, step_name TEXT, rejected_by TEXT, reason TEXT, date TIMESTAMPTZ );`);

        const { rows } = await client.query('SELECT COUNT(*) FROM requests');
        if (rows[0].count === '0') {
             console.log('[Requests Service] Seeding initial data...');
             for (const r of initialRequests) {
                 await client.query(`INSERT INTO requests VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)`, [r.id, r.subject, r.applicant, r.amount, r.date, r.deadline, r.status, r.projectId, r.contractId, r.originalApplicantId, r.currentStepOwnerId, r.isConsultation, r.lastModified, r.requestTypeId, r.workflowId]);
             }
             for (const i of initialInvoices) { await client.query(`INSERT INTO invoices VALUES ($1, $2, $3, $4)`, [i.id, i.requestId, i.invoiceNumber, i.beneficiaryId]); }
             for (const it of initialInvoiceItems) { await client.query(`INSERT INTO invoice_items VALUES ($1, $2, $3, $4, $5, $6)`, [it.id, it.invoiceId, it.description, it.quantity, it.unitPrice, it.costType]); }
        }
        await client.query('COMMIT');
        console.log("✅ [Requests Service] PostgreSQL database is ready.");
    } catch (err) {
        await client.query('ROLLBACK');
        console.error("❌ [Requests Service] Error initializing database:", err);
        process.exit(1);
    } finally {
        client.release();
    }
};
initializeDb();

const asyncHandler = (fn) => async (req, res, next) => {
    try { await fn(req, res, next); } catch (error) {
        console.error(`[Requests Service] Error:`, error);
        res.status(400).json({ message: error.message });
    }
};

const getRequests = async (req, res) => {
    const { rows } = await pool.query('SELECT *, original_applicant_id AS "originalApplicantId", current_step_owner_id AS "currentStepOwnerId" FROM requests ORDER BY last_modified DESC');
    res.json(rows);
};

const getRequestDetails = async (req, res) => {
    const { id } = req.params;
    const requestRes = await pool.query('SELECT *, original_applicant_id AS "originalApplicantId", current_step_owner_id AS "currentStepOwnerId" FROM requests WHERE id = $1', [id]);
    const request = requestRes.rows[0];
    if (!request) return res.status(404).json({ message: 'Request not found' });
    
    // In a real microservice, we would make API calls to other services to get user/project names.
    // For now, we return IDs and let the frontend resolve them.
    const invoicesRes = await pool.query('SELECT * FROM invoices WHERE request_id = $1', [id]);
    const invoiceItemsRes = await pool.query('SELECT * FROM invoice_items WHERE invoice_id = ANY($1::bigint[])', [invoicesRes.rows.map(i => i.id)]);
    
    request.invoices = invoicesRes.rows.map(inv => ({
        ...inv,
        items: invoiceItemsRes.rows.filter(item => item.invoice_id === inv.id)
    }));
    
    // Fetch other related data
    const rejectionsRes = await pool.query('SELECT * FROM rejections WHERE request_id = $1', [id]);
    request.rejectionHistory = rejectionsRes.rows;
    const consultationsRes = await pool.query('SELECT * FROM consultations WHERE request_id = $1', [id]);
    request.consultations = consultationsRes.rows;

    // Mocking some details that require other services
    request.requestingUnit = 'واحد سازمانی (از سرویس دیگر)';
    request.creditSource = 'منبع اعتبار (از سرویس دیگر)';
    request.workflow = { steps: [], currentActionBy: 'مسئول فعلی' };

    res.json(request);
};

// Other controllers (add, update, delete, approve, etc.) would be implemented here using SQL queries.

app.get('/api/requests', asyncHandler(getRequests));
app.get('/api/requests/:id', asyncHandler(getRequestDetails));

app.get("/health", (req, res) => res.json({ status: "ok" }));
app.listen(PORT, () => console.log(`📬 Requests service running on http://localhost:${PORT}`));
