const express = require("express");
const dotenv = require("dotenv");
const cors = require('cors');
const { Pool } = require('pg');

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3004;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const ContractStatus = {
    Active: 'فعال',
    Pending: 'در دست بررسی',
    Archived: 'آرشیو شده',
};

const initialContracts = [
    { id: 1, contractNumber: '1403-04-0001', title: 'دستگاه فیلامنت کامپیوتری', party: 'هیدروفن کوانتومی', amount: 102000000, endDate: '1404/02/17', status: ContractStatus.Pending, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/02/17' },
    { id: 2, contractNumber: '1403-01-0001', title: 'هیدروفن کوانتومی', party: 'علی اصغری نژاد', amount: 60000000, endDate: '1404/01/10', status: ContractStatus.Pending, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/01/10' },
    { id: 3, contractNumber: '1403-05-0001', title: 'مشاوره و تحلیل سیستم', party: 'آقای محمدی', amount: null, endDate: '1404/11/13', status: ContractStatus.Active, manualContractNumber: '---', employer: 'شرکت ما (واحد داخلی)', ourRole: 'payer', contractType: 'خرید', category: 'خدمات', projectType: 'پروژه‌ای', relatedCenter: 'فناوری', startDate: '1403/11/13' },
];

const initializeDb = async () => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        await client.query(`
            CREATE TABLE IF NOT EXISTS contracts (
                id BIGINT PRIMARY KEY,
                contract_number TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                party TEXT NOT NULL,
                amount BIGINT,
                end_date TEXT,
                status TEXT,
                manual_contract_number TEXT,
                employer TEXT,
                our_role TEXT,
                contract_type TEXT,
                category TEXT,
                project_type TEXT,
                related_center TEXT,
                start_date TEXT
            );
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS contract_payments (
                id BIGINT PRIMARY KEY,
                contract_id BIGINT REFERENCES contracts(id) ON DELETE CASCADE,
                type TEXT,
                date TEXT,
                amount JSONB,
                description TEXT,
                reference_number TEXT
            );
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS contract_guarantees (
                id BIGINT PRIMARY KEY,
                contract_id BIGINT REFERENCES contracts(id) ON DELETE CASCADE,
                type TEXT,
                issuer TEXT,
                reference_number TEXT,
                amount JSONB,
                issue_date TEXT,
                expiry_date TEXT,
                related_center TEXT
            );
        `);
        
        await client.query(`
            CREATE TABLE IF NOT EXISTS contract_addendums (
                id BIGINT PRIMARY KEY,
                contract_id BIGINT REFERENCES contracts(id) ON DELETE CASCADE,
                type TEXT,
                date TEXT,
                number TEXT,
                amount_change JSONB,
                description TEXT
            );
        `);

        await client.query(`
            CREATE TABLE IF NOT EXISTS contract_attachments (
                id BIGINT PRIMARY KEY,
                contract_id BIGINT REFERENCES contracts(id) ON DELETE CASCADE,
                file_name TEXT,
                file_type TEXT,
                upload_date TEXT
            );
        `);

        const { rows } = await client.query('SELECT COUNT(*) FROM contracts');
        if (rows[0].count === '0') {
            console.log('[Contracts Service] Seeding initial contract data...');
            for (const contract of initialContracts) {
                await client.query(
                    `INSERT INTO contracts (id, contract_number, title, party, amount, end_date, status, manual_contract_number, employer, our_role, contract_type, category, project_type, related_center, start_date)
                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)`,
                    [contract.id, contract.contractNumber, contract.title, contract.party, contract.amount, contract.endDate, contract.status, contract.manualContractNumber, contract.employer, contract.ourRole, contract.contractType, contract.category, contract.projectType, contract.relatedCenter, contract.startDate]
                );
            }
        }

        await client.query('COMMIT');
        console.log("✅ [Contracts Service] PostgreSQL database is ready.");
    } catch (err) {
        await client.query('ROLLBACK');
        console.error("❌ [Contracts Service] Error initializing database:", err);
        process.exit(1);
    } finally {
        client.release();
    }
};

initializeDb();

const asyncHandler = (fn) => async (req, res, next) => {
    try {
        await fn(req, res, next);
    } catch (error) {
        console.error(`[Contracts Service] Error in ${req.method} ${req.path}:`, error);
        res.status(400).json({ message: error.message });
    }
};

// --- Controller Logic ---

const getContractList = async (req, res) => {
    const { rows } = await pool.query('SELECT id, contract_number, title, party, amount, end_date, status FROM contracts ORDER BY id DESC');
    res.json(rows);
};

const getContractDetails = async (req, res) => {
    const contractId = Number(req.params.id);
    if (isNaN(contractId)) {
        return res.status(400).json({ message: 'Invalid contract ID' });
    }

    const contractRes = await pool.query('SELECT * FROM contracts WHERE id = $1', [contractId]);
    const contract = contractRes.rows[0];

    if (!contract) {
        return res.status(404).json({ message: 'Contract not found' });
    }

    const [paymentsRes, guaranteesRes, addendumsRes, attachmentsRes] = await Promise.all([
        pool.query('SELECT * FROM contract_payments WHERE contract_id = $1', [contractId]),
        pool.query('SELECT * FROM contract_guarantees WHERE contract_id = $1', [contractId]),
        pool.query('SELECT * FROM contract_addendums WHERE contract_id = $1', [contractId]),
        pool.query('SELECT * FROM contract_attachments WHERE contract_id = $1', [contractId]),
    ]);

    contract.payments = paymentsRes.rows;
    contract.guarantees = guaranteesRes.rows;
    contract.addendums = addendumsRes.rows.map(a => ({...a, amountChange: a.amount_change})); // handle snake_case
    contract.attachments = attachmentsRes.rows;

    res.json(contract);
};

const addContract = async (req, res) => {
    const contractData = req.body;
    const newId = Date.now();
    
    await pool.query(
        `INSERT INTO contracts (id, contract_number, title, party, amount, end_date, status, manual_contract_number, employer, our_role, contract_type, category, project_type, related_center, start_date)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)`,
        [newId, `C-${newId}`, contractData.title, contractData.party, contractData.amount, contractData.endDate, ContractStatus.Pending, contractData.manualContractNumber, contractData.employer, contractData.ourRole, contractData.contractType, contractData.category, "پروژه‌ای", contractData.relatedCenter, contractData.startDate]
    );
    
    const { rows } = await pool.query('SELECT id, contract_number, title, party, amount, end_date, status FROM contracts ORDER BY id DESC');
    res.status(201).json(rows);
};

const addPayment = async (req, res) => {
    const contractId = Number(req.params.id);
    const paymentData = req.body;
    const newId = Date.now();

    await pool.query(
        `INSERT INTO contract_payments (id, contract_id, type, date, amount, description, reference_number)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [newId, contractId, paymentData.type, paymentData.date, paymentData.amount, paymentData.description, paymentData.referenceNumber]
    );

    req.params.id = contractId; // to reuse getContractDetails
    await getContractDetails(req, res);
};

const deleteContract = async (req, res) => {
    const contractId = Number(req.params.id);
    // In a real microservice architecture, checking dependencies would require an API call to service-main.
    // For now, we assume the dependency check is handled by the frontend or is not critical for this service.
    
    await pool.query('DELETE FROM contracts WHERE id = $1', [contractId]);
    
    const { rows } = await pool.query('SELECT id, contract_number, title, party, amount, end_date, status FROM contracts ORDER BY id DESC');
    res.json(rows);
};

// --- API Endpoints ---
app.get('/contracts', asyncHandler(getContractList));
app.get('/contracts/:id', asyncHandler(getContractDetails));
app.post('/contracts', asyncHandler(addContract));
app.delete('/contracts/:id', asyncHandler(deleteContract));
app.post('/contracts/:id/payments', asyncHandler(addPayment));
// NOTE: Other sub-entity endpoints (guarantees, addendums) would follow the same pattern as addPayment.

// Health Check
app.get("/health", (req, res) => res.json({ status: "ok" }));

app.listen(PORT, () => console.log(`📑 Contracts service running on http://localhost:${PORT}`));
