// This service runs the existing in-memory mock backend for all data
// EXCEPT for user authentication, which is handled by service-users.js.

const express = require('express');
const cors = require('cors');

const { virtualApi } = (() => {
    // This IIFE simulates the module loading for the virtual backend
    require('./virtual-backend/db.ts');
    const identityController = require('./virtual-backend/controllers/identityController.ts');
    const organizationController = require('./virtual-backend/controllers/organizationController.ts');
    const requestController = require('./virtual-backend/controllers/requestController.ts');
    const workflowController = require('./virtual-backend/controllers/workflowController.ts');
    const bankAccountController = require('./virtual-backend/controllers/bankAccountController.ts');
    const accessController = require('./virtual-backend/controllers/accessController.ts');
    const projectController = require('./virtual-backend/controllers/projectController.ts');
    const financialResourceController = require('./virtual-backend/controllers/financialResourceController.ts');
    const workMeasurementController = require('./virtual-backend/controllers/workMeasurementController.ts');
    const contractController = require('./virtual-backend/controllers/contractController.ts');
    const analysisController = require('./virtual-backend/controllers/analysisController.ts');
    const notificationController = require('./virtual-backend/controllers/notificationController.ts');
    const payrollController = require('./virtual-backend/controllers/payrollController.ts');
    const reportController = require('./virtual-backend/controllers/reportController.ts');
    const automationController = require('./virtual-backend/controllers/automationController.ts');

    const createApiController = (controller) => {
        return Object.keys(controller).reduce((acc, key) => {
            acc[key] = (...args) => {
                try {
                    const result = controller[key](...args);
                    return Promise.resolve(result); // Simulate async for consistency
                } catch (error) {
                    return Promise.reject(error);
                }
            };
            return acc;
        }, {});
    };

    return {
        virtualApi: {
            identity: createApiController(identityController),
            organization: createApiController(organizationController),
            request: createApiController(requestController),
            workflow: createApiController(workflowController),
            bankAccount: createApiController(bankAccountController),
            access: createApiController(accessController),
            project: createApiController(projectController),
            financialResource: createApiController(financialResourceController),
            workMeasurement: createApiController(workMeasurementController),
            contract: createApiController(contractController),
            analysis: createApiController(analysisController),
            notification: createApiController(notificationController),
            payroll: createApiController(payrollController),
            report: createApiController(reportController),
            automation: createApiController(automationController),
        }
    };
})();

const app = express();
const PORT = 3002;

app.use(cors());
app.use(express.json());

const asyncHandler = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(error => {
        console.error(`[Main Service] Error in ${req.method} ${req.path}:`, error);
        res.status(400).json({ message: error.message });
    });
};

// --- API Routes for Main Service ---

// Note: /api/users, /api/login, /api/register are handled by service-users.js
// This service provides the rest of the mock data.

// Beneficiaries, PettyCash, Roles are part of identity but not auth, so they are here.
app.get('/api/beneficiaries', asyncHandler(async (req, res) => res.json(await virtualApi.identity.getBeneficiaries())));
app.get('/api/petty-cash-holders', asyncHandler(async (req, res) => res.json(await virtualApi.identity.getPettyCashHolders())));
app.post('/api/petty-cash-holders/set-global-limit', asyncHandler(async (req, res) => res.json(await virtualApi.identity.updateAllPettyCashLimits(req.body.limit))));
app.get('/api/roles', asyncHandler(async (req, res) => res.json(await virtualApi.identity.getRoles())));

// Organization
app.get('/api/org-units', asyncHandler(async (req, res) => res.json(await virtualApi.organization.getOrgUnits())));
app.delete('/api/org-units/:id', asyncHandler(async (req, res) => res.json(await virtualApi.organization.deleteOrgUnit(req.params.id))));
app.post('/api/org-units', asyncHandler(async (req, res) => res.json(await virtualApi.organization.addOrgUnit(req.body))));
app.put('/api/org-units/:id', asyncHandler(async (req, res) => res.json(await virtualApi.organization.updateOrgUnit({ ...req.body, id: req.params.id }))));


// Requests
app.get('/api/requests', asyncHandler(async (req, res) => res.json(await virtualApi.request.getRequests())));
app.get('/api/requests/:id', asyncHandler(async (req, res) => res.json(await virtualApi.request.getRequestDetails(req.params.id))));
app.post('/api/requests', asyncHandler(async (req, res) => res.status(201).json(await virtualApi.request.addRequest(req.body.requestData, req.body.invoicesData))));
app.delete('/api/requests/:id', asyncHandler(async (req, res) => res.json(await virtualApi.request.deleteRequest(req.params.id))));
app.post('/api/requests/:id/approve', asyncHandler(async (req, res) => res.json(await virtualApi.request.approveRequestStep(req.params.id))));
app.post('/api/requests/:id/reject', asyncHandler(async (req, res) => res.json(await virtualApi.request.rejectRequest(req.params.id, req.body.reason))));
app.post('/api/requests/:id/consultations', asyncHandler(async (req, res) => res.json(await virtualApi.request.askForConsultation(req.params.id, req.body.toUserIds, req.body.question))));
app.put('/api/requests/:id/resubmit', asyncHandler(async (req, res) => res.json(await virtualApi.request.resubmitRequest(req.body.requestData, req.body.invoicesData))));
app.get('/api/consultations', asyncHandler(async (req, res) => res.json(await virtualApi.request.getConsultations())));
app.post('/api/consultations/:id/answer', asyncHandler(async (req, res) => res.json(await virtualApi.request.answerConsultation(Number(req.params.id), req.body.answer))));

// Other simple CRUDs
app.get('/api/bank-accounts', asyncHandler(async (req, res) => res.json(await virtualApi.bankAccount.getBankAccounts())));
app.get('/api/access-levels', asyncHandler(async (req, res) => res.json(await virtualApi.access.getAccessLevels())));
app.get('/api/projects', asyncHandler(async (req, res) => res.json(await virtualApi.project.getProjects())));
app.get('/api/financial-resources', asyncHandler(async (req, res) => res.json(await virtualApi.financialResource.getFinancialResources())));
app.get('/api/tasks', asyncHandler(async (req, res) => res.json(await virtualApi.workMeasurement.getTasks())));
app.get('/api/request-types', asyncHandler(async (req, res) => res.json(await virtualApi.workflow.getRequestTypes())));
app.get('/api/workflows', asyncHandler(async (req, res) => res.json(await virtualApi.workflow.getWorkflows())));

// Contracts
app.get('/api/contracts', asyncHandler(async (req, res) => res.json(await virtualApi.contract.getContractList())));
app.get('/api/contracts/:id', asyncHandler(async (req, res) => res.json(await virtualApi.contract.getContractDetails(Number(req.params.id)))));
app.post('/api/contracts/:id/payments', asyncHandler(async (req, res) => res.json(await virtualApi.contract.addPayment({ ...req.body, contractId: Number(req.params.id) }))));
app.post('/api/contracts', asyncHandler(async (req, res) => res.status(201).json(await virtualApi.contract.addContract(req.body))));

// Analysis
app.post('/api/analysis', asyncHandler(async (req, res) => res.json(await virtualApi.analysis.getAnalysis(req.body.question))));
app.get('/api/analysis/templates', asyncHandler(async (req, res) => res.json(await virtualApi.analysis.getTemplates())));

// Notifications
app.get('/api/notifications', asyncHandler(async (req, res) => res.json(await virtualApi.notification.getNotifications())));
app.post('/api/notifications/:id/read', asyncHandler(async (req, res) => res.json(await virtualApi.notification.markNotificationAsRead(Number(req.params.id)))));
app.post('/api/notifications/read-all', asyncHandler(async (req, res) => res.json(await virtualApi.notification.markAllNotificationsAsRead())));

// Payroll
app.get('/api/payrolls', asyncHandler(async (req, res) => res.json(await virtualApi.payroll.getPayrolls())));
app.get('/api/payrolls/:id', asyncHandler(async (req, res) => res.json(await virtualApi.payroll.getPayrollDetails(Number(req.params.id)))));

// Reports
app.get('/api/reports/project-financial-summary', asyncHandler(async (req, res) => res.json(await virtualApi.report.getProjectFinancialSummary())));
app.get('/api/reports/status-distribution', asyncHandler(async (req, res) => res.json(await virtualApi.report.getStatusDistribution())));
app.get('/api/reports/monthly-request-volume', asyncHandler(async (req, res) => res.json(await virtualApi.report.getMonthlyRequestVolume())));
app.get('/api/invoice-items/search', asyncHandler(async (req, res) => res.json(await virtualApi.report.searchInvoiceItems(req.query))));

// Automation
app.get('/api/automation/inbox', asyncHandler(async (req, res) => res.json(await virtualApi.automation.getInboxLetters(6)))); // Hardcoded user 6 (admin)
app.get('/api/automation/letters/:id', asyncHandler(async (req, res) => res.json(await virtualApi.automation.getLetterDetails(Number(req.params.id), 6))));
app.post('/api/automation/letters', asyncHandler(async (req, res) => res.status(201).json(await virtualApi.automation.sendLetter(req.body))));
app.get('/api/automation/templates', asyncHandler(async (req, res) => res.json(await virtualApi.automation.getLetterTemplates())));
app.post('/api/automation/templates', asyncHandler(async (req, res) => res.status(201).json(await virtualApi.automation.addLetterTemplate(req.body))));
app.delete('/api/automation/templates/:id', asyncHandler(async (req, res) => res.json(await virtualApi.automation.deleteLetterTemplate(Number(req.params.id)))));


app.listen(PORT, () => {
  console.log(`📦 Main Service (Virtual Backend) running on http://localhost:${PORT}`);
});