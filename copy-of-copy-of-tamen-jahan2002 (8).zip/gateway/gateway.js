const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// --- Proxy Middleware ---
// The order of these rules is important. More specific routes must come first.

// 1. Proxy to Users service (port 3001)
app.use(
  "/api/login",
  createProxyMiddleware({ target: "http://localhost:3001", changeOrigin: true })
);
app.use(
  "/api/users",
  createProxyMiddleware({ target: "http://localhost:3001", changeOrigin: true })
);

// 2. Proxy to Project service (port 3003)
app.use(
  "/api/projects",
  createProxyMiddleware({ target: "http://localhost:3003", changeOrigin: true })
);

// 3. Proxy to Contracts service (port 3004)
app.use(
  "/api/contracts",
  createProxyMiddleware({ target: "http://localhost:3004", changeOrigin: true })
);

// 4. Proxy to Requests service (port 3005)
app.use(
  ["/api/requests", "/api/consultations"],
  createProxyMiddleware({ target: "http://localhost:3005", changeOrigin: true })
);

// 5. Proxy to new Base Info service (port 3006)
app.use(
  [
    "/api/org-units", 
    "/api/beneficiaries", 
    "/api/petty-cash-holders", 
    "/api/bank-accounts", 
    "/api/financial-resources", 
    "/api/request-types",
    "/api/roles"
  ],
  createProxyMiddleware({ target: "http://localhost:3006", changeOrigin: true })
);

// 6. Proxy all other API requests to the Main service (port 3002)
app.use(
  "/api",
  createProxyMiddleware({ target: "http://localhost:3002", changeOrigin: true })
);

// Health Check
app.get("/health", (req, res) => res.json({ status: "ok" }));

// Serve frontend static files in a production-like setup
const frontendPath = path.join(__dirname, '..', 'frontend', 'dist');
app.use(express.static(frontendPath));
app.get('*', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

app.listen(PORT, () => console.log(`✅ Gateway running on port ${PORT}`));